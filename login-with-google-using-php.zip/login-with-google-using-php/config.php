<?php
session_start();
include_once("src/Google_Client.php");
include_once("src/contrib/Google_Oauth2Service.php");
######### edit details ##########
$clientId = '970980937053-3bfh176vph9k3s01g02t9u3hlq5mpq1a.apps.googleusercontent.com'; //Google CLIENT ID
$clientSecret = 'qAkcEWoz9ODLsnio5G35PjSD'; //Google CLIENT SECRET
$redirectUrl = 'http://localhost/login-with-google-using-php';  //return url (url to script)
$homeUrl = 'http://localhost/login-with-google-using-php';  //return to home

##################################

$gClient = new Google_Client();
$gClient->setApplicationName('Login to codexworld.com');
$gClient->setClientId($clientId);
$gClient->setClientSecret($clientSecret);
$gClient->setRedirectUri($redirectUrl);

$google_oauthV2 = new Google_Oauth2Service($gClient);
?>