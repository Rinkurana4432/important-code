<?php
//    require_once('PHPMailer_v5.1/class.phpmailer.php'); //library added in download source.
	require_once('PHPMailer_v5.1/class.phpmailer.php');
	require_once('PHPMailer_v5.1/class.smtp.php');
	require_once('PHPMailer_v5.1/PHPMailerAutoload.php');


	$mail = new PHPMailer;

	$mail->IsSMTP();                                      // Set mailer to use SMTP
	$mail->Host = 's3cur3.com';                 // Specify main and backup server
	$mail->Port = 587;                                    // Set the SMTP port
	$mail->SMTPAuth = true;                               // Enable SMTP authentication
	$mail->Username = 'admin@s3cur3.com';                // SMTP username
	$mail->Password = 'TAKGZ2B8f7';                  // SMTP password
	//$mail->SMTPSecure = 'ssl';                            // Enable encryption, 'ssl' also accepted

	$mail->From = 'admin@s3cur3.com';
	$mail->FromName = 'Your From name';
	$mail->AddAddress('dsingh@mind-roots.com', 'Dsingh');  // Add a recipient
	$mail->AddAddress('dsingh@mind-roots.com');               // Name is optional

	$mail->IsHTML(true);                                  // Set email format to HTML

	$mail->Subject = 'Here is the subject';
	$mail->Body    = 'This is the HTML message body <strong>in bold!</strong>';
	if(!$mail->Send()) {
	   echo 'Message could not be sent.';
	 }else{
	 echo 'Message has been sent';
	 }
?>
