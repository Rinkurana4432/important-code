<?php
  class c_test extends CI_Controller {
        function __construct() {
        parent::__construct();
        $this->load->helper('url');
		$this->load->library('session');
		$this->load->model('m_test');
	}
	public function index()
	{
		$this->load->view('v_test');
	}
        public function login(){
         $email = $_REQUEST['email'];
         $password = md5($_REQUEST['password']);
         $this->load->model('m_test');
         $result =  $this->m_test->login_user($email,$password);
         if($result == false){
           echo 'false';
         }
      }
      public function demo(){
       $this->load->view('v_insert');
       }
   public function insert_data(){
	$size = $_FILES['image']['size'];
	
	if($size != 0 && $size <= 49852 ){
	   if ($_FILES['image']['name'] != '') {
       $filenameext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
       if($filenameext =='jpg' || $filenameext =='jpeg' || $filenameext =='png' || $filenameext =='gif')
       {
        $file_name = substr(time(), 0, 12) . "" . rand(100, 1000);
        $file=$file_name.".".$filenameext;
        move_uploaded_file($_FILES["image"]["tmp_name"], "./assets/images/upload/" . $file);
       }
	}
	 $name = $_REQUEST['name'];
     $email = $_REQUEST['email'];
     $password = md5($_REQUEST['password']);
     $address =  $_REQUEST['address'];
     $this->load->model('m_test');
     $insert_value = array('name'=>$name,'email'=>$email,'password'=>$password,'address'=>$address,'image'=>$file);
	
     $insert_data = $this->m_test->insert($email,$insert_value);
     if($insert_data > 0){
		 echo 'Insert Successfully';
            }else{
              echo 'Email id is All ready';
            }
	  }else{
		  echo 'Image is too big';
	  }
	}
  

       public function view_all_user(){
             $this->load->model('m_test');
             $data['all'] = $this->m_test->view_data();         
              $this->load->view('v_all_data',$data);
             }
        public function delete_user(){
          $id = $_REQUEST['id'];
           $this->load->model('m_test');
           $id_delete = $this->m_test->delete($id);
            if($id_delete){
            echo "Delete Successfully";
             }else{
                echo "Not deleted";

               }

         }
		
		public function view_user(){
			$id = $_REQUEST['id'];
			//$this->load->model('m_test');
			$v_ata['user'] =  $this->m_test->edited_user($id);
			$this->load->view('v_edit',$v_ata);
			
		}
		public function update(){
			$id =  $_REQUEST['id'];	
			$name = $_REQUEST['name'];
			$email = $_REQUEST['email'];
			$address =  $_REQUEST['address'];
			if($_FILES['image']['name'] == ''){
			$update_value = array('name'=>$name,'email'=>$email,'address'=>$address);
			}else{
			$filenameext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
			if($filenameext =='jpg' || $filenameext =='jpeg' || $filenameext =='png' || $filenameext =='gif'){
				$file_name = substr(time(), 0, 12) . "" . rand(100, 1000);
				$file=$file_name.".".$filenameext;
				move_uploaded_file($_FILES["image"]["tmp_name"], "./assets/images/upload/" . $file);
				$update_value = array('name'=>$name,'email'=>$email,'address'=>$address,'image'=>$file);   
			   }
			}
			 $update_data = $this->m_test->update_user_data($id,$update_value);
			 
				if($update_data > 0){
				echo 'update Successfully';
              }else{
                  echo 'not updated';
              }	
			
		}
		public function multi(){
			$this->load->view('v_multi');
		}
        
		function doupload() {
		$name_array = array();
		$count = count($_FILES['userfile']['size']);
		foreach($_FILES as $key=>$value)
		for($s=0; $s<=$count-1; $s++){
		$_FILES['userfile']['name']= $value['name'][$s];
		$_FILES['userfile']['type'] = $value['type'][$s];
		$_FILES['userfile']['tmp_name']= $value['tmp_name'][$s];
		$_FILES['userfile']['error']= $value['error'][$s];
		$_FILES['userfile']['size']= $value['size'][$s];  
		$config['upload_path'] = './assets/m_upload/';
		$config['allowed_types'] = 'gif|jpg|png';
	    $config['max_size'] = '4096';
		$config['encrypt_name'] = TRUE; 
	    $this->load->library('upload', $config);
	 	$this->upload->do_upload();
		$data = $this->upload->data();
		$name_array[] = $data['file_name'];
		}
		$names= implode(',', $name_array);
		$this->load->database();
		$db_data = array('id'=> NULL,'name'=> $names);
		$insert_data2 = $this->m_test->insert_data($db_data);
	    if($insert_data2 > 0){
        echo 'Image Added Successfully';
        }
	}
	public function checkbo(){
		$this->load->view('v_check');
	}
	public function insert_check(){
	$dd = $_REQUEST['selectedLanguage'];
	$this->load->model('m_test');
     $insert_check_value = array('techno'=>$dd);
     $insert_data = $this->m_test->insert_check($insert_check_value);
     if($insert_data > 0){
        echo 'Insert check box value Successfully';
        }
	}
	
	public function simple_insert(){
		$name = $_REQUEST['name'];
		$email = $_REQUEST['email'];
		$address = $_REQUEST['address'];
		$city = $_REQUEST['city'];
		$this->load->model('m_test');
		$insert_simple_value = array("name"=>$name,"email"=>$email,"address"=>$address,"city"=>$city);
		$datas = $this->m_test->insert_value($email,$insert_simple_value);
		if($datas > 0){
		 	echo 'Simple value inserted';
		}else{
			echo 'Email ID Allready Exisits';
		}
	}
	
	public function practice(){
		$this->load->view('insert_pract');
	}
	
	
	public function insert_data_33(){ 
        $name = $_REQUEST['name'];
	    $email = $_REQUEST['email'];
		$address = $_REQUEST['address'];
		$city = $_REQUEST['city'];
		$this->load->model('m_test');
		$insert_simple_value = array("name"=>$name,"email"=>$email,"address"=>$address,"city"=>$city);
		$datas = $this->m_test->insert_value2($email,$insert_simple_value);
		if($datas > 0){
		 	echo 'Simple value inserted';
		}else{
			echo 'Email ID Allready Exisits';
		}
	}
	
	
		public function check(){
		$this->load->view('simple_check_val');
	}
	
	public function check_value(){
	$dd = $_REQUEST['techno'];
	$valued = implode(',',$dd);
	$this->load->model('m_test');
	$insert_checkbox_value = array('techno'=>$valued);
	 $data_checkbox = $this->m_test->insert_check_value($insert_checkbox_value);
	 if($data_checkbox > 0){
		$this->session->set_flashdata('result', 'Insert Successfully');
			//redirect('c_test/check');
	 }else{
		 echo 'Not added';
	 }
}
	
	
	
	
	
	
	
}
	


