<script language="javascript" type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-1.11.3.min.js"></script>
<title>Upload Form</title>
<form name="m_pic" id="m_img" enctype="multipart/form-data">
<input name="userfile[]" id="userfile" type="file" multiple=""  required />
<input type="submit" value="upload" />

</form>

<a href="<?php echo base_url(); ?>c_test/checkbo">Checkbox</a>
<span id="msg"></span>
<script>
$(document).ready(function (e) {
	 $("#m_img").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "<?php  echo base_url(); ?>c_test/doupload",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
			dataType: "html",
			success: function(htmlStr)
			 {
				$("#msg").html(htmlStr);
				$("#m_img").trigger('reset');
		    },
		  	error: function() 
	    	{
				
	    	} 
       
	   });
	 
	
	}));
});







</script>

