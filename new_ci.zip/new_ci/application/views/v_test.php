<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>-->
<script language="javascript" type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-1.11.3.min.js"></script>
 
	<form name="login_form" id="login_form2" method="post" action="javascript:login_user_data();" >
	<table>
	<tr><td>Email</td><td><input type="text" name="email" value="" ></td></tr>
	<tr><td>Password</td><td><input type="password" name="password" value="" ></td></tr>
	<tr><td><input type="submit" name="submit" value="Login"></td></tr>
	</table>
	<div id="msg"></div>

	</form>

		<script>
		function login_user_data(){
		   var data_to_send = $("#login_form2").serialize();
		   $.ajax({
		       url: "<?php echo base_url(); ?>c_test/login",
			   type: "post",
		       data: data_to_send,
		       cache: false,
		       success: function (result){
		      if(result == 'false'){
		     $("#msg").html('Invalid User name and Password');
		     }else {
		          $("#msg").html('Login successfully');
		          window.location.href="<?php echo base_url(); ?>c_test/demo";
		        }  
		     }
		  }); 
	       }


		</script>

