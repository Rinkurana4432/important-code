<script language="javascript" type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-1.11.3.min.js"></script>
 <title>View</title>
	<table border=1>
            <tr><th>Image</th><th>Name</th><th>Email</th><th>Address</th><th>Action</th></tr>
            <?php  foreach ($all as $user_dta){ ?>
            <tr id="tr_<?php echo $user_dta['id']; ?>">
			<td><img height=100 width=100 src="<?php echo base_url(); ?>assets/images/upload/<?php echo $user_dta['image']; ?>"></td>
                  <td><?php echo $user_dta['name']; ?></td>
                 <td><?php echo $user_dta['email']; ?></td>
                <td><?php echo $user_dta['address']; ?></td>
                <td>
                   <input type="button" value="Delete" onclick="delete_user('<?php echo $user_dta['id']; ?>');">
                 <!--input type="button" value="Edit" onclick="edit_user('<?php //echo $user_dta['id']; ?>')"--> 
				 <a href="<?php echo base_url(); ?>c_test/view_user?id=<?php echo $user_dta['id'];  ?>"><input type="button" value="Edit"></a>
              </td>   
           </tr>
              <?php } ?>
       </table>
<a href="<?php echo base_url(); ?>c_test/demo">For insert</a>

<script>
function delete_user(id){
  var delete_user = confirm("Do you really want to delete this user");
        if(delete_user == true){
      var data_to_send = "id=" +id;
        $.ajax({
               url: "<?php echo base_url(); ?>c_test/delete_user",
           type: "post",
            data: data_to_send,
            cache: false,
           success: function (htmlStr){
                 $("#msg").html(htmlStr);
                 $("#tr_"+id).remove();
                 //$("#msg").fadeOut(2000);  
              }
         });

   }

 }
function edit_user(id){
var data_to_send = "id= " + id;
 $.ajax({
	 url:"<?php echo base_url(); ?>c_test/view_user",
	 type: "post",
            data: data_to_send,
            cache: false,
           success: function (htmlStr){
                 $("#msg").html(htmlStr);
            }
		});
	}

</script>
