 <form action="<?php echo base_url(); ?>c_test/check_value" method="post" enctype="multipart/form-data" id="che_ck">  
   <div style="width:300px;border-radius:6px;margin:0px auto">  
 <table border="1">  
   <tr>  
      <td colspan="2">Select Technology:</td>  
   </tr>  
   <tr><td>PHP</td><td><input type="checkbox" name="techno[]" value="PHP"></td></tr>  
   <tr><td>.Net</td><td><input type="checkbox" name="techno[]" value=".Net"></td></tr>  
   <tr><td>Java</td><td><input type="checkbox" name="techno[]" value="Java"></td></tr>  
   <tr><td>JavaScript</td><td><input type="checkbox" name="techno[]" value="javascript"></td></tr>  
   <tr><td colspan="2" align="center">
   <tr><td><input type="submit" value="Submit"></td></tr>
   </td></tr>  
 </table> 
	<span id="msg" style="background: red none repeat scroll 0 0;color: #fff;display: none;font-size: 13px;padding:6px;margin-top:5px;"></span> 
 </div>  
 </form>