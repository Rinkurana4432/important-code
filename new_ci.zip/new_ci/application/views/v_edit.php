<script language="javascript" type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-1.11.3.min.js"></script>
<form name="insert_data" name="ins" action="" id="edit_user">
<table>
 <?php foreach ($user as $row): ?>	
<input type="hidden" value="<?php echo $row['id']; ?>"  name="id">
<tr><td>Name</td><td><input id="name" type="text" value="<?php echo $row['name']; ?>" name="name"></td></tr>
<tr><td>Email</td><td><input id="email" type="text" value="<?php echo $row['email']; ?>" name="email"></td></tr>
<tr><td>Address</td><td><input id="address" type="text" value="<?php echo $row['address']; ?>" name="address"></td></tr>
<tr><td>Image</td><td><img height=100 width=100 src="<?php echo base_url(); ?>assets/images/upload/<?php echo $row['image']; ?>"><br/><input type="file" name="image" id="image"></td></tr>
<tr><td><input type="submit" value="update" name="submit"></td></tr>
</table>
</form>
<span id="msg" ></span>
   <?php endforeach; ?>


<script>
$(document).ready(function (e) {
	 $("#edit_user").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "<?php  echo base_url(); ?>c_test/update",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
			dataType: "html",
			success: function(htmlStr)
			 {
			//	 alert(htmlStr);
			$("#msg").html(htmlStr);
			window.location.href = "<?php  echo base_url(); ?>c_test/view_all_user";
		    },
		  	error: function() 
	    	{
				
	    	} 
       
	   });
	 
	
	}));
});



</script>