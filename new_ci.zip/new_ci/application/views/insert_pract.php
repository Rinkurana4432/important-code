<script language="javascript" type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-1.11.3.min.js"></script>

<form name="pra" action="javascript:insert_val()" method="post" id="ins_user">
<table>
<tr><td>Name</td><td><input type="text" value="" name="name" id='name' required></td></tr>
<tr><td>Email</td><td><input type="text" value="" name="email" id='email' required></td></tr>
<tr><td>city</td><td><input type="text" value="" name="city" id="city" required></td></tr>
<tr><td>Address</td><td><input type="text" value="" name="address" id="address" required></td></tr>
<tr><td><input type="submit" value="submit" name="submit" ></td></tr>

</table>
</form>

<script>
function insert_val(){
var name = $('#name').val();
var email = $('#email').val();
var city = $('#city').val();
var address = $('#address').val();
var data_to_send = "name=" + name +"&email=" +email + "&city=" + city + "&address=" + address;
$.ajax({
           url: "<?php echo base_url(); ?>c_test/insert_data_33",
           type: "post",
           data: data_to_send,
           cache: false,
           success: function (htmlStr){
           alert(htmlStr);
		   $("#ins_user").trigger("reset");
           }
        });
}
</script>
