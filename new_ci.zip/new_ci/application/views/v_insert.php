<script language="javascript" type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-1.11.3.min.js"></script>
<title>Insert value</title>
<form name="insert_data" name="ins" action="javascript:user_insert();" id="ins_user">
<table>
<?php 
//session_start();
if(isset($_SESSION["id"]) ){
?>
<tr><td>Name</td><td><input type="text" value="" name="name" id='name' required></td></tr>
<tr><td>Email</td><td><input type="text" value="" name="email" id='email' required></td></tr>
<tr><td>Passsword</td><td><input type="password" value="" name="password" id="pass" required></td></tr>
<tr><td>Address</td><td><input type="text" value="" name="address" id="address" required></td></tr>
<tr><td>Image</td><td><input type="file" value="" name="image" id="img" required></td></tr>
<tr><td><input type="submit" value="Insert" name="submit"></td></tr>
</table>
</form>
<span id="msg" ></span><br/>
<a href="<?php echo base_url(); ?>c_test/view_all_user">View All Data</a><br/>
<a href="<?php echo base_url(); ?>c_test/multi">For Multi upload image </a>
<?php }else{
redirect(base_url()."c_test/index",refresh);
} ?>
 <script>
// function user_insert(e){
// e.preventDefault();
  // $.ajax({
               // url: "<?php echo base_url(); ?>c_test/insert_data",
               // type: "post",
               // data:  new FormData(this),
				// contentType: false,
				// cache: false,
				// processData:false,
				// dataType: "html",
               // success: function (htmlStr){
               // $("#msg").html(htmlStr);
               // $("#ins_user").trigger("reset");     
             
             // }
          // }); 
// }
$(document).ready(function (e) {
	 $("#ins_user").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "<?php  echo base_url(); ?>c_test/insert_data",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
			dataType: "html",
			success: function(htmlStr)
			 {
				 $("#msg").html(htmlStr);
				 $("#ins_user").trigger("reset");
				// if(htmlStr == "Insert Successfully"){
				//window.location.href = "<?php  echo base_url(); ?>c_test/view_all_user";
				
				// }else{
					// $("#msg").html("Email id is All ready");
					// $("#ins_user").trigger("reset");
				// }
		    },
		  	error: function() 
	    	{
				
	    	} 
       
	   });
	 
	
	}));
});
</script>
