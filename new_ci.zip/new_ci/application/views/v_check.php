<script type = "text/javascript" src = "http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.6.1.min.js"></script>
   <form action="" method="post" enctype="multipart/form-data" id="che_ck">  
   <div style="width:300px;border-radius:6px;margin:0px auto">  
 <table border="1">  
   <tr>  
      <td colspan="2">Select Technology:</td>  
   </tr>  
   <tr><td>PHP</td><td><input type="checkbox" name="techno" value="PHP" required></td></tr>  
   <tr><td>.Net</td><td><input type="checkbox" name="techno" value=".Net"></td></tr>  
   <tr><td>Java</td><td><input type="checkbox" name="techno" value="Java"></td></tr>  
   <tr><td>JavaScript</td><td><input type="checkbox" name="techno" value="javascript"></td></tr>  
   <tr><td colspan="2" align="center">
   <input type="button" id="btnSubmit" value="submit" name="sub">
   </td></tr>  
 </table> 
	<span id="msg" style="background: red none repeat scroll 0 0;color: #fff;display: none;font-size: 13px;padding:6px;margin-top:5px;"></span> 
 </div>  
 </form>
 
 
 <form name="sim_le" method="post"action="<?php echo base_url(); ?>c_test/simple_insert">
 <table border=1>
 <tr><td>Name</td><td><input type="text" name="name" required></td></tr>
 <tr><td>Email</td><td><input type="text" name="email" required></td></tr>
 <tr><td>Address</td><td><input type="text" name="address" required></td></tr>
 <tr><td>City</td><td><input type="text" name="city" required></td></tr>
 <tr><td><input type="submit" value="Submit"></td></tr>
 </table>
 </form>
 
 
 
 
 

<script language="JavaScript" type="text/JavaScript">
$(document).ready(function (){
$("#btnSubmit").click(function(){
var selectedLanguage = new Array();
$('input[name="techno"]:checked').each(function() {
selectedLanguage.push(this.value);
});
var data_to_send = "selectedLanguage="+ selectedLanguage ;
$.ajax({
		       url: "<?php  echo base_url(); ?>c_test/insert_check",
               type: "post",
               data: data_to_send,
			   cache: false, success: function(htmlStr){
			   $("#msg").show();
			   $("#msg").text(htmlStr);
			   $("#msg").fadeOut(6000);
			   $("#che_ck").trigger("reset");
             }
          }); 
      });
});
</script>
