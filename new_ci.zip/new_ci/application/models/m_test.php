<?php
	class m_test Extends CI_Model{
         function __construct() {
        parent::__construct();
        $this->load->helper('url');
       // session_start();
	}
        function login_user($email,$password){
         $this->load->database();
	     $this->db->select('*');
         $this->db->from('tbl_user');
         $this->db->where('email',$email);
         $this->db->where('password',$password);
         $data = $this->db->get();
         $tt = $data->row_array();
            $_SESSION['id'] = $tt['id'];
          if($data->num_rows() > 0){
          return true; 
          }else{
          return false;  
         }
      }


      function insert($email,$insert_value){
      $this->load->database();
	  $this->db->select('*');
	  $this->db->from('tbl_user');
	  $this->db->where('email',$email);
	  $exits = $this->db->get();
	  if($exits->num_rows() > 0){
	  return false;
	  }
      $this->db->insert('tbl_user', $insert_value);
      return $this->db->affected_rows();
     }

         function view_data(){
             $this->load->database();
             $this->db->select('*');
             $this->db->from('tbl_user');
             $ddd = $this->db->get();
                if($ddd->num_rows() > 0){
                return $ddd->result_array();
            }else{
              return false;
                }
 
          }
         function delete($id){
         $this->load->database();
           $this->db->delete('tbl_user',array("id"=>$id));
           return $this->db->affected_rows();    
        }
		
		function edited_user($id){
		 $this->load->database();
		 $this->db->select('*');
         $this->db->from('tbl_user');
         $this->db->where('id',$id);
		$d = $this->db->get();
                 if($d->num_rows() > 0){
                return $d->result_array();
            }else{
              return false;
                }
		}
		
		public function update_user_data($id,$update_value){
			$this->load->database();
			$this->db->where('id',$id);
			$this->db->update('tbl_user',$update_value);
			// echo $this->db->last_query();
	       // die;
			return $this->db->affected_rows();
		}
		
		public function insert_data($db_data){
			$this->load->database();
			$this->db->insert('tbl_multi', $db_data);
		    return $this->db->affected_rows();
		}
        Public function insert_check($insert_check_value){
			$this->load->database();
			$this->db->insert('tbl_multi',$insert_check_value);
			return $this->db->affected_rows();
		}
		public function insert_value($email,$insert_simple_value){
			$this->load->database();
			$this->db->select('*');
			  $this->db->from('tbl_user');
			  $this->db->where('email',$email);
			  $exits = $this->db->get();
			  if($exits->num_rows() > 0){
			  return false;
			  }
			$this->db->insert('tbl_simple',$insert_simple_value);
			return $this->db->affected_rows();
		}

        public function insert_value2($email,$value){
		   $this->load->database();
		   $this->db->from('tbl_simple');
		   $this->db->where('email',$email);
		   $get = $this->db->get();
		   if($get->num_rows()>0){
			   return false;
		   }
		   $this->db->insert('tbl_simple',$value);
		   return $this->db->affected_rows();
	    }
		
		public function insert_check_value($valued){
		$this->load->database();	
		$this->db->insert('tbl_multi',$valued);
		return $this->db->affected_rows();	
			
		}
		
		
		
}





















