-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 19, 2016 at 06:59 AM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.5.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `new_ci`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_multi`
--

CREATE TABLE `tbl_multi` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `techno` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_multi`
--

INSERT INTO `tbl_multi` (`id`, `name`, `techno`) VALUES
(10, '', 'PHP,Java,javascript'),
(23, '', '.Net'),
(24, '', 'PHP,.Net,Java,javascript'),
(25, '', 'PHP,.Net,Java,javascript'),
(30, '', 'PHP,.Net,Java'),
(31, '', 'PHP,.Net,Java'),
(32, '', 'PHP');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_multi2`
--

CREATE TABLE `tbl_multi2` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `techno` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pass_check`
--

CREATE TABLE `tbl_pass_check` (
  `id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pass_check`
--

INSERT INTO `tbl_pass_check` (`id`, `user_name`, `password`, `email`) VALUES
(1, 'kamal', '3691308f2a4c2f6983f2880d32e29c84', 'kamal@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_simple`
--

CREATE TABLE `tbl_simple` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `city` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_simple`
--

INSERT INTO `tbl_simple` (`id`, `name`, `address`, `email`, `city`) VALUES
(3, 'kaml', 'asdf', 'kamal@gmail.com', 'asdfdasf'),
(5, 'gtg', 'df', 'dfdf@gmail.com', 'dfdfdf'),
(6, 'sourcecode', 'zirakpur', 'admin@gmail.com', 'sss'),
(8, 'sourcecode', 'zirakpur', 'adminddd@gmail.com', 'sss'),
(10, 'asdf', 'adsfasd', 'admin@gmail.com', 'sssasfasfasfsadf'),
(11, 'asdf', 'adsfasd', 'admin@gmail.com', 'sssasfasfasfsadf');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `image` varchar(200) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `image`, `email`, `address`, `password`) VALUES
(10, 'KamalJeet', '1453361036465.gif', 'admin@gmail.com', 'Panchkula', 'e10adc3949ba59abbe56e057f20f883e'),
(28, 'Ramanjeet', '1453361056406.png', 'asdfn@gmail.com', 'asdfssss', '202cb962ac59075b964b07152d234b70'),
(30, 'dummy', '1455268727845.jpg', 'as@gmail.com', 'asdf', '912ec803b2ce49e4a541068d495ab570'),
(31, 'syana ', '1458190469479.png', 'pol@gmail.com', 'zrkpr', 'e10adc3949ba59abbe56e057f20f883e');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_multi`
--
ALTER TABLE `tbl_multi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_multi2`
--
ALTER TABLE `tbl_multi2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_pass_check`
--
ALTER TABLE `tbl_pass_check`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_simple`
--
ALTER TABLE `tbl_simple`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_multi`
--
ALTER TABLE `tbl_multi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `tbl_multi2`
--
ALTER TABLE `tbl_multi2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_pass_check`
--
ALTER TABLE `tbl_pass_check`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_simple`
--
ALTER TABLE `tbl_simple`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
