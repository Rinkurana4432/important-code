<!DOCTYPE html>
<html >
  <head>
   <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
       <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/payment.css">
    <title>Payment Info</title>
  </head>


  <body>
  <!--start header-->
		<div style="display:none;" class="header header-main">
			<div class="inner">
			<div class="logo-container">
					<div class="logo">
					<a class="navigateTo" href="http://rempic.com/" title="REMPIC Mobile App"><img  src="<?php echo base_url(); ?>img/logo.png" alt="REMPIC Mobile App"></a>
				</div>
			</div>            
			
			<!--mobileMenu toggle-->
			<div class="mobileMenuToggle"><a href=""></a></div>
	    </div>
	</div>
	<!--end header-->
      <div class="main-container">  
	 <div class="form-container">
    <form method="POST" onsubmit="return checkCheckBox(this)" action="<?php echo base_url(); ?>index.php/welcome/pay" class="theForm" >
   		
		<div class="personal-information">	  
			<div style="float:left">Order Details</div>		
			<div class="next" style="float:right;">
			
			</div>
		<div style="clear:both"></div>
      </div> <!-- end of personal-information -->
	  
      <label class="item item-input">
          <div class="input-label">Print Details</div>
		</label>
	 <label class="item item-input">
          <div class="input" style="padding:2px !important;margin-left:32px;margin-top: 8px;">Size<span class="re_rid">*</span></div>
		  <div class="input">
		   <select id="size" name="size" class="sel" required="required" >
		      <option disabled selected value=''>Select size(inches)</option>
			  <option value="45.44">30x30 @ $45.44 each</option>
			  <option value="39.81">26x26 @ $39.81 each</option>
			  <option value="35.04">20x20 @ $35.04 each</option>
			  <option value="31.14">16x16 @ $31.14 each</option>
			  <option value="28.10">12x12 @ $28.10 each</option>
			  <option value="25.95">8x8 @ $25.95 each</option>
			</select> 
			</div>
	 </label>
	<label class="item item-input">
          <div class="input">Qty<span class="re_rid">*</span></div>
		  <input id="input-field" type="text" name="qty" class="qty" required="required" autocomplete="on" maxlength="45" placeholder="Enter Quantity" onclick="allnumeric(document.form1.text1)"  />
	</label>  
	<label class="item item-input">
          <div class="input-label" style="margin-left: 32px;">Customer Details</div>
		</label>
    <label class="item item-input">
           <div class="input">First Name<span class="re_rid">*</span></div>
		  <input id="input-field" type="text" name="fname" required="required" autocomplete="on" maxlength="45" placeholder="Enter First Name"/>
	</label>
	<label class="item item-input">
           <div class="input">Surname<span class="re_rid">*</span></div>
		  <input id="input-field" type="text" name="surname" required="required" autocomplete="on" maxlength="45" placeholder="Enter Surname"/>
	</label> 
	<label class="item item-input">
           <div class="input">Email Address<span class="re_rid">*</span></div>
		  <input id="input-field" type="email" name="eaddress" required="required" autocomplete="on" maxlength="45" placeholder="Enter Email Address" class="txtemail"/>
	</label>
	<label class="item item-input">
           <div class="input">Phone Number<span class="re_rid">*</span></div>
		  <input id="input-field" type="text" class="phno" name="phnumber" required="required" autocomplete="on" maxlength="45" placeholder="Enter Phone Number"/>
	</label>
	<label class="item item-input">
           <div class="input">Address1<span class="re_rid">*</span></div>
		  <input id="input-field" type="text" name="streetaddress1" required="required" autocomplete="on" maxlength="45" placeholder="Enter Address1"/>
	</label>
	<label class="item item-input">
           <div class="input">Address2<span class="re_rid">*</span></div>
		  <input id="input-field" type="text" name="streetaddress2" required="required" autocomplete="on" maxlength="45" placeholder="Enter Address2"/>
	</label>
	<label class="item item-input">
           <div class="input">Address City<span class="re_rid">*</span></div>
		  <input id="input-field" type="text" name="city" required="required" autocomplete="on" maxlength="45" placeholder="Enter Address City"/>
	</label>
	<label class="item item-input">
           <div class="input">Address State<span class="re_rid">*</span></div>
		  <input id="input-field" type="text" name="state" required="required" autocomplete="on" maxlength="45" placeholder="Enter Address State"/>
	</label>
	<label class="item item-input">
           <div class="input">Address Postcode<span class="re_rid">*</span></div>
		  <input id="input-field" type="text" name="postcode" required="required" autocomplete="on" maxlength="45" placeholder="Enter Address Postcode"/>
	</label>
	<label class="item item-input">
           <div class="input">Address Country<span class="re_rid">*</span></div>
		  <input id="input-field" type="text" name="country" required="required" autocomplete="on" maxlength="45" placeholder="Enter Address Country"/>
	</label>
	<input type="hidden" name="token" id="token" value="" />
	<input type="hidden" name="image_name"  value="<?php echo $_SESSION['image_name']; ?>" />
	<label class="item item-input">
			<div class="input-label" style="color:#000;">
					<div class="prev" style="float:left; color: #656565;">
                    <input type="checkbox" name="agree" value="1" />I agree to the Terms & Conditions
					</div>
					<div class="next" style="float:right;">
						<input type="submit" value="Next"  class="sub" onClick="return ValidateForm()">
					</div>
				<div style="clear:both"></div>	
			</div>
			
    </label>
      
    </form>
  </div> <!-- end of form-container -->
  </div>
  <div style="display: block;" id="footer">
	<div class="footer_content_wrapper">
		<div class="content">
						
			<!--div class="logo">
				<a title="REMPIC Mobile App" href="http://rempic.com" class="navigateTo"><img alt="REMPIC Mobile App" src="<?php //echo base_url();?>img/footer_logo.png"></a>
			</div-->
			<p class="copyright"> ©Signs By Knight | ABN 32 014 129 608 | <a href="http://rempic.com/terms-and-conditions/">Terms &amp; Conditions</a> | <a href="http://rempic.com/return-policy/">Shipping &amp; Returns</a> | <a href="http://rempic.com/privacy-policy/">Privacy Policy</a> | All Rights Reserved.</p>

			<!--social-->
			
		</div>
	</div>
</div>
<!--end footer-->
</body>

</html>
<SCRIPT language=JavaScript>

$(document).ready(function(){
	$.ajax({
		url: "http://rempic.com/weborder/lib/token.php",
		type: "post",
		cache: false,
		success: function (htmlStr){
			$( "#token" ).val( htmlStr );
		}
	});
});


function checkCheckBox(f){

var amt = f.size.value*f.qty.value;
if (f.agree.checked == false )
{
alert('Please check the box to continue.');
return false;
}else{
return true;
}
}
//-->


//validation for number only quantity and phone number
$('.qty').keypress(function (event) {
    var keycode = event.which;
    if (!(event.shiftKey == false && (keycode == 46 || keycode == 8 || keycode == 37 || keycode == 39 || (keycode >= 48 && keycode <= 57)))) {
        event.preventDefault();
    }
});


$('.phno').keypress(function (event) {
    var keycode = event.which;
    if (!(event.shiftKey == false && (keycode == 46 || keycode == 8 || keycode == 37 || keycode == 39 || (keycode >= 48 && keycode <= 57)))) {
        event.preventDefault();
    }
});
 </SCRIPT>
   <script>
	$('.sub').click(function(){
    $('html, body').animate({
        scrollTop: $('.form-container').offset().top
    }, 1000);
});
    </script>
 