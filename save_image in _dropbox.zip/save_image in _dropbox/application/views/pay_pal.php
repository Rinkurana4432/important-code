<!DOCTYPE html>
<html >
  <head>
   <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
       <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/payment.css">
    <title>Payment Info</title>
	<Style>
.dds {
    border-bottom: 1px solid #ddd;
    color: #e43b96;
    font-size: 27px;
    margin: 10% auto 0;
    text-align: center;
}
	.dtil{
	color: #9d9d9d;
    display: block;
    font-size: 14px;
    margin-left: 3px;
    margin-top: 18px !important;
	}
	button.paypal {
    margin-left: 7px !important;
    margin-top: 7px !important;
   
}
#dropin-container
{
	margin: 10px !important;
	padding: 20px !important;
	background: #fff;
}
.top_hed{
	  background: #000 none repeat scroll 0 0;
    border-radius: 5px 5px 0 0;
    color: #fff;
    font-size: 22px;
    margin: 0 auto;
    padding: 10px 0px;
    text-align: center;
}
.payment-method-options{display:none !important;}  



	</style>
  </head>
   

  <body>
  <!--start header-->
		<div style="display:none;" class="header header-main">
			<div class="inner">
			<div class="logo-container">
					<div class="logo">
					<a class="navigateTo" href="http://rempic.com/" title="REMPIC Mobile App"><img  src="<?php echo base_url(); ?>img/logo.png" alt="REMPIC Mobile App"></a>
				</div>
			</div>            
			
			<!--mobileMenu toggle-->
			<div class="mobileMenuToggle"><a href=""></a></div>
	    </div>
		
	</div>
	<!--end header-->

      <div class="main-container" > 
	<div class="section-title dds">Payment Detail<br>
	  <span class="dtil">Please enter you card details</span>
   </div>	  
	 <div class="form-container" style=" margin-top: 13%;">
    <?php
//$token = file_get_contents('http://rempic.com/weborder/lib/token.php');
?>
<?php

$amt= $_POST['size'];
$qty= $_POST['qty'];

$amount = $amt*$qty;
?>
<div class="top_hed">Payment Detail</div>
<div id="dropin-container"></div>
<form method="post" id="checkout-form" action="http://rempic.com/weborder/lib/client_token.php">
  <input type='hidden' name="amount" value='<?php echo $amount; ?>'/>
  <input type='hidden' name="image_name" value='<?php echo "https://www.dropbox.com/home/Apps/test_new?preview=".$_POST['image_name']; ?>'/>
  <input type='hidden' name="cust_name" value='<?php echo $_POST['fname']; ?>'/>
  <input type='hidden' name="cust_email" value='<?php echo $_POST['eaddress']; ?>'/>
  <input type='hidden' name="cust_add1" value='<?php echo $_POST['streetaddress1']; ?>'/>
  <input type='hidden' name="cust_add2" value='<?php echo $_POST['streetaddress2']; ?>'/>
  <input type='hidden' name="cust_state" value='<?php echo $_POST['state']; ?>'/>
  <input type='hidden' name="cust_city" value='<?php echo $_POST['city']; ?>'/>
  <input type='hidden' name="cust_country" value='<?php echo $_POST['country']; ?>'/>
  <input type='hidden' name="cust_postcode" value='<?php echo $_POST['postcode']; ?>'/>
  <input type='hidden' name="cust_phno" value='<?php echo $_POST['phnumber']; ?>'/>
  <input type='hidden' name="qty" value='<?php echo $_POST['qty']; ?>'/>
  <input type='hidden' name="size" value='<?php echo $_POST['size']; ?>'/>
  <input type='hidden' name="status" value='Completed'/>
  <input type='hidden' name="auth_code" value='qTydhseRwlvKufnMzx'/>
  <input type='submit'  value='Pay' class="ppay"/>
</form>	

<script src="https://js.braintreegateway.com/v2/braintree.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script>


braintree.setup(
    // Replace this with a client token from your server
    "<?php echo $_POST['token'];  ?>",
    "dropin", {
  container: "dropin-container",
  form: "checkout-form"
});

$(document).ready(function ()
{
	
$(function() {
    var intervalID = setInterval(function() {
		$(".payment-container").css("padding","10px"); 
		$(".payment-method-options").css("width","20%"); 
		$(".payment-method-options").css("margin","0 auto"); 

    }, 3000);
    setTimeout(function() {
        clearInterval(intervalID);
    }, 18000);
}); 
});
</script>
  </div> <!-- end of form-container -->
  </div>
  <div style="display:block;margin-top:18%;"></div>
  <div style="display: block; margin-top: 11%;" id="footer" >
	<div class="footer_content_wrapper">
		<div class="content">
						
			<!--div class="logo">
				<a title="REMPIC Mobile App" href="http://rempic.com" class="navigateTo"><img alt="REMPIC Mobile App" src="<?php //echo base_url();?>img/footer_logo.png"></a>
			</div-->
			<p class="copyright">©Signs By Knight | ABN 32 014 129 608 | <a href="http://rempic.com/terms-and-conditions/">Terms &amp; Conditions</a> | <a href="http://rempic.com/return-policy/">Shipping &amp; Returns</a> | <a href="http://rempic.com/privacy-policy/">Privacy Policy</a> | All Rights Reserved.</p>

			<!--social-->
			
		</div>
	</div>
</div>
<!--end footer-->
</body>

</html>
