<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Web Order</title>
<link rel="profile" href="http://gmpg.org/xfn/11">

<!-- up script and css-->
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
<script language="javascript" type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-1.7.1.min.js"></script>
<script language="javascript" type="text/javascript" src="<?php echo base_url(); ?>assets/js/script.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/style.css">
<!-- up script and css-->
</head>
<body class="home page page-id-8 page-template-default" >

<!--start wrapper-->
<div>

		
	<!--start header-->
		<div style="display: none;" class="header header-main">
			<div class="inner">
			<div class="logo-container">
					<div class="logo">
					<a class="navigateTo" href="http://rempic.com/" title="REMPIC Mobile App"><img src="<?php base_url(); ?>img/logo.png" alt="REMPIC Mobile App"></a>
				</div>
			</div>            
			
			<!--mobileMenu toggle-->
			<div class="mobileMenuToggle"><a href=""></a></div>
	    </div>
	</div>
	<!--end header-->


<div id="collections" class="section odd desktop">
<div class="content clearfix">

<div style="clear:both;"></div>

<div class="section-title" style="color:#E43B96;border-bottom: 1px solid #ddd;">Web Order</div>    
<div  class="teaser fixed-desktop mn_div" >
<div style="clear:both;"></div>
<div class="mn_div">
<div class="main">
		<form id="uploadForm"  method="post">
		
		<div id="dropbox" class="drop-area">
			<div class="uploadimage-text">Drag images here</div>
			<div style="color: #373737;font-size: 16px;">Or, if you prefer...</div>
			<input type="file" id="fileElem" name="the_upload" onchange="handleFiles(this.files);" > 
			
			</div>
			<div class="upload-progress"></div>
			<span id="msg"></span>
			
			
</form>


</div>
<div style="margin-top: 25%;"></div>
</div>
</div></div>
</div>


</div>        
<!--end wrapper--> 

<!--start footer-->
<div style="display: block; margin-top: 6%;padding-top: 28px;" id="footer">
	<div class="footer_content_wrapper">
		<div class="content">
						
			<!--div class="logo">
				<a title="REMPIC Mobile App" href="http://rempic.com" class="navigateTo"><img alt="REMPIC Mobile App" src="<?php //echo base_url();?>img/footer_logo.png"></a>
			</div-->
			<p class="copyright">©Signs By Knight | ABN 32 014 129 608 | <a href="http://rempic.com/terms-and-conditions/">Terms &amp; Conditions</a> | <a href="http://rempic.com/return-policy/">Shipping &amp; Returns</a> | <a href="http://rempic.com/privacy-policy/">Privacy Policy</a> | All Rights Reserved.</p>

			<!--social-->
			
		</div>
	</div>
</div>
<!--end footer-->
</body></html>
<script>
 $(document).ready(function (e) {
	 $("#uploadForm").on('submit',(function(e) {
		e.preventDefault();
		$("#msg").html(" ");
	  var file_value = $("#fileElem").val();
	  if(file_value != '' ){
		 
		//$("#container").css("display","block");
		$.ajax({
        	url: "<?php  echo base_url(); ?>index.php/welcome/index2",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
			dataType: "html",
			success: function(data)
			 {
				if(data == 6)
				{
					$("#msg").html("Your Image  size max 4 MB");
					setTimeout(function() { $("#msg").fadeOut(); }, 3000);
					$(".upload-progress").hide();	
                    setTimeout(function(){
					window.location.reload(1);
					}, 1000); 					
				}
				else if(data == 5)
				{
					$("#msg").html("No Image detected! Upload proper format<br>");
					setTimeout(function() { $("#msg").fadeOut(); }, 3000);
				    $(".upload-progress").hide();
                    setTimeout(function(){
					window.location.reload(1);
					}, 1000);					
				}
				else
			      {
					$("#msg").html("<p style='color:green'>Image Uploaded</p>");
					setTimeout(function() { $("#msg").fadeOut(); }, 3000);
					$('.upload-progress').fadeOut(1000);	
					$('.fileElem').val('');
/*                     setTimeout(function(){
					window.location.reload(1);
					}, 4000);	 */
                   window.location = "index.php/welcome/pay_ment";					
				}	
		    },
		  	error: function() 
	    	{
				
	    	} 
       
	   });
	 }else{
		 //$("#uploadForm").submit();
		// alert('asdf');
		
		// $("#msg").html("Please Upload Image First");
		//  $('#msg').show();
		// $('#msg').fadeOut(1000);
		
	 }
	
	}));
});
</script>
<script>
$(document).ready(function() {
	$(".drop-area").on('dragenter', function (e){
	e.preventDefault();
	$(this).css('background', '#BBD5B8');
	});

	$(".drop-area").on('dragover', function (e){
	e.preventDefault();
	});

	$(".drop-area").on('drop', function (e){
	$(this).css('background', '#D8F9D3');
	e.preventDefault();
	var image = e.originalEvent.dataTransfer.files;
	
	createFormData(image);
	});
});

function createFormData(image) {
	var formImage = new FormData();
	formImage.append('the_upload', image[0]);
	uploadFormData(formImage);
}

function uploadFormData(formData) {
	$.ajax({
	url: "<?php  echo base_url(); ?>index.php/welcome/index2",
	type: "POST",
	data: formData,
	contentType:false,
	cache: false,
	processData: false,
	success: function(data){
		if(data == 6)
				{
					$("#msg").html("Your Image  size max 4 MB");
					setTimeout(function() { $("#msg").fadeOut(); }, 3000);
					$(".upload-progress").hide();
                     $('.fileElem').val('');					
                    setTimeout(function(){
					window.location.reload(1);
					}, 1000); 					
				}
				else if(data == 5)
				{
					$("#msg").html("No Image detected! Upload proper format<br>");
					setTimeout(function() { $("#msg").fadeOut(); }, 3000);
				    $(".upload-progress").hide();
					$('.fileElem').val('');
                    setTimeout(function(){
					window.location.reload(1);
					}, 1000);					
				}
				else
				{
					$("#msg").html("<p style='color:green'>Image Uploaded</p>");
					setTimeout(function() { $("#msg").fadeOut(); }, 3000);
					$('.upload-progress').fadeOut(1000);	
					$('.fileElem').val('');
                    // setTimeout(function(){
					// window.location.reload(1);
					// }, 4000);	
                   window.location = "index.php/welcome/pay_ment";					
				}	
	}
});
}
</script>
