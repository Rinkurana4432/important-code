<!DOCTYPE html>
<html >
  <head>
   
       <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/payment.css">
   <title>Thank you</title>
 <style>  
.form-container2 {
    border-radius: 5px;
    margin: 0 auto;
    padding: 0 0 24px;
    text-align: center;
    width: 700px;
}


.btn_2 {
    background: #faac12 none repeat scroll 0 0;
    color: #fff;
	margin-left:5px;
    cursor: pointer;
    font-weight: 600;
    height: 38px;
    width: 30%;
}
</style>
  </head>


  <body>
  <!--start header-->
		<div style="display:none;" class="header header-main">
			<div class="inner">
			<div class="logo-container">
					<div class="logo">
					<a class="navigateTo" href="http://rempic.com/" title="REMPIC Mobile App"><img  src="<?php echo base_url(); ?>img/logo.png" alt="REMPIC Mobile App"></a>
				</div>
			</div>            
			
			<!--mobileMenu toggle-->
			<div class="mobileMenuToggle"><a href=""></a></div>
	    </div>
	</div>
	<!--end header-->
      <div class="main-container" style="margin-bottom: 24.9% !important;">    
	 <div class="form-container2">
	   <div class="cont_img">
       <!--img width=300 src="<?php// echo base_url(); ?>img/footer_logo.png"-->
	   <h2 style=" color: #47c6ed;font-size: 30px; margin-top:55%;">Thank you for your purchase</span></h2>
	   <h3 style="color:#c1c1c1;">You will shortly receive an email with your order information</span> </h3>
	   <div class="bbtnn">
	   <a href="http://google.com"><button class="btn_2">CONTACT REMPIC</button></a>
	    <a href="http://rempic.com/weborder/"> <button class="btn_2" style="background:#45C5ED;">RETURN TO HOME </button></a>
	  </div>         
	   </div>
  </div> <!-- end of form-container -->
  </div>
  <div style="display: block;" id="footer">  
	<div class="footer_content_wrapper">
		<div class="content">
						
			<!--div class="logo">
				<a title="REMPIC Mobile App" href="http://rempic.com" class="navigateTo"><img alt="REMPIC Mobile App" src="<?php //echo base_url();?>img/footer_logo.png"></a>
			</div-->
			
			<p class="copyright">©Signs By Knight | ABN 32 014 129 608 | <a href="http://rempic.com/terms-and-conditions/">Terms &amp; Conditions</a> | <a href="http://rempic.com/return-policy/">Shipping &amp; Returns</a> | <a href="http://rempic.com/privacy-policy/">Privacy Policy</a> | All Rights Reserved.</p>

			<!--social-->
			
		</div>
	</div>
</div>
<!--end footer-->
</body>

</html>

