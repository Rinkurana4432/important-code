<?php
namespace Braintree\MerchantAccount;

use Braintree\Instance;

final class AddressDetails extends Instance
{
    protected $_attributes = [];
}
class_alias('Braintree\MerchantAccount\AddressDetails', 'Braintree_MerchantAccount_AddressDetails');
