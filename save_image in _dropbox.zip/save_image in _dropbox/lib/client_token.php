<?php 

	header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: PUT, GET, POST");
    header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");


		
require_once $_SERVER['DOCUMENT_ROOT'].'/appadmin/webservice/application/libraries/Braintree.php';
    //echo $_SERVER['DOCUMENT_ROOT'];
Braintree_Configuration::environment('sandbox');
Braintree_Configuration::merchantId('2bwsjnfv7dspzjhm');
Braintree_Configuration::publicKey('fy33n889sjsvmgwd');
Braintree_Configuration::privateKey('209ebf759030ccb88398bd575804dfbf');
		
		
	
		// echo "<pre>";
		// print_r($_REQUEST);
		// echo "</pre>";
		
		
		
		$nonce = $_REQUEST["payment_method_nonce"];
		$amount = $_REQUEST["amount"];
		
	
		$result = Braintree_Transaction::sale(array(
			'amount' => $amount,
			'paymentMethodNonce' => $nonce,
			 'options' => array(
				'submitForSettlement' => true
				)
			));
		
		
		//echo $result;
		
		if ($result->success) {
		 header("Location: http://rempic.com/weborder/index.php/welcome/thank_you"); 
		
		exit();
		} else {
		  print_r($result->errors);
		}

	
	
	

/* End of file data.php */
/* Location: ./application/controllers/data.php */