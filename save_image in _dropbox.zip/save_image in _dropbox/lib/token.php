<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/appadmin/webservice/application/libraries/Braintree.php';

Braintree_Configuration::environment('sandbox');
Braintree_Configuration::merchantId('2bwsjnfv7dspzjhm');
Braintree_Configuration::publicKey('fy33n889sjsvmgwd');
Braintree_Configuration::privateKey('209ebf759030ccb88398bd575804dfbf');
$clientToken = Braintree_ClientToken::generate();

		echo $clientToken;

?>