<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include "wp-config.php";
include "wp-load.php";

$db = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

if (mysqli_connect_errno()){

    exit("Couldn't connect to the database: ".mysqli_connect_error());
}

$service = $_REQUEST['service_type'];

 
if(!empty($service))
{
	
	/************************ Check Delivery Options *******************************/	
	if( $service == 'deliveryoptions' )	
	{
		$table_name = 'wp_custom_delivery_options';
		$today_date = date('d-m-Y');
		$deliveryoptions = $wpdb->get_results( 'SELECT *,"5pm" as time FROM '.$table_name);

		$response = array(
						'Status' => 'true',
						'Data' => $deliveryoptions);

		echo json_encode($response);
		die();

	}
	
	/************************ Check Delivery Options *******************************/	
	if( $service == 'CheckpostDelivery' )	
	{
		
		if( !isset($_REQUEST['data']) || empty($_REQUEST['data']) ) { $response = array( 'Status' => 'false', 'error' => "data is Compulsory."); echo json_encode($response); die(); }		
		
		$table_name = 'wp_zone_lists';
		$table_name2 = 'wp_custom_delivery_options';

		$deliveryoptions = $wpdb->get_results( 'SELECT * FROM '.$table_name.' WHERE `postcode` = "'.$_REQUEST['data'].'" AND `suburb` = "'.$_REQUEST['suburb'].'" ' );
		
		if( $wpdb->num_rows > 0 ) {
			
			$chkcutoff = $wpdb->get_row( 'SELECT * FROM '.$table_name2.' WHERE city = "'.$deliveryoptions[0]->city.'" ' );
			
			$date1 = date_create($chkcutoff->cut_off_date);
			$date2 = date_create($chkcutoff->delivery_date);

			$diff = date_diff($date1,$date2);
			
			$customdata = array('deliverydays' => $diff->format("%a"));
			
			$response = array(
						'Status' => 'true',
						'Data' => $customdata);
		} else { 
			$response = array(
							'Status' => 'false',
							'error' => "we cant deliver in this suburb");		
		}
		echo json_encode($response);
		die();

	}	

	/************************ Check Delivery Postcode *******************************/	
	if( $service == 'checkpostcode_delivery' )	
	{
date_default_timezone_set('Australia/Sydney');
		$date = date("d-m-Y"); 
		$check_hour = date('h');
	$check_session = date('a');	
		if( !isset($_REQUEST['postcode']) || empty($_REQUEST['postcode']) ) { $response = array( 'Status' => 'false', 'error' => "postcode is Compulsory."); echo json_encode($response); die(); }
		
		if( !isset($_REQUEST['suburb']) || empty($_REQUEST['suburb']) ) { $response = array( 'Status' => 'false', 'error' => "suburb is Compulsory."); echo json_encode($response); die(); }		
		
		$table_name = 'wp_zone_lists';
		$table_name2 = 'wp_custom_delivery_options';

		$deliveryoptions = $wpdb->get_results( 'SELECT * FROM '.$table_name.' WHERE postcode = "'.$_REQUEST['postcode'].'" AND suburb = "'.$_REQUEST['suburb'].'" ' );
		
		if( $wpdb->num_rows > 0 ) {
			
			if( $deliveryoptions[0]->city == 'Adelaide' || $deliveryoptions[0]->city == 'Melbourne' || $deliveryoptions[0]->city == 'Brisbane' || $deliveryoptions[0]->city == 'Sydney' ) {
				$options = array( 'OVERNIGHT 12AM TO 7AM', 'DAYTIME 8AM TO 6PM' );
			} else {
				$options = array( 'OVERNIGHT 12AM TO 7AM', 'DAYTIME 8AM TO 6PM' );
			}
			
			$city = $deliveryoptions[0]->city;
			$chkcutoff = $wpdb->get_row( 'SELECT * FROM '.$table_name2.' WHERE city = "'.$city.'" ' );
			
			if( strtotime($chkcutoff->cut_off_date) >= strtotime($date) ) {

if( ( strtotime($chkcutoff->cut_off_date) == strtotime($date) ) && $check_hour >= 5 && $check_session == 'pm' ) {
$response = array(
							'Status' => 'false',
							'error' => "Sorry, orders have closed for your area. Orders will reopen for our next delivery date within the next few days!");
} else {

                               $response = array(
						'Status' => 'true',
						'Data' => "yes we can deliver",
						'options' => $options );
}
				
			} else {

				$response = array(
							'Status' => 'false',
							'error' => "Sorry, orders have closed for your area. Orders will reopen for our next delivery date within the next few days!");
			}
			
			
			
		} else { 
			$response = array(
							'Status' => 'false',
							'error' => "Sorry, we aren’t currently delivering to this area atm");		
		}
		echo json_encode($response);
		die();

	}	
	
	
	/************************ Order Creation *******************************/	
	if( $service == 'CreateOrder' )	
	{
		if( !isset($_REQUEST['first_name']) || empty($_REQUEST['first_name']) ) { $response = array( 'Status' => 'false', 'error' => "first_name is Compulsory."); echo json_encode($response); die(); }
		if( !isset($_REQUEST['last_name']) || empty($_REQUEST['last_name']) ) { $response = array( 'Status' => 'false', 'error' => "last_name is Compulsory."); echo json_encode($response); die(); }
		if( !isset($_REQUEST['email']) || empty($_REQUEST['email']) ) { $response = array( 'Status' => 'false', 'error' => "email is Compulsory."); echo json_encode($response); die(); }
		if( !isset($_REQUEST['street_no']) || empty($_REQUEST['street_no']) ) { $response = array( 'Status' => 'false', 'error' => "street_no is Compulsory."); echo json_encode($response); die(); }
		if( !isset($_REQUEST['address']) || empty($_REQUEST['address']) ) { $response = array( 'Status' => 'false', 'error' => "address is Compulsory."); echo json_encode($response); die(); }
		if( !isset($_REQUEST['suburb']) || empty($_REQUEST['suburb']) ) { $response = array( 'Status' => 'false', 'error' => "suburb is Compulsory."); echo json_encode($response); die(); }		
		if( !isset($_REQUEST['state']) || empty($_REQUEST['state']) ) { $response = array( 'Status' => 'false', 'error' => "state is Compulsory."); echo json_encode($response); die(); }		
		if( !isset($_REQUEST['postcode']) || empty($_REQUEST['postcode']) ) { $response = array( 'Status' => 'false', 'error' => "postcode is Compulsory."); echo json_encode($response); die(); }		
		if( !isset($_REQUEST['payment_method']) || empty($_REQUEST['payment_method']) ) { $response = array( 'Status' => 'false', 'error' => "payment_method is Compulsory."); echo json_encode($response); die(); } else {
			
			if( $_REQUEST['payment_method'] == 'paypal' ) {
				
				$payment_method_title = 'PayPal';
				$paypal_paymenttype = 'instant';
				$paypal_paymentstatus = 'completed';
			
			if( !isset($_REQUEST['transaction_id']) || empty($_REQUEST['transaction_id']) ) { $response = array( 'Status' => 'false', 'error' => "transaction_id is Compulsory."); echo json_encode($response); die(); } else { $transaction_id = $_REQUEST['transaction_id']; }				
				if( !isset($_REQUEST['payer_email']) || empty($_REQUEST['payer_email']) ) { $response = array( 'Status' => 'false', 'error' => "payer_email is Compulsory."); echo json_encode($response); die(); }
				if( !isset($_REQUEST['payerfirst_name']) || empty($_REQUEST['payerfirst_name']) ) { $response = array( 'Status' => 'false', 'error' => "payerfirst_name is Compulsory."); echo json_encode($response); die(); }
				if( !isset($_REQUEST['payer_last_name']) || empty($_REQUEST['payer_last_name']) ) { $response = array( 'Status' => 'false', 'error' => "payer_last_name is Compulsory."); echo json_encode($response); die(); }
				
			} else if( $_REQUEST['payment_method'] == 'stripe' ) {
				
				if( !isset($_REQUEST['stripe_card_id']) || empty($_REQUEST['stripe_card_id']) ) { $response = array( 'Status' => 'false', 'error' => "stripe_card_id is Compulsory."); echo json_encode($response); die(); }			
			}
			
		}	
		
		if( !isset($_REQUEST['prdsData']) || empty($_REQUEST['prdsData']) ) { $response = array( 'Status' => 'false', 'error' => "prdsData is Compulsory."); echo json_encode($response); die(); }			
		if( !isset($_REQUEST['amount']) || empty($_REQUEST['amount']) ) { $response = array( 'Status' => 'false', 'error' => "amount is Compulsory."); echo json_encode($response); die(); }			
		
		if( isset($_REQUEST['auth_code']) && !empty($_REQUEST['auth_code']) ) { 
			
			$check_authcode = $wpdb->get_row('SELECT * from `wp_sweetnector_authcode` where auth_code = "'.$_REQUEST['auth_code'].'"');
		    if($check_authcode > 0){
				$current_userid = $check_authcode->user_id;
				
				update_user_meta( $current_userid, 'billing_address_1', $_REQUEST['street_no']);
				update_user_meta( $current_userid, 'billing_address_2', $_REQUEST['address']);
				update_user_meta( $current_userid, 'billing_state', $_REQUEST['state']);
				update_user_meta( $current_userid, 'billing_postcode', $_REQUEST['postcode']);
				update_user_meta( $current_userid, 'billing_suburb', $_REQUEST['suburb']);
				update_user_meta( $current_userid, 'billing_phone', $_REQUEST['phone']);

			} else {
				$response = array( 'Status' => 'false', 'error' => "auth_code is Incorrect."); echo json_encode($response); die();
			}	
		} else {
			$current_userid = 0;
		}	
		
		$deliverydates = $wpdb->get_row('SELECT * from `wp_zone_lists` where postcode = "'.$_REQUEST['postcode'].'"');
		if( count( (array)$deliverydates ) > 0 ) {
			$city_name =  $deliverydates->city;
			
			$deliverydates_arry = $wpdb->get_row('SELECT * from `wp_custom_delivery_options` where city = "'.$city_name.'"');
			
			$finalisedelivery_date = $deliverydates_arry->delivery_date;
			
			if( $city_name == 'GC' || $city_name == 'Sunshine Coast' ) {
				$finalisedelivery_time = $_REQUEST['overnite_delivery'];	
			} else {
				$finalisedelivery_time = $_REQUEST['overnite_delivery'];
			}
		}	
			
			
		
		if( $_REQUEST['payment_method'] == 'stripe' ) {
			/*********************** Stripe Payment ***************************/		

			$amount = $_REQUEST['amount']*100;	
			$apiKey = 'sk_test_KHtRNB0BQUDIUdEH3ouzAhUm';
			$curl = curl_init();
			curl_setopt_array($curl, array(
				CURLOPT_RETURNTRANSFER => 1,
				CURLOPT_URL => "https://api.stripe.com/v1/charges",
				CURLOPT_POST => 1,
				CURLOPT_HTTPHEADER => array(
					"Authorization: Bearer " . $apiKey
				),
				CURLOPT_POSTFIELDS => http_build_query(array(
					"amount" => $amount,
					"currency" => 'AUD',
					"source" => $_REQUEST['stripe_card_id'],
					"description" => 'Stripe Payment from app'
				))
			));

			$resp = curl_exec($curl);
			curl_close($curl);
			$data_val = json_decode($resp, true);
			
			if($data_val['paid'] == 1){
				$stripe_charge_captured = 'yes';
				$stripe_charge_id = $data_val['id'];
				$stripe_card_id = $_REQUEST['stripe_card_id'];
				$payment_method_title = $data_val['source']['brand'];
				$transaction_id = $data_val['id'];
			} else {
				$response = array( 'Status' => 'false', 'error' => $data_val['error']['message']); echo json_encode($response); die();	
			}	

			/*********************** Stripe Payment ***************************/				
		}	
		
		
		
		
		$prds_array = json_decode(stripslashes($_REQUEST['prdsData']));
			
		$address = array(
					'first_name' => $_REQUEST['first_name'],
					'last_name'  => $_REQUEST['last_name'],
					'email'      => $_REQUEST['email'],
					'phone'      => $_REQUEST['phone'],
					'address_1'  => $_REQUEST['street_no'],
					'address_2'  => $_REQUEST['address'],
					'state'      => $_REQUEST['state'],
					'postcode'   => $_REQUEST['postcode'],
					'country'    => 'AU',
					'suburb'    => $_REQUEST['suburb'],
					);		
		
		

		
		$_product_qty = 0;
		//echo "<pre>"; print_r($prds_array); echo "</pre>";
		//echo "<pre>"; print_r($address); echo "</pre>"; die();
		
		$order = wc_create_order();	
			
		foreach($prds_array as $singleprodkey => $singleprodvalue ){
			foreach( $singleprodvalue as $key => $value ) {			
				$order->add_product( get_product($key), $value);
				$_product_qty = $_product_qty + $value;
			}	
		}	
			
		$boxes = $_product_qty / 6;
$cost = 0;
		/*if( $boxes == 1 || $boxes == 2 ) {
 
                        $cost = 0;
 
                    } else {
 						
			$leftboxes = $boxes - 2;
						
                        $cost = 0 + ( $leftboxes * 5 );
 
                    }	*/
		
		$order->set_address( $address, 'billing' );
		$order->set_address( $address, 'shipping' );

		$item = new WC_Order_Item_Shipping();
		$item->set_props( array(
							'method_title' => "Refrigerated Courier",
							'method_id'    => 'refrigerated',
							'total'        => wc_format_decimal( $cost ),
							'taxes'        => $rate->taxes,
							'order_id'     => $order->id,
						) );

		$order->add_item( $item );
		
		$order->calculate_totals(); 				

		$deliveryoptions = $wpdb->get_row( 'SELECT * FROM `wp_zone_lists` WHERE postcode = "'.$_REQUEST['postcode'].'" ' ); 
	
		if( count((array)$deliveryoptions) > 0) {
			$deliverydate = $wpdb->get_row( 'SELECT * FROM `wp_custom_delivery_options` WHERE city = "'.$deliveryoptions->city.'" ' ); 

			update_post_meta( $order->id, 'delivery_date', sanitize_text_field( $deliverydate->delivery_date ) );
			update_post_meta( $order->id, '_city_method', sanitize_text_field( $deliveryoptions->city ) );
		}		
		
		update_post_meta( $order->id, '_customer_user', $current_userid );
		update_post_meta( $order->id, 'My Field', sanitize_text_field( $_REQUEST['prdsData'] ) );
		update_post_meta( $order->id, 'Recipient Name', sanitize_text_field( $_REQUEST['recipients_name'] ) );
		update_post_meta( $order->id, 'Recipient Message', sanitize_text_field( $_REQUEST['recipients_msg'] ) );
		if( $_REQUEST['payment_method'] == 'paypal' ) {
			
			update_post_meta( $order->id, '_paypal_status', sanitize_text_field( $paypal_paymentstatus ) );
			update_post_meta( $order->id, 'Payment type', sanitize_text_field( $paypal_paymenttype ) );
			update_post_meta( $order->id, 'Payer last name', sanitize_text_field( $_REQUEST['payer_last_name'] ) );
			update_post_meta( $order->id, 'Payer first name', sanitize_text_field( $_REQUEST['payerfirst_name'] ) );
			update_post_meta( $order->id, 'Payer PayPal address', sanitize_text_field( $_REQUEST['payer_email'] ) );
			
		} elseif( $_REQUEST['payment_method'] == 'stripe' ) {
			
			update_post_meta( $order->id, '_stripe_card_id', sanitize_text_field( $stripe_card_id ) );
			update_post_meta( $order->id, '_stripe_charge_id', sanitize_text_field( $stripe_charge_id ) );
			update_post_meta( $order->id, '_stripe_charge_captured', sanitize_text_field( $stripe_charge_captured ) );
			
		}	
		update_post_meta( $order->id, '_payment_method', sanitize_text_field( $_REQUEST['payment_method'] ) );
		update_post_meta( $order->id, '_payment_method_title', sanitize_text_field( $payment_method_title ) );
		update_post_meta( $order->id, '_transaction_id', sanitize_text_field( $transaction_id ) );
		update_post_meta( $order->id, 'overnite_delivery', sanitize_text_field( $_REQUEST['overnite_delivery'] ) );
		
		$order = new WC_Order($order->id);
		
		if (!empty($order)) {
		
			if( isset($_REQUEST['orderNotes']) ) { $order->set_customer_note( $_REQUEST['orderNotes'] ); }
			
			$order->update_status( 'wc-processing' );
			
		}
		
		if( $current_userid > 0 ) {
		/**************for update billing address***************/
		update_user_meta( $current_userid, 'billing_city', $_REQUEST['city']);
		update_user_meta( $current_userid, 'billing_postcode', $_REQUEST['postcode']);
		update_user_meta( $current_userid, 'billing_address_1', $_REQUEST['street_no']);	
		update_user_meta( $current_userid, 'billing_address_2', $_REQUEST['address']);	
		/**************for update billing address***************/	
		}
		
		echo '{"Status":"true" , "Data":[{"result":"Order Created","Delivery Date":"'.$finalisedelivery_date.'","Delivery Time":"'.$finalisedelivery_time.'"}]}';
			
	}	
	
	
	
	
	
	
	
/************** Sign up****************/	
 if($service == 'signup')
 {
	  if(isset($_REQUEST['state']) && isset($_REQUEST['firstname']) && isset($_REQUEST['lastname']) && isset($_REQUEST['email']) && isset($_REQUEST['password']) && isset($_REQUEST['type']) && isset($_REQUEST['obj_id']) && isset($_REQUEST['sign_type']) && isset($_REQUEST['fb_id']) && isset($_REQUEST['accessToken'])) 
	 {
		
		$firstname=sanitize_text_field( $_REQUEST['firstname'] );
		$lastname=sanitize_text_field( $_REQUEST['lastname']);
		$username = sanitize_text_field(  $_REQUEST['email'] );
		$email = sanitize_text_field(  $_REQUEST['email']  );
		$state = sanitize_text_field(  $_REQUEST['state']  );
		$fb_token = sanitize_text_field(  $_REQUEST['accessToken']  );
		$password = $wpdb->escape( sanitize_text_field( $_REQUEST['password']));
		
		  /********************Get Signup user detail**********************/
		 $auth_code = md5(microtime().rand(0,9999));
		 
				$signup_user_detail['detail'][] = array(
				               'first_name' =>$firstname,
				               'last_name' =>$lastname,
				               'email' =>$email,
				               'phone' =>$address['billing_phone']['value'],
				               'street_no' =>'',
				               'address' =>'',
				               'suburb' =>'',
				               'state' =>$state,
				               'postcode' =>'',
							   'auth_code' =>$auth_code,
						      );		 
		 
		 
		$signup_user_json_data =  json_encode($signup_user_detail);
				
		/******************** Get Signup user detail**********************/
			 
		 if($_REQUEST['sign_type'] == 'fb'){
			$select_users = $wpdb->get_results('SELECT * FROM `wp_users` where user_email = "'.$_REQUEST['email'].'"');
				if($select_users[0]->user_email == $_REQUEST['email']){
					$check_objID = $wpdb->get_var('SELECT COUNT(*) from `wp_sweetnector_authcode` where obj_id = "'.$_REQUEST['obj_id'].'"');
	 				 if( $check_objID > 0 ){
					  $delete_objID = $wpdb->query('DELETE from `wp_sweetnector_authcode`  WHERE obj_id = "'.$_REQUEST['obj_id'].'"');
			 		}	
					//$auth_code = md5(microtime().rand(0,9999));
					$inser_authtokn = $wpdb->query('INSERT INTO `wp_sweetnector_authcode`(`user_id`, `auth_code`, `type`, `obj_id`) VALUES 		("'.$select_users[0]->ID.'","'.$auth_code.'","'.$_REQUEST['type'].'","'.$_REQUEST['obj_id'].'")');

					
					
					
			$load_address = sanitize_key( 'billing' );
			$address = WC()->countries->get_address_fields( get_user_meta( $select_users[0]->ID, $load_address . '_country', true ), $load_address . '_' ); 
			foreach ( $address as $key => $field ) {
			$value = get_user_meta( $select_users[0]->ID, $key, true );
			if ( ! $value ) {
				switch ( $key ) {
					case 'billing_email' :
					case 'shipping_email' :
						$value = $select_users[0]->user_email;
						break;
					case 'billing_country' :
					case 'shipping_country' :
						$value = WC()->countries->get_base_country();
						break;
					case 'billing_state' :
					case 'shipping_state' :
						$value = WC()->countries->get_base_state();
					break;
				}
			}

			$address[ $key ]['value'] = apply_filters( 'woocommerce_my_account_edit_address_field_value', $value, $key, $load_address );
				
				//print_r($address);die('sdf');
		}			 
			
			$countries = WC()->countries->get_allowed_countries();
			$current_cc  = WC()->checkout->get_value( 'billing_country' );
			$states      = WC()->countries->get_states( $current_cc );
			
				$account_data['detail'][] = array(
				               'first_name' =>$address['billing_first_name']['value'],
				               'last_name' =>$address['billing_last_name']['value'],
				               'email' =>$address['billing_email']['value'],
				               'phone' =>$address['billing_phone']['value'],
				               'street_no' =>$address['billing_address_1']['value'],
				               'address' =>$address['billing_address_2']['value'],
				               'suburb' =>get_user_meta( $select_users[0]->ID, 'billing_suburb', true ),
				               'state' =>$address['billing_state']['value'],
				               'postcode' =>$address['billing_postcode']['value'],
							   'auth_code' =>$auth_code,
						      );
			
			    
					
				/*****************************************/	
					
					
    $headers = 'From: Sweet Nectar <hello@sweetnectar.com.au>' . "\r\n";
    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
     
    $subject = 'New signup';
	
	$name = $address['billing_first_name']['value'].' '.$address['billing_last_name']['value'];	

    $message = '<html>
  <head>
 <link href="https://fonts.googleapis.com/css?family=Noto+Sans" rel="stylesheet">
<style>
.pic1
{
	width:200px;
	float:left;
}
.pic2{
	width:200px;
	float:left;
}
.pic4
{
	width:200px;
	float:left;
}
.pic5{
	width:200px;
	float:left;
}
tr,td{
	border:none;
}
button.btn.btn-default {
    background: #ec89bb;
    color: #fff;
    height: 50px;
    width: 200px;
	margin-bottom: 25px;
	border: none;
	margin-top: -42px;
}
.left
{
	width:295px;
	float:left;
	padding-bottom:20px;
}
.right
{
	width:300px;
	float:right;
	margin-top: 50px;
	
}
p.head {
    color:#ec89bb;
    font-size: 65px;
    text-align: left;
    padding-left: 30px;
	margin-top: 0px;
	opacity: 0.3;
}
</style>
  </head>
<body style="font-family: Pacifico !important;"> 
<table class="container" align="center" border="2px solid #000" cellpadding="0" cellspacing="0" width="100%" style="position:relative; text-align:center; max-width:600px;">
<tr style="text-align: center;border: none;">
<td style="border: none;"><a href="https://sweetnectar.com.au"><img src="https://sweetnectar.com.au/wp-content/uploads/2017/09/SN-logo.png" alt="" width="150" height="150" class="alignnone size-full wp-image-791"></td>
</tr>


<tr style="text-align: center;border: none;">
<td  class="head" style="font-weight: bold;font-family: Pacifico;font-size: 30px;margin-top: 100px;padding: 20px;border: none;">
<img src="https://sweetnectar.com.au/wp-content/uploads/2017/10/left.jpg" alt="" class="alignnone size-full wp-image-800" style="position:absolute;left:0px;margin-top: -18%; width: 20%;"><i>Welcome <strong>' . esc_html( $name ) . '</strong>!</i>
<img src="https://sweetnectar.com.au/wp-content/uploads/2017/10/right.jpg" alt="" class="alignnone size-full wp-image-801" style="position:absolute;right:0px;margin-top: -18%;width: 20%;"></td>

</tr>
<tr style="text-align: center;border: none;">
<td style="font-size: 15px;font-family: Open Sans;padding-top: 17%;border: none;">Your dessert dreams just came true. <br> We cant wait to feed you the sweet stuff!
<hr style="align=center; margin-left:250px; margin-right:250px;">
</td>
</tr>
<tr style="text-align: center;border: none;">
<td style="font-size: 20px;font-family: Open Sans;padding-top: 40px;padding-bottom: 0px;font-weight: bold;border: none;"><i>Ready to pick your six?</i></td>
</tr>
<tr style="border: none;">
<td style="text-align: right;padding-right: 100px;padding-top: 0px;border: none;"><img src="https://sweetnectar.com.au/wp-content/uploads/2017/09/arrw.jpg" alt="" width="92" height="108" class="alignnone size-full wp-image-803">
</td>
</tr>

<tr style="text-align: center;border: none;">
<td style="padding-bottom: 35px;border: none;"><a href="https://sweetnectar.com.au/#shop_my_box"><button type="button" class="btn btn-default" style="background: #ec89bb;color: #fff;height: 50px;width: 200px;margin-bottom: 25px;border: none;margin-top: -42px;">ORDER HERE</button></a></td>
</tr>



<tr style="text-align: center;border: none;">
<td style="border: none;">
<hr style="align=center; margin-left:30px; margin-right:30px; margin-top:30px;margin-bottom: 20px;">
<a href="https://www.instagram.com/sweetnectardesserts/"><img src="https://sweetnectar.com.au/wp-content/uploads/2017/09/social2.jpg" alt="" width="57" height="53" class="alignnone size-full wp-image-798"></a>
<a href="https://www.facebook.com/sweetnectardesserts"><img src="https://sweetnectar.com.au/wp-content/uploads/2017/09/social1.jpg" alt="" width="57" height="53" class="alignnone size-full wp-image-797"></a>
<hr style="align=center; margin-left:30px; margin-right:30px; margin-top:30px;margin-bottom: 20px;">
</td>

</tr>
<tr style="text-align: center;line-height: 1;border: none;">
<td style="border: none;">
</td>
</tr>


</table>
  </body>
</html>';  

    $response = wp_mail( $address['billing_email']['value'], $subject, $message, $headers );					
					
					
				/****************************************/	
					
				//$all_data = array_merge( (array)$account_data, (array)$get_product_img );
				//$all_data = array_merge($account_data, $get_product_img);
				 
				$ddd =  json_encode($account_data);
				echo '{"Status":"true","Data":'.$ddd.'}';					
					
				die();	
					
			}else{
			    $select_identifier = $wpdb->get_var('SELECT ID FROM `wp_social_users` WHERE type = "fb" AND identifier = "'.$_REQUEST['fb_id'].'" ');
	  	    if($select_identifier == '' ){
				 $wpdb->query($wpdb->prepare('DELETE FROM wp_social_users WHERE ID = %d AND type = \'fb\'', $_REQUEST['fb_id']));
			  	 $status = wp_create_user($username,$password,$email);
				 $insert_fb_data = $wpdb->query('INSERT INTO `wp_social_users`(`ID`, `type`, `identifier`) VALUES ("'.$status.'","'.$_REQUEST['sign_type'].'","'.$_REQUEST['fb_id'].'")');
				update_user_meta($status, 'fb_user_access_token', $_REQUEST['accessToken']);
				//$status = wp_create_user($username,$password,$email);
			 } 
		}
	}
			 
		else { 
			  $status = wp_create_user($username,$password,$email);
		  }
		 
		 
		 
		if($status->errors['existing_user_login'][0]){
			echo '{"Status":"false","error":"Sorry, that email already exists!"}';
		  }elseif($status->errors['existing_user_email'][0]){
			echo '{"Status":"false","error":"Sorry, that email address is already used!"}';
		}else{
			$user_id=$status;
			update_user_meta( $user_id, 'first_name', $firstname);
			update_user_meta( $user_id, 'last_name', $lastname);
			update_user_meta( $user_id, 'billing_first_name', $firstname);
       		update_user_meta( $user_id, 'billing_last_name', $lastname);
       		update_user_meta( $user_id, 'billing_state', $state);
       		update_user_meta( $user_id, 'billing_email', $email);
       		
 			$reg_phone = 0;
			update_user_meta( $user_id, 'billing_phone', $reg_phone );
			
			//$auth_code = md5(microtime().rand(0,9999));
			$inser_authtokn = $wpdb->query('INSERT INTO `wp_sweetnector_authcode`(`user_id`, `auth_code`, `type`, `obj_id`) VALUES ("'.$user_id.'","'.$auth_code.'","'.$_REQUEST['type'].'","'.$_REQUEST['obj_id'].'")');
			

				/*****************************************/	
					
					
    $headers = 'From: Sweet Nectar <hello@sweetnectar.com.au>' . "\r\n";
    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
     
    $subject = 'New signup';
	
	$name = $firstname.' '.$lastname;	

    $message = '<html>
  <head>
 <link href="https://fonts.googleapis.com/css?family=Noto+Sans" rel="stylesheet">
<style>
.pic1
{
	width:200px;
	float:left;
}
.pic2{
	width:200px;
	float:left;
}
.pic4
{
	width:200px;
	float:left;
}
.pic5{
	width:200px;
	float:left;
}
tr,td{
	border:none;
}
button.btn.btn-default {
    background: #ec89bb;
    color: #fff;
    height: 50px;
    width: 200px;
	margin-bottom: 25px;
	border: none;
	margin-top: -42px;
}
.left
{
	width:295px;
	float:left;
	padding-bottom:20px;
}
.right
{
	width:300px;
	float:right;
	margin-top: 50px;
	
}
p.head {
    color:#ec89bb;
    font-size: 65px;
    text-align: left;
    padding-left: 30px;
	margin-top: 0px;
	opacity: 0.3;
}
</style>
  </head>
<body style="font-family: Pacifico !important;"> 
<table class="container" align="center" border="2px solid #000" cellpadding="0" cellspacing="0" width="100%" style="position:relative; text-align:center; max-width:600px;">
<tr style="text-align: center;border: none;">
<td style="border: none;"><img src="https://sweetnectar.com.au/wp-content/uploads/2017/09/SN-logo.png" alt="" width="150" height="150" class="alignnone size-full wp-image-791"></td>
</tr>


<tr style="text-align: center;border: none;">
<td  class="head" style="font-weight: bold;font-family: Pacifico;font-size: 30px;margin-top: 100px;padding: 20px;border: none;">
<img src="https://sweetnectar.com.au/wp-content/uploads/2017/09/side1.jpg" alt="" width="117" height="263" class="alignnone size-full wp-image-800" style="position:absolute;left:0px;margin-top: -18%;"><i>Welcome <strong>' . esc_html( $name ) . '</strong>!</i>
<img src="https://sweetnectar.com.au/wp-content/uploads/2017/09/side2.jpg" alt="" width="117" height="263" class="alignnone size-full wp-image-801" style="position:absolute;right:0px;margin-top: -18%;"></td>

</tr>
<tr style="text-align: center;border: none;">
<td style="font-size: 15px;font-family: Open Sans;padding-top: 17%;border: none;">Your dessert dreams just came true. <br> We cant wait to feed you the sweet stuff!
<hr style="align=center; margin-left:250px; margin-right:250px;">
</td>
</tr>
<tr style="text-align: center;border: none;">
<td style="font-size: 20px;font-family: Open Sans;padding-top: 40px;padding-bottom: 0px;font-weight: bold;border: none;"><i>Ready to pick your six?</i></td>
</tr>
<tr style="border: none;">
<td style="text-align: right;padding-right: 100px;padding-top: 0px;border: none;"><img src="https://sweetnectar.com.au/wp-content/uploads/2017/09/arrw.jpg" alt="" width="92" height="108" class="alignnone size-full wp-image-803">
</td>
</tr>

<tr style="text-align: center;border: none;">
<td style="padding-bottom: 35px;border: none;"><a href="https://sweetnectar.com.au/#shop_my_box"><button type="button" class="btn btn-default" style="background: #ec89bb;color: #fff;height: 50px;width: 200px;margin-bottom: 25px;border: none;margin-top: -42px;">ORDER HERE</button></a></td>
</tr>



<tr style="text-align: center;border: none;">
<td style="border: none;">
<img src="https://sweetnectar.com.au/wp-content/uploads/2017/09/social2.jpg" alt="" width="57" height="53" class="alignnone size-full wp-image-798">
<img src="https://sweetnectar.com.au/wp-content/uploads/2017/09/social1.jpg" alt="" width="57" height="53" class="alignnone size-full wp-image-797">
<hr style="align=center; margin-left:30px; margin-right:30px; margin-top: 15px;margin-bottom: 20px; opacity: 0.3;">
</td>

</tr>
<tr style="text-align: center;line-height: 1;border: none;">
<td style="border: none;">
<div class="row">
<div class="left" style="width: 295px;float: left;padding-bottom: 20px;">
<p class="head" style="color: #ec89bb;font-size: 65px;text-align: left;padding-left: 30px;margin-top: 0px;opacity: 0.3;">P.S</p>
<p style="margin-left: 30px; margin-top: -50px;text-align: left;margin-bottom: 0px; font-family: Noto Sans, sans-serif;font-size: 14px;    line-height: 21px;">To keep Up to date with new flavors make sure you download our app available for android & iphone "Sweet Nectar" as a user of th app you can also be in the running to win competitions & receive instant updates when your goodless are on their way!</p>
<img src="https://sweetnectar.com.au/wp-content/uploads/2017/09/appstore.png" alt="" width="100" height="100" class="alignnone size-full wp-image-825" style="margin-left: -15%;">
<img src="https://sweetnectar.com.au/wp-content/uploads/2017/09/app1.png" alt="" width="100" height="100" class="alignnone size-full wp-image-813">
<p style="font-size:20px; margin-top: -5px; margin-left: -20%; font-weight:bold; font-family:open sans;">Sweet Nectar Team:)</p>
 </div><!--left-->
<div class="right" style="width: 300px;float: right;margin-top: 50px;">
<img src="https://sweetnectar.com.au/wp-content/uploads/2017/09/mobile.png" alt="" width="263" height="405" class="alignnone size-full wp-image-820">
</div><!--right-->
</div><!--row-->
</td>
</tr>


</table>
  </body>
</html>';  
			

   	$response = wp_mail( $email, $subject, $message, $headers );					
					
					
				/****************************************/				
			
			
		//echo '{"Status":"true", "Data":[{"auth_code":"'.$auth_code.'","first_name":"'.$firstname.'"}]}';
		echo '{"Status":"true","Data":'.$signup_user_json_data.'}';
		}
		 
		
 }else{
	 echo '{"Status":"false","error":"Some Error Occured."}';
	 }
 }
	
	
/*******************LOGIN*********************/
	if($service == 'login')
	{
	if(isset($_REQUEST['user_login']) || isset($_REQUEST['user_email']) && isset($_REQUEST['user_pass']) && isset($_REQUEST['type']) && isset($_REQUEST['obj_id']) ) {
		
		 $user = wp_authenticate($_REQUEST['user_email'],$_REQUEST['user_pass']);
		
		$current_user_login = $user->data->ID;
		
		
		
		/******************For getiing user dtail********************/
		$load_address = sanitize_key( 'billing' );
			$address = WC()->countries->get_address_fields( get_user_meta( $current_user_login, $load_address . '_country', true ), $load_address . '_' ); 
			foreach ( $address as $key => $field ) {
			$value = get_user_meta( $current_user_login, $key, true );
			if ( ! $value ) {
				switch ( $key ) {
					case 'billing_email' :
					case 'shipping_email' :
						$value = $current_user->user_email;
						break;
					case 'billing_country' :
					case 'shipping_country' :
						$value = WC()->countries->get_base_country();
						break;
					case 'billing_state' :
					case 'shipping_state' :
						$value = WC()->countries->get_base_state();
					break;
				}
			}

			$address[ $key ]['value'] = apply_filters( 'woocommerce_my_account_edit_address_field_value', $value, $key, $load_address );
				
				//print_r($address);die('sdf');
		}			 
			
			$countries = WC()->countries->get_allowed_countries();
			$current_cc  = WC()->checkout->get_value( 'billing_country' );
			$states      = WC()->countries->get_states( $current_cc );
			$auth_code = md5(microtime().rand(0,9999));
		
				$user_detail['detail'][] = array(
				               'first_name' =>$address['billing_first_name']['value'],
				               'last_name' =>$address['billing_last_name']['value'],
				               'email' =>$address['billing_email']['value'],
				               'phone' =>$address['billing_phone']['value'],
				               'street_no' =>$address['billing_address_1']['value'],
				               'address' =>$address['billing_address_2']['value'],
				               'suburb' =>get_user_meta( $current_user_login, 'billing_suburb', true ),
				               'state' =>$address['billing_state']['value'],
				               'postcode' =>$address['billing_postcode']['value'],
					 			'auth_code' => $auth_code,
						      );		
		

		/******************For getiing user dtail********************/
	 if(isset($user->data)){
			
			 $check_objID = $wpdb->get_var('SELECT COUNT(*) from `wp_sweetnector_authcode` where obj_id = "'.$_REQUEST['obj_id'].'"');
			 
			 //print_r($check_objID);die();
			 
			 if( $check_objID > 0 ){
			  $delete_objID = $wpdb->query('DELETE from `wp_sweetnector_authcode`  WHERE obj_id = "'.$_REQUEST['obj_id'].'"');
			 }
			 $inser_authtokn = $wpdb->query('INSERT INTO `wp_sweetnector_authcode`(`user_id`, `auth_code`, `type`, `obj_id`) VALUES ("'.$user->data->ID.'","'.$auth_code.'","'.$_REQUEST['type'].'","'.$_REQUEST['obj_id'].'")');
			 
	 }
		
		if(isset($user->errors['invalid_email'][0])){
			echo '{"Status":"false","error":"Invalid Email"}';
			}
			elseif(isset($user->errors['incorrect_password'][0])){
				echo '{"Status":"false","error":"Invalid Password"}';
				}
			elseif(isset($user->errors['empty_password'][0])){
			echo '{"Status":"false","error":"The password field is empty"}';
				}else{
				//echo '{"Status":"true", "Data":[{"result":"'.$d_detail.'"}]}';
				$ddd =  json_encode($user_detail);
				
				echo '{"Status":"true","Data":'.$ddd.'}';
			}
		}else
		{
		echo '{"Status":"false","error":"Some Error Occured."}';
		}
	}		
	
	
	/******************GET ALL PRODUCT*******************/
	if($service == 'get_product')
	{
		 $args = array(
			    'post_type' => 'product',
			    'stock' => 1,
			    'posts_per_page' => 9,
			    'orderby' =>'date',
			    'order' => 'DESC' );
			    $loop = new WP_Query( $args );
			while ( $loop->have_posts() ) : $loop->the_post(); global $product; 
		    $attr = get_post_meta($product->id, '_product_attributes' );
		    $my_meta = get_post_meta( $product->id, 'dryfruit', true );
	
	//print_r($my_meta);

		
		//to get calories etc
		foreach($attr[0] as  $brdnewattr){ 
			
			$prod_options[$brdnewattr['name']] = $brdnewattr['value'];
		}
		$ingredients = explode(',',$prod_options['Ingredients']);
		$post_thumbnail_id = get_post_thumbnail_id($post->ID);
		$post_thumbnail_url = wp_get_attachment_url( $post_thumbnail_id );
		
		$content_all =  get_the_content();

		$regex = '#<span style="(.+?)">(.+?)</span>#';
		if (strpos($content_all, 'span') !== false) {
			preg_match($regex, $content_all, $groups);
			
			$contttt = 	$groups[2];
		} else {
			$contttt = 	$content_all;
		}	
		
	$array[] = array(
            'id' => get_the_ID(),
            'title' => get_the_title(),
			'img' => $post_thumbnail_url,
			'Calories' => $prod_options['Calories'],
			'Protein (g)' => $prod_options['Protein (g)'],
			'Sugars (g)' => $prod_options['Sugars (g)'],
			'Carbs (g)' => $prod_options['Carbs (g)'],
			'Ingredients' => $ingredients,
			'Notes' => $contttt,
		    'Type' => $my_meta,
           );
		
		
	   	   endwhile;
		
		echo json_encode($array);
		
		
		wp_reset_query();
      
	}
	
/*****************Get Account Detail*************************/
	
	if($service == 'get_account_detail'){
		if(isset($_REQUEST['auth_code'])){
		$check_authcode = $wpdb->get_row('SELECT * from `wp_sweetnector_authcode` where auth_code = "'.$_REQUEST['auth_code'].'"');
		if($check_authcode > 0){
		$current_user_login =  $check_authcode->user_id;
			//echo $user_id = get_current_user_id($current_user_login);
			//die('sdf');
			//get_current_user_id();
			$load_address = sanitize_key( 'billing' );
			$address = WC()->countries->get_address_fields( get_user_meta( $current_user_login, $load_address . '_country', true ), $load_address . '_' ); 
			foreach ( $address as $key => $field ) {
			$value = get_user_meta( $current_user_login, $key, true );
			if ( ! $value ) {
				switch ( $key ) {
					case 'billing_email' :
					case 'shipping_email' :
						$value = $current_user->user_email;
						break;
					case 'billing_country' :
					case 'shipping_country' :
						$value = WC()->countries->get_base_country();
						break;
					case 'billing_state' :
					case 'shipping_state' :
						$value = WC()->countries->get_base_state();
					break;
				}
			}

			$address[ $key ]['value'] = apply_filters( 'woocommerce_my_account_edit_address_field_value', $value, $key, $load_address );
				
				//print_r($address);die('sdf');
		}			 
			
			$countries = WC()->countries->get_allowed_countries();
			$current_cc  = WC()->checkout->get_value( 'billing_country' );
			$states      = WC()->countries->get_states( $current_cc );
			
				$account_data['detail'][] = array(
				               'first_name' =>$address['billing_first_name']['value'],
				               'last_name' =>$address['billing_last_name']['value'],
				               'email' =>$address['billing_email']['value'],
				               'phone' =>$address['billing_phone']['value'],
				               'street_no' =>$address['billing_address_1']['value'],
				               'address' =>$address['billing_address_2']['value'],
				               'suburb' =>get_user_meta( $current_user_login, 'billing_suburb', true ),
				               'state' =>$address['billing_state']['value'],
				               'postcode' =>$address['billing_postcode']['value'],
						      );
			
			    
				//$all_data = array_merge( (array)$account_data, (array)$get_product_img );
				//$all_data = array_merge($account_data, $get_product_img);
				 
				$ddd =  json_encode($account_data);
				echo '{"Status":"true","Data":'.$ddd.'}';
				
			
		}else{
			echo '{"Status":"false" , "Data":[{"result":"authcode expired"}]}';			
			die();		
		}
		
		}	
	
	}
/*******************user history********************/
	
	if($service == 'order_history'){
		if(isset($_REQUEST['auth_code'])){
		$check_authcode = $wpdb->get_row('SELECT * from `wp_sweetnector_authcode` where auth_code = "'.$_REQUEST['auth_code'].'"');
		if($check_authcode > 0){
			$current_user_login =  $check_authcode->user_id;
			$customer_orders = get_posts( apply_filters( 'woocommerce_my_account_my_orders_query', array(
					'numberposts' => $order_count,
					'meta_key'    => '_customer_user',
					'meta_value'  => $current_user_login,//get_current_user_id()
					'post_type'   => wc_get_order_types( 'view-orders' ),
					'post_status' => array_keys( wc_get_order_statuses() ),
				) ) );
				
				  foreach($customer_orders as $cust_order){ 
				  	//print_r($cust_order);
					  $yrdata= strtotime($cust_order->post_date);
					  $order_date = date('d-M-y', $yrdata);
				      $time =  $cust_order->post_date;
				      $time_new = date("d.m.y h:i a",strtotime($time));
					  $img_array = array();
					  $order_items = json_decode(stripslashes(get_post_meta( $cust_order->ID, 'My Field', true )));
					  if( count( (array)$order_items ) > 0 ) {
					  foreach ( $order_items as $sing_box => $items ) {
							foreach( $items as $sing_itemskey => $sing_itemsvalue ) {
								$image = wp_get_attachment_image_src( get_post_thumbnail_id( $sing_itemskey ), 'thumbnail' );
								
								for($i=0; $i < $sing_itemsvalue; $i++) {
									$img_array[$sing_box][] = $image[0]; 
								}
							}	
					  }	
					  } else {
						  $img_array = array();
					  }	  
					  
				/*$order = new WC_Order( $cust_order->ID );
				$items = $order->get_items();
				
					  
				print_r($items); die('adsf');
					  
				//for prduct image
				foreach($items as $item){
					//print_r($item);						
				 $product_name = $item['name'];
    			 $product_id = $item['product_id'];
    			 $product_qty = $item['quantity'];
    			 $order_id = $item['order_id'];
					
				 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $product_id ), 'single-post-thumbnail' );
				
				 for($i=0; $i < $product_qty; $i++) {
					$img_array[] = $image[0]; 
				 
					}
					
				}*/
					  
					  $get_product_img['orders'][] = array(
				          'order_id' =>  $cust_order->ID,
				          'order_date' =>  $order_date,
				          'order_time' =>  $time_new,
						  'post_status'=>wc_get_order_status_name( $cust_order->post_status ),
						  'images'=>$img_array,
				    	);
			  }	
		
			
				if(!empty($get_product_img)){
					$order_history =  json_encode($get_product_img);
					echo '{"Status":"true","Data":'.$order_history.'}';
				}else{
				echo '{"Status":"false" , "Data":[{"result":"NO order Available"}]}';
				
				}
		
		
		}else{
		    echo '{"Status":"false" , "Data":[{"result":"authcode expired"}]}';			
			die();
		}
	
	
	}
	
	}	
	
	
/*******************user history********************/	

	
	/*******************Add to cart********************/
	
	if($service == 'create_order'){
		if(isset($_REQUEST['auth_code']) && isset($_REQUEST['products']) && isset($_REQUEST['address_1']) && isset($_REQUEST['city']) && ($_REQUEST['postcode']) && isset($_REQUEST['amount'])  && isset($_REQUEST['stripeToken']) && isset($_REQUEST['description'])  && isset($_REQUEST['payment_type'])  ){
		 $check_authcode = $wpdb->get_row('SELECT * from `wp_sweetnector_authcode` where auth_code = "'.$_REQUEST['auth_code'].'"');
		    if($check_authcode > 0){
				/*************Get delivery date****************/
				$check_pincode = $wpdb->get_row('SELECT * from `wp_check_pincode_p` where pincode = "'.$_REQUEST['postcode'].'"');
				if($check_pincode > 0){
				$curr_date =  date('d-m-Y');
				$check_pincode = $wpdb->get_row('SELECT * from `wp_check_pincode_p` where pincode = "'.$_REQUEST['postcode'].'"');
					
			
					
				$days = '+'.$check_pincode->dod.' day';
					
	            $dd_td =  date('d-m-Y', strtotime($days, strtotime($curr_date)));
					
				
					
				$getday = date('l', strtotime($dd_td)); 
				
					
					
				$all_days = explode(',',$check_pincode->delivery_days);
				
				 $count_array_all_days = count($all_days);
				
					
				 $key = array_search($getday, $all_days) + 0; 
					
					
				
				if( $key == $count_array_all_days )
				{
					$inc = 0;	
				} else {
					$inc = $key;
				}	
       
				$nxt_dy =   'next'.' '.$all_days[$inc];
					
					
					
				$delivery_date =  date('d-m-Y', strtotime($nxt_dy, strtotime($dd_td)));
					
					//print_r($delivery_date);die('yes');
					
					
					
					
				/*************Get delivery date****************/
				
				if($_REQUEST['payment_type'] == 'paypal'){
				$prods = $_REQUEST['products'];
				$data_prod = json_decode(stripslashes($prods), true);
				$product_value_count =  array_sum($data_prod);
				
				if($product_value_count != 6){
				echo '{"Status":"false" , "Data":[{"result":"Please Check your product quantity"}]}';	
				}
				$current_user_login =  $check_authcode->user_id;	
				$userInfo = get_user_meta($current_user_login);	
					
					//print_r($current_user_login);die('yes');
					
				$address = array(
						'first_name' => $userInfo['first_name'][0],
						'last_name'  => $userInfo['last_name'][0],
						'email'      => $userInfo['nickname'][0],
						'address_1'  => $_REQUEST['address_1'],
						'address_2'  => $_REQUEST['address_2'],
						'state'      => $_REQUEST['state'],
						'postcode'   => $_REQUEST['postcode'],
						'country'    => 'AU'
						);
				//print_r($address);die('asdfas');	
				$order = wc_create_order();
				foreach($data_prod as $prod_id=>$prd_val){
				$order->add_product( get_product($prod_id), $prd_val);
				}
			  $order->set_address( $address, 'billing' );
			  $order->set_address( $address, 'shipping' );
			  WC()->shipping->calculate_shipping( WC()->cart->get_shipping_packages() );

				// Get the rate object selected by user    for add shipping.
				foreach ( WC()->shipping->get_packages() as $package_key => $package ) {
					foreach ( $package['rates'] as $key => $rate ) {
						$item = new WC_Order_Item_Shipping();
							$item->set_props( array(
										'method_title' => $rate->label,
										'method_id'    => $rate->id,
										'total'        => wc_format_decimal( $rate->cost ),
										'taxes'        => $rate->taxes,
										'order_id'     => $order->id,
									) );
						foreach ( $rate->get_meta_data() as $key => $value ) {
										$item->add_meta_data( $key, $value, true );
									}

						$order->add_item( $item );
					}
				}	  			
			    $order->calculate_totals(); 				
			    update_post_meta( $order->id, '_customer_user', $current_user_login );
				$order = new WC_Order($order->id);
				if (!empty($order)) {
					$order->set_customer_note( $_REQUEST['order_notes'] );
					$order->update_status( 'wc-processing' );
				}
				/**************for update billing address***************/
       			update_user_meta( $current_user_login, 'billing_city', $_REQUEST['city']);
       			update_user_meta( $current_user_login, 'billing_postcode', $_REQUEST['postcode']);
       			update_user_meta( $current_user_login, 'billing_address_1', $_REQUEST['address_1']);	
				/**************for update billing address***************/		
				echo '{"Status":"true" , "Data":[{"result":"Order Created","del_date":"'.$delivery_date.'"}]}';
				}else{
					$amount = $_REQUEST['amount']*100;	
					$apiKey = 'sk_test_KHtRNB0BQUDIUdEH3ouzAhUm';
					$curl = curl_init();
					curl_setopt_array($curl, array(
						CURLOPT_RETURNTRANSFER => 1,
						CURLOPT_URL => "https://api.stripe.com/v1/charges",
						CURLOPT_POST => 1,
						CURLOPT_HTTPHEADER => array(
							"Authorization: Bearer " . $apiKey
						),
						CURLOPT_POSTFIELDS => http_build_query(array(
							"amount" => $amount,
							"currency" => 'AUD',
							"source" => $_REQUEST['stripeToken'],
							"description" => $_REQUEST['description']
						))
					));
					
					$resp = curl_exec($curl);
					curl_close($curl);
					$data_val = json_decode($resp, true);
					
					if($data_val['paid'] == 1){
					$prods = $_REQUEST['products'];
					$data_prod = json_decode(stripslashes($prods), true);
					$product_value_count =  array_sum($data_prod);
					if($product_value_count != 6){
					echo '{"Status":"false" , "Data":[{"result":"Please Check your product quantity"}]}';	
					}

					$current_user_login =  $check_authcode->user_id;	
					$userInfo = get_user_meta($current_user_login);	
					$address = array(
						'first_name' => $userInfo['first_name'][0],
						'last_name'  => $userInfo['last_name'][0],
						'email'      => $userInfo['nickname'][0],
						'address_1'  => $_REQUEST['address_1'],
						'address_2'  => $_REQUEST['address_2'],
						'state'      => $_REQUEST['state'],
						'postcode'   => $_REQUEST['postcode'],
						'country'    => 'AU'
						);
					  $order = wc_create_order();
						foreach($data_prod as $prod_id=>$prd_val){
						 $order->add_product( get_product($prod_id), $prd_val);
							}
			  			 $order->set_address( $address, 'billing' );
			 			 $order->set_address( $address, 'shipping' );
						  WC()->shipping->calculate_shipping( WC()->cart->get_shipping_packages() );

					// Get the rate object selected by user for add shiping.
					foreach ( WC()->shipping->get_packages() as $package_key => $package ) {
						foreach ( $package['rates'] as $key => $rate ) {
							$item = new WC_Order_Item_Shipping();
								$item->set_props( array(
											'method_title' => $rate->label,
											'method_id'    => $rate->id,
											'total'        => wc_format_decimal( $rate->cost ),
											'taxes'        => $rate->taxes,
											'order_id'     => $order->id,
										) );
							foreach ( $rate->get_meta_data() as $key => $value ) {
											$item->add_meta_data( $key, $value, true );
										}

							$order->add_item( $item );
						}
					}	  	
					  $order->calculate_totals(); 				
					  update_post_meta( $order->id, '_customer_user', $current_user_login );
				      $order = new WC_Order($order->id);
				if (!empty($order)) {
					$order->set_customer_note( $_REQUEST['order_notes'] );
					$order->update_status( 'wc-processing' );
				   }	
				    //echo '{"Status":"true" , "Data":[{"result":"Order Created"}]}';
				/**************for update billing address***************/
       			update_user_meta( $current_user_login, 'billing_city', $_REQUEST['city']);
       			update_user_meta( $current_user_login, 'billing_postcode', $_REQUEST['postcode']);
       			update_user_meta( $current_user_login, 'billing_address_1', $_REQUEST['address_1']);	
				/**************for update billing address***************/		
						echo '{"Status":"true" , "Data":[{"result":"Order Created","del_date":"'.$delivery_date.'"}]}';
			      }else{
				    $error1 =  $data_val['error']['message'];
				    echo '{"Status":"false", "Data":[{"result":"'.$error1.'"}]}';
			      }
		        }
			}else{
			echo '{"Status":"false" , "Data":[{"result":"Pincode does not Exist"}]}';			
				die();
			}			
				}else{
				echo '{"Status":"false" , "Data":[{"result":"authcode expired"}]}';			
				die();		
				}
			
			}else{
			echo '{"Status":"false" , "Data":[{"result":"Some thing missing"}]}';			
			die();		
			}
}		

if($service == 'update_user'){
	if(isset($_REQUEST['auth_code']) && isset($_REQUEST['state']) && isset($_REQUEST['suburb']) && isset($_REQUEST['firstname']) && isset($_REQUEST['lastname']) && isset($_REQUEST['postcode']) && isset($_REQUEST['phone']) && isset($_REQUEST['street_no']) && isset($_REQUEST['address']) ){
		 $check_authcode = $wpdb->get_row('SELECT * from `wp_sweetnector_authcode` where auth_code = "'.$_REQUEST['auth_code'].'"');
		    if($check_authcode > 0){
			 $user_id =  $check_authcode->user_id;
				//echo $user_id ;die('sdf');
				update_user_meta( $user_id, 'billing_first_name', $_REQUEST['firstname']);
       			update_user_meta( $user_id, 'billing_last_name', $_REQUEST['lastname']);
       			update_user_meta( $user_id, 'billing_phone', $_REQUEST['phone']);
       			update_user_meta( $user_id, 'billing_state', $_REQUEST['state']);
       			update_user_meta( $user_id, 'billing_suburb', $_REQUEST['suburb']);
       			update_user_meta( $user_id, 'billing_postcode', $_REQUEST['postcode']);
       			update_user_meta( $user_id, 'billing_address_1', $_REQUEST['street_no']);
       			update_user_meta( $user_id, 'billing_address_2', $_REQUEST['address']);
				echo '{"Status":"true","Data":"Update"}';
				
			}else{
			echo '{"Status":"false" , "Data":[{"result":"authcode expired"}]}';			
			die();		
		}
	
	
	}else{
		echo '{"Status":"false" , "Data":[{"result":"Some thing missing"}]}';
		
		}
}	
	
	
if($service == 'forgot_password'){
   if(isset($_REQUEST['user_email'])){
   $check_Data = $wpdb->get_row('SELECT * from `wp_users` where user_email = "'.$_REQUEST['user_email'].'"');
   if($check_Data > 0)
			{	
				$hash_code = wp_generate_password( 12, false );
				$password_change_link = "https://sweetnectar.com.au/change-password/?hashcode=$hash_code";	
				
				$check_hash_code = $wpdb->get_var('SELECT COUNT(*) from `wp_hash_code` where user_id = "'.$check_Data->ID.'"');
	 				 if( $check_hash_code > 0 ){
					  $delete_hashcode = $wpdb->query('DELETE from `wp_hash_code`  WHERE user_id = "'.$check_Data->ID.'"');
			 		}
			$inser_authtokn = $wpdb->query("INSERT INTO `wp_hash_code`(`user_id`, `hashcode`) VALUES ('".$check_Data->ID."','".$hash_code."')");
				
				
				
				
			    $to = $_REQUEST['user_email'];
				$subject="Your new password";
				$message = '<html><body topmargin="25"><p>Here is your new Password : '.$password_change_link.'' . '</p><br/><p>Use this to login.</p><br/><p>Regards,<br/>Team Sweet Nector</p></body></html>';
				$headers = 'From: Sweet Nectar <hello@sweetnectar.com.au>' . "\r\n";
				$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
			    mail($to,$subject,$message,$headers);
				//$update_pass = $wpdb->query('UPDATE `wp_users` SET `user_pass`="'.md5($randomString).'" WHERE user_email = "'.$_REQUEST['user_email'].'"');
				echo '{"Status":"true", "Data":[{"result":"Please check email for further instructions."}]}';
			   exit();
			}
			else
			{	echo '{"Status":"false", "Data":[{"result":"The entered email address is not a valid registered user id. Please enter your registered email address."}]}';
			exit();
			}
	   }else{
      echo '{"Status":"false", "Data":[{"result":"Data is missing"}]}';	
   }

}	
	
	

	
	
	
if($service == 'create_coupan'){
	if(isset($_REQUEST['fb_response']) && isset($_REQUEST['auth_code'])){
	$check_authcode = $wpdb->get_row('SELECT * from `wp_sweetnector_authcode` where auth_code = "'.$_REQUEST['auth_code'].'"');
	if($check_authcode > 0){	
	  $uniqid = uniqid();
      $rand_start = rand(1,5);
	  $rand_8_char = substr($uniqid,$rand_start,6);
	  $coupon_code = $rand_8_char; // Code
	  $amount = '5'; // Amount
	  $discount_type = 'fixed_cart'; // Type: fixed_cart, percent, fixed_product, percent_product
	  $coupon = array(
			'post_title' => $coupon_code,
			'post_content' => '',
			'post_status' => 'publish',
			'post_author' => 1,
			'post_type'		=> 'shop_coupon'
		);
    	$new_coupon_id = wp_insert_post( $coupon );
		// Add meta
		update_post_meta( $new_coupon_id, 'discount_type', $discount_type );
		update_post_meta( $new_coupon_id, 'coupon_amount', $amount );
		update_post_meta( $new_coupon_id, 'individual_use', 'no' );
		update_post_meta( $new_coupon_id, 'product_ids', '' );
		update_post_meta( $new_coupon_id, 'exclude_product_ids', '' );
		update_post_meta( $new_coupon_id, 'usage_limit', 1 );
		update_post_meta( $new_coupon_id, 'expiry_date', '' );
		update_post_meta( $new_coupon_id, 'apply_before_tax', 'yes' );
		update_post_meta( $new_coupon_id, 'free_shipping', 'no' );
	   echo '{"Status":"true" , "Data":[{"result":"'.$rand_8_char.'"}]}';	
	}else{
		echo '{"Status":"false" , "Data":[{"result":"authcode expired"}]}';			
		die();
	}
		


}
}
	
	
if($service == 'check_coupan_code'){
	if(isset($_REQUEST['code']) ){

	$code = $_REQUEST['code'];
	$coupon = new WC_Coupon($code);
	$coupon_post = get_post($coupon->id);	
	$coupon_data = array(
		'id' => $coupon->id,
		'code' => $coupon->code,
		'type' => $coupon->type,
		'created_at' => $coupon_post->post_date_gmt,
		'updated_at' => $coupon_post->post_modified_gmt,
		'amount' => wc_format_decimal($coupon->coupon_amount, 2),
		'individual_use' => ( 'yes' === $coupon->individual_use ),
		'product_ids' => array_map('absint', (array) $coupon->product_ids),
		'exclude_product_ids' => array_map('absint', (array) $coupon->exclude_product_ids),
		'usage_limit' => (!empty($coupon->usage_limit) ) ? $coupon->usage_limit : null,
		'usage_count' => (int) $coupon->usage_count,
		'expiry_date' => (!empty($coupon->expiry_date) ) ? date('Y-m-d', $coupon->expiry_date) : null,
		'enable_free_shipping' => $coupon->enable_free_shipping(),
		'product_category_ids' => array_map('absint', (array) $coupon->product_categories),
		'exclude_product_category_ids' => array_map('absint', (array) $coupon->exclude_product_categories),
		'exclude_sale_items' => $coupon->exclude_sale_items(),
		'minimum_amount' => wc_format_decimal($coupon->minimum_amount, 2),
		'maximum_amount' => wc_format_decimal($coupon->maximum_amount, 2),
		'customer_emails' => $coupon->customer_email,
		'description' => $coupon_post->post_excerpt,
    	);
	
		if( $coupon->enable_free_shipping() == 1 )
		{
			$shipping = 'no';
		} else {
			$shipping = 'yes';	
		}	

		if($coupon->id == 0){
			echo '{"Status":"false" , "Data":[{"result":"Sorry, this promo code is not valid."}]}';
			die();
			}
		
			if( $coupon_data['usage_limit'] )
			{
				$usage_left = $coupon_data['usage_limit'] - $coupon_data['usage_count'];
			} else {
				if( $coupon_data['usage_limit'] == 0 )
				{
					$usage_left = 0;
				} else {	
					$usage_left = 5;
				}	
			}	
		
			if ($usage_left > 0) {
			echo '{"Status":"true" , "Data":[{"result":"Promocode Valid","amount": '.wc_format_decimal($coupon->coupon_amount, 2).',"type": "'.$coupon->type.'","shipping": "'.$shipping.'"}]}';
			} 
			else {
			echo '{"Status":"false" , "Data":[{"result":"Coupon Usage Limit Reached"}]}';	
			}	
			}else{
			echo '{"Status":"false" , "Data":[{"result":"Something missing"}]}';			
			die();		
			}	
	}		

	
	
if($service == 'reorder'){
if(isset($_REQUEST['auth_code'])){
	$check_authcode = $wpdb->get_row('SELECT * from `wp_sweetnector_authcode` where auth_code = "'.$_REQUEST['auth_code'].'"');
	if($check_authcode > 0){
	$customer_orders = get_posts( apply_filters( 'woocommerce_my_account_my_orders_query', array(
			'numberposts' => 1,
			'meta_key'    => '_customer_user',
			'meta_value'  => $check_authcode->user_id,
			'post_type'   => wc_get_order_types( 'view-orders' ),
			'post_status' => array_keys( wc_get_order_statuses() ),
		)));	
		if(empty($customer_orders)){
		echo '{"Status":"false" , "Data":[{"result":"Please Place the order first"}]}';			
		die();	
		}
			$order = new WC_Order($customer_orders[0]->ID);
			$items = $order->get_items();
			$img_array = array();
				foreach ( $items as $item ) {
				$product_name = $item['name'];
    			$product_id = $item['product_id'];
    			$product_qty = $item['quantity'];
				$post_thumbnail_id = get_post_thumbnail_id($product_id);
		    	$post_thumbnail_url = wp_get_attachment_url( $post_thumbnail_id );
				$reorder_dtail[] = array(
		    		'title' =>  $product_name,
					'img'=>$post_thumbnail_url,
					'Quantity'=> $product_qty, 	
					'id' =>  $product_id,
					);
			}
			$val =  json_encode($reorder_dtail);
			echo '{"Status":"true","result":'.$val.'}';
			 }else{
				echo '{"Status":"false" , "Data":[{"result":"authcode expired"}]}';			
				die();		
				} 
			}else{
			echo '{"Status":"false" , "Data":[{"result":"Something missing"}]}';			
			die();		
		}	
}
	

	
if($service == 'check_pincode'){
	if(isset($_REQUEST['pincode'])){
	
	$num_rows = $wpdb->get_row( "SELECT * FROM `wp_check_pincode_p` where `pincode` = '".$_REQUEST['pincode']."'");
	if(isset($num_rows)){
		
		$pin_dtl[] = array(
		            'pincode' => $num_rows->pincode,
		            'amount' => $num_rows->amount,
		            'dwd' => $num_rows->dod,
		
		            );
		$val =  json_encode($pin_dtl);
			echo '{"Status":"true","result":'.$val.'}';
	//echo '{"Status":"true" , "Data":[{"result":"'.$pin_dtl.'"}]}';
	}else{
	echo '{"Status":"false" , "Data":[{"result":"Not Found"}]}';
	}
	
	
	}else{
	echo '{"Status":"false" , "Data":[{"result":"Something missing"}]}';			
	die();	
	
	}
}	
	
	
if($service == 'request_forpincode_add'){
	if(isset($_REQUEST['first_name']) && isset($_REQUEST['last_name']) && isset($_REQUEST['email']) && isset($_REQUEST['pincode'])){

		        $to = 'enclouddev@gmail.com';
				$subject="Request for new postcode delivery -Sweet Nector - ".$_REQUEST['pincode'];
				$message = '<html>
				<body topmargin="25"><p>A request for new postcode delivery has been received. The details of the request are as follows:</p>
				<br/>Name: '.$_REQUEST['first_name'].' '.$_REQUEST['last_name'].'<br/>
				<br/>Email: '.$_REQUEST['email'].'<br/>
				<br/>Postcode: '.$_REQUEST['pincode'].'<br/>
				<p>Regards,<br/>Team Sweet Nectar</p></body></html>';
				$headers = "From: sweetnector@reply.com\r\n";
				$headers .= "Reply-To: sweetnector@reply.com\r\n";
				$headers .= "Return-Path: sweetnector@reply.com\r\n";
			    $headers = "MIME-Version: 1.0" . "\r\n";
           		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
			    mail($to,$subject,$message,$headers);
				echo '{"Status":"true", "Data":[{"result":"Email Send ."}]}';
			   exit();





	}else{
	echo '{"Status":"false" , "Data":[{"result":"Something missing"}]}';			
	die();	
	
	}


}	
	
	
	
	
	
	
	
	

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	 

}	  
?>