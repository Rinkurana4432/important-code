<?php /* Template Name: test*/ ?>


<?php include_once $_SERVER['DOCUMENT_ROOT'] . '/wp-config.php';

global $wpdb;

$checkbox_data = $_POST;

if($checkbox_data['myCheckboxes'][0] == 'All'){

$args = array(
	    'post_type' => 'product',
	    'stock' => 1,
	    'posts_per_page' => 9,
	    'orderby' =>'date',
	    'order' => 'ASC'
	 );

$loop = new WP_Query( $args ); ?>

<?php while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
 	<div class="col-md-4 col-sm-6 shopdetail">
		     <div class="shopdetailinner">
			 <div class="shopdetailinnerinner">
		   <a id="id-<?php the_id(); ?>" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
	 <?php 
	 if (has_post_thumbnail( $loop->post->ID ))
	     echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog');
	      else 
	     echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Sweet Nector" width="65px" height="115px" />'; ?>
		   </a>
			  <?php
			   $attr = get_post_meta( $product->id, '_product_attributes' ); 
	//echo'<pre>';print_r($attr);echo'</pre>';
			?>
			<div class="shopdetailinnerhover">
				<div class="headheadmain">
				   <?php
				   foreach($attr[0] as  $brdnewattr){ 
				      if($brdnewattr['name'] !='Ingredients' && $brdnewattr['name'] != 'Notes' ){
				   ?> 
				   <div class="headhead">
				     <h4><?php echo $brdnewattr['value']; ?></h4>
					 <p><?php echo $brdnewattr['name']; ?></p>
				   </div>
 	   <?php     } } ?>
				</div>
				  <div class="headheadcontent">
				   <div class="headheadcontentinner">
                   <?php
				    foreach($attr[0] as  $key => $value){
					if($key == 'ingredients'){
					  $groc = explode(",",$value['value']);
					  $groc_name = $value['name'];
					}
			    }
		   ?>
				     <h2 class="ingredient"><?php echo $groc_name; ?></h2>
				     <ul style="width:100%; margin:0px;padding:0px;">
				        <?php 
					  foreach($groc as $val1){ ?>
						<li style="float:left;width:50%;line-height:20px;"><?php echo $val1; ?></li>
					<?php  } ?>
					 </ul>  
					 <?php
					  foreach($attr[0] as  $key => $value){
					      if($key == 'notes'){
						 $note_nector = $value['value'];
					      }
					  }
					 ?>
					 </div>
			   </div>
		</div>
	</div>
			<div class="shopdetailhead">
				<h3><?php the_title(); ?></h3>
				 <span class="circle_div" style="display:none;" ></span>
					<input class="prds_qty" type="hidden" id="<?php echo $product->id; ?>" name="product[<?php echo $product->id; ?>]" value="0" />					
    				<i class="fa fa-plus plus-click plus_sign4all" aria-hidden="true"></i>
					<i class="fa fa-minus minus-click minus_sign4all" aria-hidden="true" style="display:none;"></i>
					  <?php  //woocommerce_template_loop_add_to_cart( $loop->post, $product ); ?>
				</div>
				<div class="shopdetailcontent">
				  <p><?php the_content(); ?></p>
				</div>
			 </div>
		  </div>
<?php endwhile; ?>

<?php wp_reset_query(); ?>

	
<?php	
}else{
$condition ='(';
$ii = 0;

foreach($checkbox_data['myCheckboxes'] as  $val){
	
	if( $ii > 0 ) { $condition .= " OR "; }
	
	$condition .= "(`meta_value` LIKE '".$val."' OR `meta_value` LIKE '%,".$val."' OR `meta_value` LIKE '".$val.",%')";
	$ii++;
}
$condition .= ')';

$sql = $wpdb->get_results("SELECT GROUP_CONCAT(`ID` separator ',') as IDs FROM `wp_posts` wp LEFT JOIN wp_postmeta wpm ON wp.ID=wpm.post_id WHERE `meta_key` = 'dryfruit' AND ".$condition);

if (strpos($sql[0]->IDs, ',') !== false) {
	$www = explode(',',$sql[0]->IDs);
} else {
	$www = array($sql[0]->IDs);
}


$query_args = array( 
		'post_status' => 'publish', 
		'post_type' => 'product',	
		'post__in' => $www
		);

$loop = new WP_Query($query_args); ?>

<?php while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
 		<div class="col-md-4 col-sm-6 shopdetail">
		     <div class="shopdetailinner">
			 <div class="shopdetailinnerinner">
		   <a id="id-<?php the_id(); ?>" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
	 <?php 
	 if (has_post_thumbnail( $loop->post->ID ))
	     echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog');
	      else 
	     echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Sweet Nector" width="65px" height="115px" />'; ?>
		   </a>
			  <?php
			   $attr = get_post_meta( $product->id, '_product_attributes' ); 
	//echo'<pre>';print_r($attr);echo'</pre>';
			?>
			<div class="shopdetailinnerhover">
				<div class="headheadmain">
				   <?php
				   foreach($attr[0] as  $brdnewattr){ 
				      if($brdnewattr['name'] !='Ingredients' && $brdnewattr['name'] != 'Notes' ){
				   ?> 
				   <div class="headhead">
				     <h4><?php echo $brdnewattr['value']; ?></h4>
					 <p><?php echo $brdnewattr['name']; ?></p>
				   </div>
 	   <?php     } } ?>
				</div>
				  <div class="headheadcontent">
				   <div class="headheadcontentinner">
                   <?php
				    foreach($attr[0] as  $key => $value){
					if($key == 'ingredients'){
					  $groc = explode(",",$value['value']);
					  $groc_name = $value['name'];
					}
			    }
		   ?>
				     <h2 class="ingredient"><?php echo $groc_name; ?></h2>
				     <ul style="width:100%; margin:0px;padding:0px;">
				        <?php 
					  foreach($groc as $val1){ ?>
						<li style="float:left;width:50%;line-height:20px;"><?php echo $val1; ?></li>
					<?php  } ?>
					 </ul>  
					 <?php
					  foreach($attr[0] as  $key => $value){
					      if($key == 'notes'){
						 $note_nector = $value['value'];
					      }
					  }
					 ?>
					 <p style="line-height:20px;text-align:justify;"><?php echo $note_nector; ?></p>
					 </div>
			   </div>
		</div>
	</div>
			<div class="shopdetailhead">
				<h3><?php the_title(); ?></h3>
				 <span class="circle_div" style="display:none;" ></span>
					<input class="prds_qty" type="hidden" id="<?php echo $product->id; ?>" name="product[<?php echo $product->id; ?>]" value="0" />					
    				<i class="fa fa-plus plus-click plus_sign4all" aria-hidden="true"></i>
					<i class="fa fa-minus minus-click minus_sign4all" aria-hidden="true" style="display:none;"></i>
					  <?php  //woocommerce_template_loop_add_to_cart( $loop->post, $product ); ?>
				</div>
				<div class="shopdetailcontent">
				  <p><?php the_content(); ?></p>
				</div>
			 </div>
		  </div>
<?php endwhile; ?>

<?php wp_reset_query(); ?>

<?php } ?>

