<?php

define( 'CHILD_DIR', get_stylesheet_directory_uri() );
define( 'siteURl', get_site_url() );

function wc_empty_cart_redirect_url() {
	return siteURl.'/#shop_my_box';
}
add_filter( 'woocommerce_return_to_shop_redirect', 'wc_empty_cart_redirect_url' );

function azera_shop_php_style_custom() {

	if ( ( empty( $azera_shop_enable_move ) || ! $azera_shop_enable_move ) && ( is_front_page() || is_page_template( 'template-frontpage.php' ) ) ) {
		
			$custom_css .= '.header{ background: #464b51 !important; }';
	}
	
	wp_add_inline_style( 'azera-shop-style', $custom_css );
	
	wp_enqueue_script( 'custom-woocommerce', get_stylesheet_directory_uri() . '/js/custom_woocommerce.js',array( 'jquery' ));
}
add_action( 'wp_enqueue_scripts', 'azera_shop_php_style_custom', 100 );

add_action( 'init', 'woocommerce_clear_cart_url' );
function woocommerce_clear_cart_url() {
  global $woocommerce;
	
	if ( isset( $_GET['empty-cart'] ) ) {
		$woocommerce->cart->empty_cart(); 
	}
}


add_filter( 'woocommerce_cart_shipping_method_full_label', 'bbloomer_remove_shipping_label', 10, 2 );
  
function bbloomer_remove_shipping_label($label, $method) {
$new_label = preg_replace( '/^.+:/', '', $label );
return $new_label;
}

        function wc_cart_totals_shipping_html22() { 
            $packages = WC()->shipping->get_packages(); 
		
	
            foreach ( $packages as $i => $package ) { 
                $chosen_method = isset( WC()->session->chosen_shipping_methods[ $i ] ) ? WC()->session->chosen_shipping_methods[ $i ] : ''; 
                $product_names = array(); 
         
                if ( sizeof( $packages ) > 1 ) { 
                    foreach ( $package['contents'] as $item_id => $values ) { 
                        $product_names[ $item_id ] = $values['data']->get_name() . ' ×' . $values['quantity']; 
                    } 
                    $product_names = apply_filters( 'woocommerce_shipping_package_details_array', $product_names, $package ); 
                } 
         
                wc_get_template( 'cart/cart-shipping.php', array( 
                    'package' => $package,  
                    'available_methods' => $package['rates'],  
                    'show_package_details' => sizeof( $packages ) > 1,  
                    'package_details' => implode( ', ', $product_names ),  
                    // @codingStandardsIgnoreStart 
                    'package_name' => apply_filters( 'woocommerce_shipping_package_name', sprintf( _nx( 'Refrigerated Courier', 'Shipping %d', ( $i + 1 ), 'shipping packages', 'woocommerce' ), ( $i + 1 ) ), $i, $package ),  
                    // @codingStandardsIgnoreEnd 
                    'index' => $i,  
                    'chosen_method' => $chosen_method,  
         ) ); 
            } 
        } 

//for add custom fields


add_action( 'woocommerce_product_options_general_product_data', 'woocommerce_general_product_data_custom_field' );
 
function woocommerce_general_product_data_custom_field() {
  
    woocommerce_wp_checkbox(
                array(
                    'id' => 'Nut',
                    'wrapper_class' => 'checkbox_class',
                    'label' => __('Checkbox for Product', 'woocommerce' ),
		            'name' => 'Nut',
                    'description' => __( 'Nut', 'woocommerce' )
                )
            );
	    woocommerce_wp_checkbox(
                array(
                    'id' => 'Cashew',
                    'wrapper_class' => 'checkbox_class',
                    'name' => 'Cashew', 
                    'description' => __( 'Cashew', 'woocommerce' )
                )
            );
	    woocommerce_wp_checkbox(
                array(
                    'id' => 'Peanut',
                    'wrapper_class' => 'checkbox_class',
                     'name' => 'Peanut',
                    'description' => __( 'Peanut', 'woocommerce' )
                )
            );
	    woocommerce_wp_checkbox(
                array(
                    'id' => 'Almond',
                    'wrapper_class' => 'checkbox_class',
                    'name' => 'Almond',
                    'description' => __( 'Almond', 'woocommerce' )
                )
            );
   
}

// Save Fields using WooCommerce Action Hook
add_action( 'woocommerce_process_product_meta', 'woocommerce_process_product_meta_fields_save' );
function woocommerce_process_product_meta_fields_save( $post_id ){
	
	$dryfruit = array();
	
	if(isset($_POST['Nut'])) { $dryfruit[] = 'Nut'; }
	if(isset($_POST['Cashew'])) { $dryfruit[] = 'Cashew'; }
	if(isset($_POST['Peanut'])) { $dryfruit[] = 'Peanut'; }
	if(isset($_POST['Almond'])) { $dryfruit[] = 'Almond'; }

    $woo_checkbox = isset( $_POST['Nut'] ) ? 'yes' : 'no';
    update_post_meta( $post_id, 'Nut', $woo_checkbox );
	
	$woo_checkbox = isset( $_POST['Cashew'] ) ? 'yes' : 'no';
    update_post_meta( $post_id, 'Cashew', $woo_checkbox );
	
	$woo_checkbox = isset( $_POST['Peanut'] ) ? 'yes' : 'no';
    update_post_meta( $post_id, 'Peanut', $woo_checkbox );
	
	$woo_checkbox = isset( $_POST['Almond'] ) ? 'yes' : 'no';
    update_post_meta( $post_id, 'Almond', $woo_checkbox );

	$data_dryfruits = implode(',',$dryfruit);
	update_post_meta( $post_id, 'dryfruit', $data_dryfruits );
}


/**
* Below code save extra fields.
*/
function wooc_save_extra_register_fields( $customer_id ) {
	
    if ( isset( $_POST['reg_first_name'] ) ) {
		update_user_meta( $customer_id, 'billing_first_name', sanitize_text_field( $_POST['reg_first_name'] ) );
    }
	
    if ( isset( $_POST['reg_last_name'] ) ) {
		update_user_meta( $customer_id, 'billing_last_name', sanitize_text_field( $_POST['reg_last_name'] ) );
    }
	
    if ( isset( $_POST['reg_phone'] ) ) {
		update_user_meta( $customer_id, 'billing_phone', sanitize_text_field( $_POST['reg_phone'] ) );
    } else {
		$reg_phone = 0;
		update_user_meta( $customer_id, 'billing_phone', $reg_phone );
	}	
	
    $headers = 'From: Sweet Nectar <hello@sweetnectar.com.au>' . "\r\n";
    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
     
    $subject = 'New signup';
	
	$name = $_POST['com_firstname'].' '.$_POST['com_lastname'];	

    $message = '<html>
  <head>
 <link href="https://fonts.googleapis.com/css?family=Noto+Sans" rel="stylesheet">
<style>
.pic1
{
	width:200px;
	float:left;
}
.pic2{
	width:200px;
	float:left;
}
.pic4
{
	width:200px;
	float:left;
}
.pic5{
	width:200px;
	float:left;
}
tr,td{
	border:none;
}
button.btn.btn-default {
    background: #ec89bb;
    color: #fff;
    height: 50px;
    width: 200px;
	margin-bottom: 25px;
	border: none;
	margin-top: -42px;
}
.left
{
	width:295px;
	float:left;
	padding-bottom:20px;
}
.right
{
	width:300px;
	float:right;
	margin-top: 50px;
	
}
p.head {
    color:#ec89bb;
    font-size: 65px;
    text-align: left;
    padding-left: 30px;
	margin-top: 0px;
	opacity: 0.3;
}
</style>
  </head>
<body style="font-family: Pacifico !important;"> 
<table class="container" align="center" border="2px solid #000" cellpadding="0" cellspacing="0" width="100%" style="position:relative; text-align:center; max-width:600px;">
<tr style="text-align: center;border: none;">
<td style="border: none;"><a href="https://sweetnectar.com.au"><img src="https://sweetnectar.com.au/wp-content/uploads/2017/09/SN-logo.png" alt="" width="150" height="150" class="alignnone size-full wp-image-791"></a></td>
</tr>


<tr style="text-align: center;border: none;">
<td  class="head" style="font-weight: bold;font-family: Pacifico;font-size: 30px;margin-top: 100px;padding: 20px;border: none;">
<img src="https://sweetnectar.com.au/wp-content/uploads/2017/10/left.jpg" alt="" class="alignnone size-full wp-image-800" style="position:absolute;left:0px;margin-top: -18%; width: 20%;"><i>Welcome <strong>' . esc_html( $name ) . '</strong>!</i>
<img src="https://sweetnectar.com.au/wp-content/uploads/2017/10/right.jpg" alt="" class="alignnone size-full wp-image-801" style="position:absolute;right:0px;margin-top: -18%;width: 20%;"></td>

</tr>
<tr style="text-align: center;border: none;">
<td style="font-size: 15px;font-family: Open Sans;padding-top: 17%;border: none;">Your dessert dreams just came true. <br> We cant wait to feed you the sweet stuff!
<hr style="align=center; margin-left:250px; margin-right:250px;">
</td>
</tr>
<tr style="text-align: center;border: none;">
<td style="font-size: 20px;font-family: Open Sans;padding-top: 40px;padding-bottom: 0px;font-weight: bold;border: none;"><i>Ready to pick your six?</i></td>
</tr>
<tr style="border: none;">
<td style="text-align: right;padding-right: 100px;padding-top: 0px;border: none;"><img src="https://sweetnectar.com.au/wp-content/uploads/2017/09/arrw.jpg" alt="" width="92" height="108" class="alignnone size-full wp-image-803">
</td>
</tr>

<tr style="text-align: center;border: none;">
<td style="padding-bottom: 35px;border: none;"><a href="https://sweetnectar.com.au/#shop_my_box"><button type="button" class="btn btn-default" style="background: #ec89bb;color: #fff;height: 50px;width: 200px;margin-bottom: 25px;border: none;margin-top: -42px;">ORDER HERE</button></a></td>
</tr>



<tr style="text-align: center;border: none;">
<td style="border: none;">
<hr style="align=center; margin-left:30px; margin-right:30px; margin-top:30px;margin-bottom: 20px;">
<a href="https://www.instagram.com/sweetnectardesserts/"><img src="https://sweetnectar.com.au/wp-content/uploads/2017/09/social2.jpg" alt="" width="57" height="53" class="alignnone size-full wp-image-798"></a>
<a href="https://www.facebook.com/sweetnectardesserts"><img src="https://sweetnectar.com.au/wp-content/uploads/2017/09/social1.jpg" alt="" width="57" height="53" class="alignnone size-full wp-image-797"></a>
<hr style="align=center; margin-left:30px; margin-right:30px; margin-top:30px;margin-bottom: 20px;">
</td>

</tr>
</table>
  </body>
</html>';  

    $response = wp_mail( $_POST['com_email'], $subject, $message, $headers );
	
	
	
}

add_action( 'user_register', 'wooc_save_extra_register_fields' );


add_filter( 'woocommerce_checkout_fields', 'patricks_woocommerce_checkout_fields' );
// Remove the billing phone - $fields is passed via the filter
function patricks_woocommerce_checkout_fields( $fields ) {
    // remove the phone field
    unset($fields['billing']['billing_phone']);
    unset($fields['billing']['billing_city']);
    // make the billing email field fill up the entire space
    $fields['billing']['billing_email']['class'] = array('form-row-wide');
    return $fields;
}


add_filter( 'registration_redirect', 'my_redirect_home' );
function my_redirect_home( $registration_redirect ) {
    global $woocommerce;
	
    if( WC()->cart->cart_contents_count > 0){	
        return home_url('/cart');
    } else {
		return home_url('/my-account-2');
	}	
}

function my_login_redirect( $redirect_to ) {
	
    global $woocommerce;
	
    if( WC()->cart->cart_contents_count > 0){	
        return home_url('/cart');
    } else {
		return home_url('/my-account-2');
	}	
	
}

add_action('wp_ajax_wdm_ajax_filteration_products', 'wdm_ajax_filteration_products_callback');
add_action('wp_ajax_nopriv_wdm_ajax_filteration_products', 'wdm_ajax_filteration_products_callback');

function wdm_ajax_filteration_products_callback()
{

?>	
	
<script type="text/javascript">
	$(document).ready(function(){
		$(".sub-head a").click(function() {
	
		$( ".sub-head a" ).each(function( ) {
          $(this).removeClass('sub-headinner');
        });
         $(this).addClass('sub-headinner');
		});
		
		$(".minus_sign4all").css("display","none");
		$(".circle_div").css("display","none");
	
    	/*$(".shopdetailinnerinner").hover(function(){
			$(this).find(".shopdetailinnerhover").css("top","0px");
			$(this).find(".shopdetailinnerhover").css("height","100%");
	 	}, function(){
       		$(this).find(".shopdetailinnerhover").css("top","100%");
       		$(this).find(".shopdetailinnerhover").css("height","100%");
    	});*/
		
	$(".plus-click").click(function(){
		
		var product_val = $(this).closest(".shopdetailhead").find("input").val();
		var incremented_val = parseInt( product_val ) + 1;
		
			if( incremented_val > 0 ) {
				$(this).closest(".shopdetailhead").find("span").text(incremented_val);
				$(this).closest(".shopdetailhead").find("span").css("display","inline");
			} else {
				
				$(this).closest(".shopdetailhead").find("span").css("display","none");
			}
				
		$(this).closest(".shopdetailhead").find("input").val(incremented_val);
		if( incremented_val > 0 ) { $(this).closest(".shopdetailhead").find(".minus_sign4all").css("display","block"); }

		calculate_sum();
		

	});
	
	$(".minus-click").click(function(){
		var product_val = $(this).closest(".shopdetailhead").find("input").val();
		var Decremented_val = parseInt( product_val ) - 1;
			if( Decremented_val > 0 ) {
				$(this).closest(".shopdetailhead").find("span").text(Decremented_val);
				$(this).closest(".shopdetailhead").find("span").css("display","inline");
			} else {
				$(this).closest(".shopdetailhead").find("span").css("display","none");
			}
		$(this).closest(".shopdetailhead").find("input").val(Decremented_val);
		if( Decremented_val == 0 ) { $(this).closest(".shopdetailhead").find(".minus_sign4all").css("display","none"); }
		
		calculate_sum();
	});		
    $('#nut,#cashew,#peanut,#almond').click(function(event) { 
	//on click 
        if(this.checked) { // check select status
            
			 $('#all').each(function() { //loop through each checkbox
                this.checked = false;  //select all checkboxes with class "checkbox1"               
            });
        }
    });
	
	 $('#all').click(function(event) { 
	//on click 
        if(this.checked) { // check select status
            $('.check').each(function() { //loop through each checkbox
                this.checked = false;  //select all checkboxes with class "checkbox1"               
            });
			 
        }
    });
	
	$('.check').click(function(){
		$('#all').prop('checked', false)
  	});	
	
	
	 $('.prds_qty').each(function() {
    	 var prdqty = $(this).val();
	
		 if(prdqty > 0) { 
	
			 var prdid = $(this).attr('id');
			 var idd = '#' +  $(this).attr('id');

			 $(idd + '_pp').html(prdqty); 
			 $(idd + '_pp').show();
		  	 $('.plus_sign4all').hide();
		  	 $(idd + '_mm').show();
		  
			 document.getElementById("add_tocrt").disabled = false;
		  
		}
    });
	
	$(".slide-toggle").click(function(){
    	$("#mainnavbar").slideToggle();
    });
	
	$(".slide-toggle2").click(function(){
    	$("#mainnavbar_3").slideToggle();
    });	
	
$(":text").keyup(function (e) {
  if ($(this).val() != '') {
  		$(".cht22").show();
	} 
});	
	
	
	});
	
	function calculate_sum() {
		var sum = 0;
    	
		$('.prds_qty').each(function() {
        	sum += Number($(this).val());
    	});

		if( sum == 6 ) {
			$(".plus_sign4all").css("display","none");
			//document.getElementById("add_tocrt").disabled = false;
		} else if( sum > 6 ) {
			$(".plus_sign4all").css("display","none");
		} else if( sum < 6 ) {	
			$(".plus_sign4all").css("display","block");
			// document.getElementById("add_tocrt").disabled = true;
		}	
	}	
	
	
</script>	
	
<?php
	
global $wpdb;

$checkbox_data = $_POST;

if($checkbox_data['myCheckboxes'][0] == 'All'){

$args = array(
	    'post_type' => 'product',
	    'stock' => 1,
		'post_status' => 'publish',
	    'posts_per_page' => 9,
	    'orderby' =>'date',
	    'order' => 'ASC'
	 );

$loop = new WP_Query( $args ); ?>

<?php while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
 	<div class="col-md-4 col-sm-6 shopdetail">
		     <div class="shopdetailinner">
			 <div class="shopdetailinnerinner">
		   <div class="outer-div">

	 		<?php 
	 		if(!empty(get_post_meta(get_the_id(), 'second_featured_img', true))){
	 			$popupImageID = get_post_meta(get_the_id(), 'second_featured_img', true);
	 			$popupImage = get_the_guid( $popupImageID );
	 		}else{
	 			$popupImage = '';
	 		} ?>
	 		<a id="id-<?php the_id(); ?>" href="Javascript:void(0);" onclick="showImageModal('<?php echo $popupImage; ?>');"; title="<?php the_title(); ?>">
	 <?php 
	 if (has_post_thumbnail( $loop->post->ID ))
	     echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog');
	      else 
	     echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Sweet Nector" width="65px" height="115px" />'; ?>
		   </a>
	 		<div class="inner-div">
	 			<a href="javascript:void(0);" onclick="showIngredient(<?php the_id(); ?>);"><img src="<?php echo site_url();?>/wp-content/uploads/2017/10/info-icon@3x.png"></a>
	 		</div>
	 	</div>


			  <?php
			   $attr = get_post_meta( $product->id, '_product_attributes' ); 
	//echo'<pre>';print_r($attr);echo'</pre>';
			?>
			<div class="shopdetailinnerhover">
				<div class="headheadmain">
				</div>
				  <div class="headheadcontent">
				   <div class="headheadcontentinner">
                   <?php
				    foreach($attr[0] as  $key => $value){
					if($key == 'ingredients'){
					  $groc = explode(",",$value['value']);
					  $groc_name = $value['name'];
					}
			    }
		   ?>
				     <h2 class="ingredient"><?php echo $groc_name; ?></h2>
				     <ul style="width:100%; margin:0px;padding:0px;">
				        <?php 
					  foreach($groc as $val1){ ?>
						<li style="float:left;width:50%;line-height:20px;"><?php echo $val1; ?></li>
					<?php  } ?>
					 </ul>  
					 <?php
					  foreach($attr[0] as  $key => $value){
					      if($key == 'notes'){
						 $note_nector = $value['value'];
					      }
					  }
					 ?>
					 </div>
			   </div>
		</div>
	</div>
			<div class="shopdetailhead">
				<h3><?php the_title(); ?></h3>
				 <span class="circle_div" style="display:none;" id="<?php echo $product->id; ?>_pp" ></span>
					<input class="prds_qty" type="hidden" id="<?php echo $product->id; ?>" name="product[<?php echo $product->id; ?>]" value="0" />					
    				<i class="fa fa-plus plus-click plus_sign4all" aria-hidden="true"></i>
					<i class="fa fa-minus minus-click minus_sign4all" id="<?php echo $product->id; ?>_mm" aria-hidden="true"></i>
					  <?php  //woocommerce_template_loop_add_to_cart( $loop->post, $product ); ?>
				</div>
				<div class="shopdetailcontent">
				  <p><?php the_content(); ?></p>
				</div>
			 </div>
		  </div>
<?php endwhile; ?>

<?php wp_reset_query(); ?>

	
<?php	
}else{
$condition ='(';
$ii = 0;

foreach($checkbox_data['myCheckboxes'] as  $val){
	
	if( $ii > 0 ) { $condition .= " AND "; }
	
	$condition .= "(`meta_value` LIKE '".$val."' OR `meta_value` LIKE '%,".$val."' OR `meta_value` LIKE '".$val.",%')";
	$ii++;
}
$condition .= ')';

$sql = $wpdb->get_results("SELECT GROUP_CONCAT(`ID` separator ',') as IDs FROM `wp_posts` wp LEFT JOIN wp_postmeta wpm ON wp.ID=wpm.post_id WHERE `meta_key` = 'dryfruit' AND ".$condition);

if (strpos($sql[0]->IDs, ',') !== false) {
	$www = explode(',',$sql[0]->IDs);
} else {
	$www = array($sql[0]->IDs);
}


$query_args = array( 
		'post_status' => 'publish', 
		'post_type' => 'product',	
		'post__in' => $www
		);

$loop = new WP_Query($query_args); 

 ?>

<?php if( $loop->post_count == 0 ) { ?>
	<h3 class="shopsubhead" style="font-size: 20px;">Oops! No products found for your selection.</h3>
<?php } ?>

<?php while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
 		<div class="col-md-4 col-sm-6 shopdetail">
		     <div class="shopdetailinner">
			 <div class="shopdetailinnerinner">
		   <div class="outer-div">
		   	<?php 
			 		if(!empty(get_post_meta(get_the_id(), 'second_featured_img', true))){
			 			$popupImageID = get_post_meta(get_the_id(), 'second_featured_img', true);
			 			$popupImage = get_the_guid( $popupImageID );
			 		}else{
			 			$popupImage = '';
			 		} ?>
		   <a id="id-<?php the_id(); ?>" href="Javascript:void(0);" onclick="showImageModal('<?php echo $popupImage; ?>');"; title="<?php the_title(); ?>">
	 <?php 
	 if (has_post_thumbnail( $loop->post->ID ))
	     echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog');
	      else 
	     echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Sweet Nector" width="65px" height="115px" />'; ?>
		   </a>
		   <div class="inner-div">
			 			<a href="javascript:void(0);" onclick="showIngredient(<?php the_id(); ?>);"><img src="<?php echo site_url();?>/wp-content/uploads/2017/10/info-icon@3x.png"></a>
			 		</div>
		</div>
			  <?php
			   $attr = get_post_meta( $product->id, '_product_attributes' ); 
	//echo'<pre>';print_r($attr);echo'</pre>';
			?>
			<div class="shopdetailinnerhover" style="top: 100%; height: 100%">
				<a class="close-inger" href="javascript:void(0);" onclick="hideIngredient(<?php the_id(); ?>);"><i class="fa fa-times" aria-hidden="true"></i></a>
				<div class="headheadmain">
				</div>
				  <div class="headheadcontent">
				   <div class="headheadcontentinner">
                   <?php
				    foreach($attr[0] as  $key => $value){
					if($key == 'ingredients'){
					  $groc = explode(",",$value['value']);
					  $groc_name = $value['name'];
					}
			    }
		   ?>
				     <h2 class="ingredient"><?php echo $groc_name; ?></h2>
				     <ul style="width:100%; margin:0px;padding:0px;">
				        <?php 
					  foreach($groc as $val1){ ?>
						<li style="float:left;width:50%;line-height:20px;"><?php echo $val1; ?></li>
					<?php  } ?>
					 </ul>  
					 <?php
					  foreach($attr[0] as  $key => $value){
					      if($key == 'notes'){
						 $note_nector = $value['value'];
					      }
					  }
					 ?>
					 </div>
			   </div>
		</div>
	</div>
			<div class="shopdetailhead">
				<h3><?php the_title(); ?></h3>
				<span class="circle_div" style="display:none;" id="<?php echo $product->id; ?>_pp" ></span>
					<input class="prds_qty" type="hidden" id="<?php echo $product->id; ?>" name="product[<?php echo $product->id; ?>]" value="0" />					
    				<i class="fa fa-plus plus-click plus_sign4all" aria-hidden="true"></i>
					<i class="fa fa-minus minus-click minus_sign4all" id="<?php echo $product->id; ?>_mm" aria-hidden="true"></i>
					  <?php  //woocommerce_template_loop_add_to_cart( $loop->post, $product ); ?>
				</div>
				<div class="shopdetailcontent">
				  <p><?php the_content(); ?></p>
				</div>
			 </div>
		  </div>
<?php endwhile; ?>



<?php wp_reset_query(); ?>

<?php } 
	
      die();
}


add_action('wp_ajax_wdm_go_to_cart_data_options', 'wdm_go_to_cart_data_options_callback');
add_action('wp_ajax_nopriv_wdm_go_to_cart_data_options', 'wdm_go_to_cart_data_options_callback');

function wdm_go_to_cart_data_options_callback()
{
	  global $woocommerce;
	
	  WC()->cart->empty_cart();
	
	  $userid = get_current_user_id(); //This is product ID
	
      session_start();
	
	  foreach($_SESSION as $all) {	
		  foreach( $all as $boxkey => $singlebox ) {
			  $products = array();
			  if( count( $singlebox ) > 0 ) {
			  	foreach( $singlebox as $singleboxkey => $singleboxvalue ) {
	  				WC()->cart->add_to_cart($singleboxkey, $singleboxvalue );
					$products[$singleboxkey] = $singleboxvalue;
			  	}	  
				$allprds[$boxkey] = $products;  
			  }	  
		  }	  
	  }
		
	  $_SESSION['user_custom_session'] = $allprds;
	
	  echo "<pre>"; print_r($_SESSION); echo "</pre>";
      die();
}

add_action('wp_ajax_checkpostdelivery_data_options', 'checkpostdelivery_data_options_callback');
add_action('wp_ajax_nopriv_checkpostdelivery_data_options', 'checkpostdelivery_data_options_callback');

function checkpostdelivery_data_options_callback()
{
	  global $wpdb;
	  $table_name2 = 'wp_custom_delivery_options';
	
	  $deliveryoptions = $wpdb->get_results( 'SELECT * FROM `wp_zone_lists` WHERE `postcode` = "'.$_REQUEST['pincode'].'" AND `suburb` = "'.$_REQUEST['suburb'].'" ' );
	
	  if( $wpdb->num_rows > 0 ) {
		  
  			$chkcutoff = $wpdb->get_row( 'SELECT * FROM '.$table_name2.' WHERE city = "'.$deliveryoptions[0]->city.'" ' );
			
			$date1 = date_create($chkcutoff->cut_off_date);
			$date2 = date_create($chkcutoff->delivery_date);

			$diff = date_diff($date1,$date2);
			$response = array(
						'Status' => 'true',
						'Data' => "<div class='pincode_found' style='margin: 120px auto;'>
        <img src='".CHILD_DIR."/images/pinfound.png' style='height: 100px;'/>
		<h2 class='kkls'>YES!</h2>
		<h4><b>We deliver to:</b> ".$_REQUEST['suburb'].', '.$_REQUEST['pincode']."</h4>
		<h4><b>Cost:</b> Free refrigerated delivery</h4> 
		
     </div><div class='delivery_hr'><hr style='height: 3px;'></div>");
		} else { 
			$response = array(
							'Status' => 'false',
							'error' => "<div class='pin_not_found' style='margin: 40px auto;'>
		<img src='".CHILD_DIR."/images/not_found.png' style='height: 100px;'/>
		<p class='sml_txte' style='font-size: 22px;width: 70%;'>Unfortunately we don't currently deliver to ".$_REQUEST['suburb'].', '.$_REQUEST['pincode']."!</p>
		<br/>
		<p class='sml_txte' style='font-weight: normal;width: 70%;font-size: 15px;'>Our delivery areas are frequently expanding, enter your details below to be notified the moment we are servicing your area.</p>
		<br/>
		<form name='send_eml' id='chp_pp'>
			<div class='er_msg'><span class='msg13'></span> <span class='msg134'></span></div>
		<input type='text' Placeholder='First name' name='firstname' id='firstname' class='pin_cls12' style='border: 1px solid #bceae7;height: 52px;
    margin-bottom: 10px;margin-top: 10px;width: 60%;padding: 10px;font-family: timelessregular; '>
		<input type='hidden' name='pincode' id='pincode2' value='".$_REQUEST['pincode']."'>
		<input type='text' Placeholder='Last name' name='lastname' id='lastname' class='pin_cls12' style='border: 1px solid #bceae7;height: 52px;
    margin-bottom: 10px;width: 60%;padding: 10px;font-family: timelessregular; '>
		<input type='text' Placeholder='Email' name='email' id='email' class='pin_cls12' style='border: 1px solid #bceae7;height: 52px;
    margin-bottom: 10px;width: 60%;padding: 10px;font-family: timelessregular; '><br/>
			
		<button class='btn btn-primary gobtn3 btn33' type='button' onclick='emailsendbtn();'>I WANT TO KNOW</button>
		</form>		
	</div><div class='delivery_hr'><hr style='height: 3px;'></div>");		
		}
	
	  echo json_encode($response);
      die();
}

add_action('wp_ajax_wdm_update_thisbox_data_options', 'wdm_update_thisbox_data_options_callback');
add_action('wp_ajax_nopriv_wdm_update_thisbox_data_options', 'wdm_update_thisbox_data_options_callback');

function wdm_update_thisbox_data_options_callback()
{
	  global $woocommerce;
	
	  WC()->cart->empty_cart();
	
	  $userid = get_current_user_id(); //This is product ID
	  
	  session_start();
	
	  $count784 = count($_SESSION['user_custom_session']) + 1;	
	
      $box_type = (isset($_SESSION['update_box'])) ? $_SESSION['update_box'] : 'BOX '.$count784; //This is product ID
	  $products = array();
	  
	  if( count($_POST['user_data']) > 0 ) {
		  foreach ($_POST['user_data'] as $key => $value ) {
				if( $value && $value > 0 )
				{
					$products[$key]	= $value;
				}	
	  	  }	  
	  }		  
			  
      $_SESSION['user_custom_session'][$box_type] = $products;
	
	  foreach($_SESSION as $all) {	
		  foreach( $all as $singlebox ) {
			  foreach( $singlebox as $singleboxkey => $singleboxvalue ) {
	  			WC()->cart->add_to_cart($singleboxkey, $singleboxvalue );
			  }	  
		  }	  
	  }
	
	  unset($_SESSION['update_box']);
	
	  echo "<pre>"; print_r($_SESSION); echo "</pre>";
      die();
}

add_action('wp_ajax_wdm_add_user_custom_data_options', 'wdm_add_user_custom_data_options_callback');
add_action('wp_ajax_nopriv_wdm_add_user_custom_data_options', 'wdm_add_user_custom_data_options_callback');

function wdm_add_user_custom_data_options_callback()
{
	  global $woocommerce;
	
	  WC()->cart->empty_cart();
	
	  $userid = get_current_user_id(); //This is product ID
	
      $box_type = $_POST['id']; //This is product ID
	  $products = array();
	  
	  if( count($_POST['user_data']) > 0 ) {
		  foreach ($_POST['user_data'] as $key => $value ) {
				if( $value && $value > 0 )
				{
					$products[$key]	= $value;
				}	
	  	  }	  
	  }		  
			  
      session_start();
      $_SESSION['user_custom_session'][$box_type] = $products;
	
	  foreach($_SESSION as $all) {	
		  foreach( $all as $singlebox ) {
			  foreach( $singlebox as $singleboxkey => $singleboxvalue ) {
	  			WC()->cart->add_to_cart($singleboxkey, $singleboxvalue );
			  }	  
		  }	  
	  }
	
	  echo "<pre>"; print_r($_SESSION); echo "</pre>";
      die();
}

add_action('wp_ajax_woocommerce_updatethis_box', 'woocommerce_updatethis_box_callback');
add_action('wp_ajax_nopriv_woocommerce_updatethis_box', 'woocommerce_updatethis_box_callback');

function woocommerce_updatethis_box_callback()
{
      $userid = get_current_user_id(); //This is product ID	  
	
      session_start();
	
	  $_SESSION['update_box'] = $_POST['box'];
      
	  echo $boxName = $_POST['box'];
	  die();	  
}

add_action('wp_ajax_woocommerce_deletethis_box', 'woocommerce_deletethis_box_callback');
add_action('wp_ajax_nopriv_woocommerce_deletethis_box', 'woocommerce_deletethis_box_callback');

function woocommerce_deletethis_box_callback()
{
      $userid = get_current_user_id(); //This is product ID	  
	
      session_start();
	  $boxName = $_POST['box'];	
      
	  unset($_SESSION['user_custom_session'][$boxName]);

	  WC()->cart->empty_cart();
	
	  $count = 0;
	
	  if( count($_SESSION['user_custom_session']) > 0 ) {	
		  foreach($_SESSION as $all) {	
			  foreach( $all as $boxkey => $singlebox ) {
				  $products = array();
				  if( count( $singlebox ) > 0 ) {
					$count++;  
					foreach( $singlebox as $singleboxkey => $singleboxvalue ) {
						WC()->cart->add_to_cart($singleboxkey, $singleboxvalue );
						$products[$singleboxkey] = $singleboxvalue;
					}	  
					$allprds["BOX ".$count] = $products;  
				  }	  
			  }	  
		  }

		  $_SESSION['user_custom_session'] = $allprds;
		  
		  $value = "Has";
		  
	  } else {
		  
		  $value = "Not";
		  
	  }		  

	  echo $value;
	  die();	  
}


add_action('wp_ajax_woocommerce_custom_addemptybox', 'woocommerce_custom_addemptybox_callback');
add_action('wp_ajax_nopriv_woocommerce_custom_addemptybox', 'woocommerce_custom_addemptybox_callback');

function woocommerce_custom_addemptybox_callback()
{
      $userid = get_current_user_id(); //This is product ID	  
	
      session_start();
	  if(isset($_SESSION['user_custom_session']))
	  {
		  $count = count($_SESSION['user_custom_session']);
			  
		  if( isset($_SESSION['user_custom_session']["BOX ".$count]) && count($_SESSION['user_custom_session']["BOX ".$count]) > 0 )
		  {
			  $count = $count + 1; 
		  } else {
			  $count = $count;
		  }	  
	  } else {
		  session_destroy();
		  $count = 1;
	  }	  
	
	   $_SESSION['user_custom_session']["BOX ".$count] = array();
	
	  echo $boxName = "BOX ".$count;
	  die();	  
}

add_action('wp_ajax_woocommerce_check_session', 'woocommerce_check_session_callback');
add_action('wp_ajax_nopriv_woocommerce_check_session', 'woocommerce_check_session_callback');

function woocommerce_check_session_callback()
{
      $userid = get_current_user_id(); //This is product ID	  
	
      session_start();
	  if(isset($_SESSION['user_custom_session']))
	  {
		 $count_array = count($_SESSION['user_custom_session']);
		 
		  if($count_array > 0)
		  {
			  if( isset($_SESSION['user_custom_session']["BOX ".$count_array]) && count($_SESSION['user_custom_session']["BOX ".$count_array]) > 0 )
			  {
					$count = $count_array;  
			  } else {
				  	$count = $count_array;
			  }	  
		  } else {
		  		session_destroy();
		 	 	$count = 1;			  
		  }	  			 
	  } else {
		  session_destroy();
		  $count = 1;
	  }	  
	
	  echo $boxName = "BOX ".$count;
	  die();	  
}

add_action('wp_ajax_woocommerce_check_session2', 'woocommerce_check_session2_callback');
add_action('wp_ajax_nopriv_woocommerce_check_session2', 'woocommerce_check_session2_callback');

function woocommerce_check_session2_callback()
{
      $userid = get_current_user_id(); //This is product ID	  
	
      session_start();
	
	  if( isset($_SESSION['update_box']) )	
	  {
			echo 'update';
	  		die();
	  }
	
	  if(isset($_SESSION['user_custom_session']))
	  {
		 $count_array = count($_SESSION['user_custom_session']);
		 
		  if($count_array > 0)
		  {
			  if( $count_array == 1 ) {
				  if( isset($_SESSION['user_custom_session']["BOX ".$count_array]) && count($_SESSION['user_custom_session']["BOX ".$count_array]) > 0 )
				  {
						$result = "HasNot";  
				  } else {
						$result = "Has";
				  }
			  }	else {
				  $result = "Has"; 
			  }	  
		  } else {
			  	$result = "HasNot";
		  }	  			 
	  } else {
		  	$result = "HasNot";
	  }	  
	
	  echo $result;
	  die();	  
}

add_action('wp_ajax_woocommerce_cart_session_enteries', 'woocommerce_cart_session_enteries_callback');
add_action('wp_ajax_nopriv_woocommerce_cart_session_enteries', 'woocommerce_cart_session_enteries_callback');

function woocommerce_cart_session_enteries_callback()
{
      $userid = get_current_user_id(); //This is product ID	  
      $boxtype = $_POST['boxtype']; //This is product ID	  
	
      session_start();
	  if( isset($_SESSION['user_custom_session'][$boxtype]) && count($_SESSION['user_custom_session'][$boxtype]) > 0 )
	  {
		  if( isset( $_SESSION['update_box'] ) ) {
		  	$result = $_SESSION['user_custom_session'][$_SESSION['update_box']];
		  } else {
 		 	 $result = $_SESSION['user_custom_session'][$boxtype];
		  }	  
	  } else {
		  $result = array();
	  }	  
	
	  echo json_encode($result);
	  die();	  
}

add_action('wp_ajax_custom_chk_login_data', 'custom_chk_login_data_callback');
add_action('wp_ajax_nopriv_custom_chk_login_data', 'custom_chk_login_data_callback');

function custom_chk_login_data_callback()
{
	$username = $_REQUEST['user_login'];
	$password = $_REQUEST['user_pass'];
	global $wpdb;
	
	$chkusername = $wpdb->get_row( 'SELECT * FROM `wp_users` WHERE user_email = "'.$username.'" OR user_login = "'.$username.'" ' );
	
	if( count( (array)$chkusername )  > 0 ) {
			
		if( wp_check_password( $password, $chkusername->user_pass, $chkusername->ID ) )
		{
			wp_set_current_user( $chkusername->ID, $chkusername->name );
       		wp_set_auth_cookie( $chkusername->ID, true, false );
			
			$response = array('result' => 'true');
		} else {
			$response = array('error' => "Incorrect Password");
		}	
	} else {	
		$response = array('error' => "Invalid username or useremail");
	}	
	
	echo json_encode($response);
	die();
}


add_filter( 'woocommerce_checkout_fields' , 'custom_override_checkout_fields' );

function custom_override_checkout_fields( $fields ) {
     $fields['billing']['billing_phone'] = array(
	        'label'     => __('Phone', 'woocommerce'),
    		'placeholder'   => _x('Phone', 'placeholder', 'woocommerce'),
    		'required'  => false,
    		'class'     => array('form-row-wide'),
    		'clear'     => true
     		);
	
     $fields['billing']['billing_suburb'] = array(
	        'label'     => __('Suburb', 'woocommerce'),
    		'placeholder'   => _x('Suburb', 'placeholder', 'woocommerce'),
    		'required'  => true,
    		'class'     => array('form-row-wide'),
    		'clear'     => true
     		);	

     		return $fields;
}

add_action( 'woocommerce_admin_order_data_after_shipping_address', 'my_custom_checkout_field_display_admin_order_meta', 10, 1 );

function my_custom_checkout_field_display_admin_order_meta($order){
    echo '<p><strong>'.__('Suburb').':</strong> ' . get_post_meta( $order->get_id(), '_billing_suburb', true ) . '</p>';
    echo '<p><strong>'.__('Phone').':</strong> ' . get_post_meta( $order->get_id(), '_billing_phone', true ) . '</p>';
	if( strlen(get_post_meta( $order->get_id(), 'Recipient Name', true )) > 0 ) {
    	echo '<p><strong>'.__('Recipient Name').':</strong> ' . get_post_meta( $order->get_id(), 'Recipient Name', true ) . '</p>';
	}
	if( strlen(get_post_meta( $order->get_id(), 'Recipient First Name', true )) > 0 ) {
    	echo '<p><strong>'.__('Recipient First Name').':</strong> ' . get_post_meta( $order->get_id(), 'Recipient First Name', true ) . '</p>';
	}
		if( strlen(get_post_meta( $order->get_id(), 'Recipient Last Name', true )) > 0 ) {
    	echo '<p><strong>'.__('Recipient Last Name').':</strong> ' . get_post_meta( $order->get_id(), 'Recipient Last Name', true ) . '</p>';
	}
	if( strlen(get_post_meta( $order->get_id(), 'Recipient Message', true )) > 0 ) {
    	echo '<p><strong>'.__('Recipient Message').':</strong> ' . get_post_meta( $order->get_id(), 'Recipient Message', true ) . '</p>';
	}	
    
	echo '<p><strong>'.__('Delivery Time').':</strong> ' . get_post_meta( $order->id, 'overnite_delivery', true ) . '</p>';
}


add_filter( 'woocommerce_checkout_fields' , 'custom_override_default_address_fields' );

function custom_override_default_address_fields( $fields ) {
     unset($fields['billing']['billing_company']);

	 $fields['billing']['billing_first_name']['priority'] = 10;
	 $fields['billing']['billing_last_name']['priority'] = 20;
	 $fields['billing']['billing_email']['priority'] = 30;
	 $fields['billing']['billing_phone']['priority'] = 40;
	 $fields['billing']['billing_country']['priority'] = 50;
	
     return $fields;
}

add_filter( 'customwoocommerce_proceed_to_checkout' , 'woocommerce_proceed_to_checkoutBTNNN' );
function woocommerce_proceed_to_checkoutBTNNN() {
       $checkout_url = WC()->cart->get_checkout_url();

		if( !is_user_logged_in() ) { ?>

       <a href="<?php echo $checkout_url; ?>" class="checkout-button button alt wc-forward"><?php _e( 'CheckOut As Guest', 'woocommerce' ); ?></a>
	   <span> OR </span>
	   <a href="<?php echo $checkout_url.'?guest=yes'; ?>" class="checkout-button button alt wc-forward"><?php _e( 'CheckOut & Create an account', 'woocommerce' ); ?></a>

		<div><span style="font-family: timelessregular;">Already have an account?</span> <span><a style="color: #f080ae;" href="javascript:void(0);" data-toggle="modal" data-target="#myModal">Sign In</a></span></div>
       <?php } else { ?>
		<a href="<?php echo $checkout_url; ?>" class="checkout-button button alt wc-forward"><?php _e( 'CheckOut', 'woocommerce' ); ?></a>
	  <?php } 
}


add_action( 'woocommerce_checkout_after_customer_details', 'my_custom_checkout_field' );

function my_custom_checkout_field( $checkout ) {
	
	session_start();
	
    echo '<div id="my_custom_checkout_field" style="display: none;">';

    woocommerce_form_field( 'my_field_name', array(
        'type'          => 'text',
        'class'         => array('my-field-class form-row-wide'),
        'placeholder'   => __('Enter something'),
        ), json_encode($_SESSION['user_custom_session']));

    echo '</div>';

}

add_action('woocommerce_checkout_process', 'my_custom_checkout_field_process');

function my_custom_checkout_field_process() {
    // Check if set, if its not set add an error.
    if ( ! $_POST['my_field_name'] )
        wc_add_notice( __( 'Please enter something into this new shiny field.' ), 'error' );
}

add_action( 'woocommerce_checkout_update_order_meta', 'my_custom_checkout_field_update_order_meta' );

function my_custom_checkout_field_update_order_meta( $order_id ) {
    if ( ! empty( $_POST['my_field_name'] ) ) {
        update_post_meta( $order_id, 'My Field', sanitize_text_field( $_POST['my_field_name'] ) );
    }
    if ( ! empty( $_POST['recipients_name'] ) ) {
        update_post_meta( $order_id, 'Recipient Name', sanitize_text_field( $_POST['recipients_name'] ) );
    }
        if ( ! empty( $_POST['recipients_fname'] ) ) {
        update_post_meta( $order_id, 'Recipient First Name', sanitize_text_field( $_POST['recipients_fname'] ) );
    }
        if ( ! empty( $_POST['recipients_lname'] ) ) {
        update_post_meta( $order_id, 'Recipient Last Name', sanitize_text_field( $_POST['recipients_lname'] ) );
    }
    if ( ! empty( $_POST['recipients_msg'] ) ) {
        update_post_meta( $order_id, 'Recipient Message', sanitize_text_field( $_POST['recipients_msg'] ) );
    }	
    if ( ! empty( $_POST['overnite_delivery'] ) ) {
        update_post_meta( $order_id, 'overnite_delivery', sanitize_text_field( $_POST['overnite_delivery'] ) );
    }
	
	global $wpdb;
	$deliveryoptions = $wpdb->get_row( 'SELECT * FROM `wp_zone_lists` WHERE postcode = "'.$_POST['billing_postcode'].'" ' ); 
	
	if( count((array)$deliveryoptions) > 0) {
		$deliverydate = $wpdb->get_row( 'SELECT * FROM `wp_custom_delivery_options` WHERE city = "'.$deliveryoptions->city.'" ' ); 
		
		update_post_meta( $order_id, 'delivery_date', sanitize_text_field( $deliverydate->delivery_date ) );
		update_post_meta( $order_id, '_city_method', sanitize_text_field( $deliveryoptions->city ) );
	}	
	
	session_start();
	
	unset($_SESSION['user_custom_session']);
}

function getProducts_info ( $product_id ) {
	
	$product = wc_get_product( $product_id );
	$image = wp_get_attachment_image_src( get_post_thumbnail_id( $product_id ), 'thumbnail' );
	
	if($product) {
		$main_prd_array = array(
						'name' => $product->get_title(),
						'image' => $image[0]
						);
	} else {
		$main_prd_array = array(
						'name' => $product_id,
						'image' => ''
						);	
	}
	
	return $main_prd_array;
}

add_action( 'woocommerce_admin_order_items_after_line_items', 'my_admin_products_view' );

function my_admin_products_view( $order_id ) {
	
	$all_cart_items = json_decode(stripslashes(get_post_meta( $order_id, 'My Field', true )));
		
	echo '<tbody id="order_line_items785">';
			foreach( $all_cart_items as $boxkey => $boxvalue ) {
			echo '<tr class="item785">
				<td class="thumb" colspan="2">
					<h2>'.$boxkey.'</h2>	
				</td>
				<td class="name">&nbsp;</td>
				<td class="name">&nbsp;</td>
				<td class="name">&nbsp;</td>
				<td class="name">&nbsp;</td>				
			</tr>';			
		foreach( $boxvalue as $itemsprd_key => $itemsprdqty ) {
			
			$prdinfo = getProducts_info( $itemsprd_key );
			
		echo '<tr class="item785">
				<td class="thumb">
					<div class="wc-order-item-thumbnail"><img src="'.$prdinfo['image'].'" class="attachment-thumbnail size-thumbnail wp-post-image" alt="" title="" width="150" height="150"></div>	
				</td>
				<td class="name">
					<a href="'.get_site_url().'/wp-admin/post.php?post='.$itemsprd_key.'&action=edit" class="wc-order-item-name">'.$prdinfo['name'].'</a>
					<div class="view">'.$itemsprdqty.'</div>
				</td>
				<td class="name">&nbsp;</td>
				<td class="name">&nbsp;</td>
				<td class="name">&nbsp;</td>				
			</tr>';
				}
			}	
		echo '</tbody>';
	
}	


function clear_session_cart(){
	
	session_start();

    if( !isset($_SESSION['user_custom_session']) && count($_SESSION['user_custom_session']) == 0 )
	{
		global $woocommerce;
		WC()->cart->empty_cart();
				
		$url = home_url( '/' );
		wp_redirect( $url );
		exit;
		
	}	
	
}
add_filter('woocommerce_before_cart', 'clear_session_cart');
add_filter('woocommerce_before_checkout_form', 'clear_session_cart');

add_action('wp_ajax_custompostcode_delivery', 'custompostcode_delivery_callback');
add_action('wp_ajax_nopriv_custompostcode_delivery', 'custompostcode_delivery_callback');

function custompostcode_delivery_callback()
{
	  global $wpdb;
	  $table_name = 'wp_zone_lists';
	  $table_name2 = 'wp_custom_delivery_options';
	  date_default_timezone_set('Australia/Sydney');
	  $date = date("d-m-Y"); 

	$check_hour = date('h');
	$check_session = date('a');	 
	
	  $deliveryoptions = $wpdb->get_results( 'SELECT * FROM '.$table_name.' WHERE postcode = "'.$_REQUEST['postcode'].'" AND suburb = "'.$_REQUEST['suburb'].'" ' );
	
		if( count($deliveryoptions) > 0 ) {
			
			if( $deliveryoptions[0]->city == 'Adelaide' || $deliveryoptions[0]->city == 'Melbourne' || $deliveryoptions[0]->city == 'Brisbane' || $deliveryoptions[0]->city == 'Sydney' ) {
				$options = '<div class="form cf"><section class="plan cf"><input name="overnite_delivery" id="basic"  value="DAYTIME DELIVERY 8am to 6pm" type="radio"><label class="basic-label four col" for="basic" style="padding: 20px 40px;">DAYTIME 8AM TO 6PM</label><input name="overnite_delivery" id="free" value="OVERNIGHT DELIVERY 12am to 7am" type="radio"><label class="free-label four col" for="free">OVERNIGHT 12AM TO 7AM <br/> <span class="doostep_msg" style="padding: 0px; color: #fff;">Left on your doorstep to collect in the morning.</span> </label></section></div>';
			} else {
				$options = '<div class="form cf"><section class="plan cf"><input name="overnite_delivery" id="basic" value="DAYTIME DELIVERY 8am to 6pm" type="radio"><label class="basic-label four col" for="basic" style="padding: 20px 40px;">DAYTIME 8AM TO 6PM</label><input name="overnite_delivery" id="free" value="OVERNIGHT DELIVERY 12am to 7am" type="radio"><label class="free-label four col" for="free">OVERNIGHT 12AM TO 7AM <br/> <span class="doostep_msg" style="padding: 0px; color: #fff;">Left on your doorstep to collect in the morning.</span> </label></section></div>';
			}
			
			$city = $deliveryoptions[0]->city;
			$chkcutoff = $wpdb->get_row( 'SELECT * FROM '.$table_name2.' WHERE city = "'.$city.'" ' );
			
			if( strtotime($chkcutoff->cut_off_date) >= strtotime($date) ) {
				if( ( strtotime($chkcutoff->cut_off_date) == strtotime($date) ) && $check_hour >= 5 && $check_session == 'pm' ) {
					$response = json_encode(array(
										'Result' => "error",
										'data' => "Sorry, the cut off date has either expired for this delivery or we don’t currently service this area."
										));
				} else {	
					$response = json_encode(array(
										'Result' => "true",
										'data' => $options
										));
				}
			} else {
				$response = json_encode(array(
										'Result' => "error",
										'data' => "Sorry, the cut off date has either expired for this delivery or we don’t currently service this area."
										));
			}	
			
		} else { 
			
			$response = json_encode(array(
						'Result' => "error",
						'data' => "Sorry ! We do not deliver in this Area."
						));		
		}
	
		echo $response;	
	    die();
}

add_action('admin_head', 'my_custom_fonts');

function my_custom_fonts() {
  echo '<style>
    body, td, textarea, input, select {
      font-family: "Lucida Grande";
      font-size: 12px;
    } 
	
	#woocommerce-order-items .woocommerce_order_items_wrapper.wc-order-items-editable #order_line_items { display: none; }
	#woocommerce-order-items .woocommerce_order_items_wrapper.wc-order-items-editable #order_shipping_line_items .display_meta { display: none; }
  </style>';
}


/*  
    create medical complaint start 
  */

class delivery_option_widget extends WP_Widget {

function __construct() {
parent::__construct(
'delivery_option-widget-area-left', 
__('Delivery Option', 'delivery_option-widget-area-left_domain'), 
array( 'description' => __( 'Sample widget based on WPBeginner Tutorial', 'delivery_option-widget-area-left_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );

//echo $args['before_widget'];
//if ( ! empty( $title ) )
//echo $args['before_title'] . $title . $args['after_title']; ?>
<style>
 /*13sep17 start*/
 .complete_sec{position: relative; left: 10%;}
 #delivery_status .col-xs-12 .tell_more_d{width:36%;}
        /*#delivery_status .col-xs-12 .col-xs-6 .option_city{ float: left; font-size: 13px; padding: 8px;  width: 100%; font-family: "timelessregular";
    text-transform: uppercase;}
        #delivery_status .col-xs-12 .col-xs-6 .option_date { color: #000; font-size: 12px; font-weight: bold; padding: 8px; font-family: "timelessregular"}
        #delivery_status  .delivery_titles > p {color: #000; font-family: "timelessbold"; font-size: 22px; text-align: center;}*/
		#delivery_status .col-xs-12 .col-xs-6 .option_city{ float: left; width: 100%; text-align: center;font-family: "timelessbold";}
  		#delivery_status .col-xs-12 .col-xs-6 .option_date {padding: 8px 0; right: 18px; text-align: center; font-family: "timelessregular"; font-size: 13.5px;letter-spacing: 1px;}
        #delivery_status  .delivery_titles > p {color: #000; font-family: "timelessbold"; font-size: 22px; text-align: center;}
        .delivery_info_box{clear: both;}
         #delivery_status  .delivery_titles{padding-bottom: 14px;}
          /*4-Nov-17 Start*/
        #delivery_status .checTitle {clear: both;display: block;font-family: timelessregular;font-size: 12px;margin: 0 auto;text-align: center;width: 90%;}
        /*4-Nov-17 End*/
        
        /*13sep17 end*/
        @media (min-width: 10px) and (max-width:320px)
        {
            /*13sep17 start*/
			.extra_space{width:100%;}
            #delivery_status .col-xs-12 .col-xs-6 .option_city{float: left; font-size: 13px;  width: 100% !important;}
            #delivery_status .col-xs-12 .col-xs-6 .option_date { font-size: 13px; width: 100%; font-family: "timelessregular"; }
            /*13sep17 end*/
        }
        @media (min-width: 10px) and (max-width: 480px) 
        {
            /*13sep17 start*/
			.extra_space{width:100%;}
            #delivery_status .col-xs-12 .col-xs-6 .option_city{float: left; font-size: 13px;  width: 100% !important;}
            #delivery_status .col-xs-12 .col-xs-6 .option_date { font-size: 13px;  width: 100%; font-family: "timelessregular"; }
            /*13sep17 end*/
        }
        @media (min-width: 321px) and (max-width:480px)
        {
            /*13sep17 start*/
			.extra_space{width:100%;}
            #delivery_status .col-xs-12 .col-xs-6 .option_city{float: left; font-size: 13px;  width: 100%;}
            #delivery_status .col-xs-12 .col-xs-6 .option_date { font-size: 13px;  width: 100%; font-family: "timelessregular"; }
            /*13sep17 end*/
        }
       @media (min-width: 481px) and (max-width:767px)
        {
            /*13sep17 start*/
			.extra_space{width:100%;}
             #delivery_status .col-xs-12 .col-xs-6 .option_city{float: left; font-size: 13px;  width: 100%;}
            #delivery_status .col-xs-12 .col-xs-6 .option_date { font-size: 13px; width: 100%; font-family: "timelessregular"; }
            /*13sep17 end*/
        }
        @media (min-width: 768px) and (max-width:990px)
        {
            /*13sep17 start*/
            #delivery_status .col-xs-12 .col-xs-6 .option_city{ float: left; font-size: 13px; padding: 8px; width: 100%;}
            #delivery_status .col-xs-12 .col-xs-6 .option_date { font-size: 13px; font-weight: bold; padding: 8px; width: 100%; font-family: "timelessregular"; }
            /*13sep17 end*/
        }
         @media (min-width: 768px) and (max-width:1024px)
        {
            /*13sep17 start*/
            #delivery_status .col-xs-12 .col-xs-6 .option_city{ float: left; font-size: 13px; padding: 8px; width: 100%;}
            #delivery_status .col-xs-12 .col-xs-6 .option_date { font-size: 13px; font-weight: bold; padding: 8px; width: 100%; font-family: "timelessregular"; }
            /*13sep17 end*/
        }        
</style>

<div id="delivery_status" class="col2-set chkout5">
                <div class="delivery_titles">
                    <p>CHECK YOUR DELIVERY DATE</p>
                    <!-- 4-Nov-17 Start -->
                    <span class="checTitle">If you won’t be home on this date, we recommend using your workplace or an alternative address. If cakes are left outside they WILL melt.</span>
                    <!-- 4-Nov-17 End -->
                </div>
                <div class="col-xs-12">
                <?php 
                global  $wpdb;
                $tablenname="wp_custom_delivery_options";
                $results = $wpdb->get_results( "SELECT * FROM $tablenname" );
                $i=0;
	 			date_default_timezone_set('Australia/Sydney');
				$date = date("d-m-Y"); 
                foreach($results as $data){
                    if($i%2 == 0)
                        $class=" option_left";
                    else
                        $class="";
                    $city=$data->city;
                    $cut_off_date=$data->cut_off_date;
                    $delivery_date=$data->delivery_date;
                    $cut_off_dates= date(  "jS F", strtotime( $cut_off_date ) );
                    $delivery_dates= date(  "jS F", strtotime( $delivery_date ) );
					
					$date1=date_create($data->cut_off_date);
					$date2=date_create($date);
					$diff=date_diff($date1,$date2);
					$difference_value = $diff->format("%R%a");

					$check_hour = date('h');
					$check_session = date('a');
                    ?>
                    <!--div class="col-xs-6 tell_more_d">
                        <div class="option_city<?php //echo $class; ?>"><?php //echo $city; ?>:</div><div class="option_date"><?php //echo $delivery_dates; ?></div>
                   		
                    </div--> 
					
					<div class="col-xs-6 extra_space">
                        <div class="option_city"><?php echo $city; ?>:&nbsp;&nbsp;<?php echo $delivery_dates; ?></div>
                        <div class="option_date"><?php if($difference_value <= 0 ){							if( ( $difference_value == 0 ) && $check_hour >= 5 && $check_session == 'pm' ) {
								echo "ORDERS HAVE CLOSED FOR THIS DELIVERY";
							} else {	
								echo "Order up until 5pm AEST ".$cut_off_dates;
							}
}else{ echo "ORDERS HAVE CLOSED FOR THIS DELIVERY";}?></div>
                   
                    </div> 
                <?php $i++;} ?>
                         
                     </div>
                
            </div>
<?php
echo $args['after_widget'];
}
		

public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'New title', 'delivery_option-widget-area-left_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<?php 
}

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
return $instance;
}
} 

function delivery_option_load_widget() {
	register_widget( 'delivery_option_widget' );   
}
add_action( 'widgets_init', 'delivery_option_load_widget' );


function mysite_woocommerce_order_status_completed( $order_id ) {
   
	$boxtype = json_decode(stripslashes(get_post_meta( $order_id, 'My Field', true )));
	
	foreach( $boxtype as $singboxtype ){
		foreach( $singboxtype as $singboxkey => $singboxvalue ) {
			
			$earlier_val = ( get_post_meta( $singboxkey, '_Inventory_Stock', true ) )? get_post_meta( $singboxkey, '_Inventory_Stock', true ) : 0 ;
			
			$new_val = $earlier_val - $singboxvalue;
			
			update_post_meta( $singboxkey, '_Inventory_Stock', sanitize_text_field( $new_val ) );	
		}	
	}	
	
}
add_action( 'woocommerce_order_status_completed', 'mysite_woocommerce_order_status_completed', 10, 1 );


add_filter('show_admin_bar', '__return_false');

add_action( 'template_redirect', 'woo_custom_redirect_after_purchase' );
function woo_custom_redirect_after_purchase() {
	
    global $wp;

    if ( is_checkout() && ! empty( $wp->query_vars['order-received'] ) ) {
        $order_id  = absint( $wp->query_vars['order-received'] );
	
		wp_redirect( 'https://sweetnectar.com.au/thank-you?order_id='.$order_id );
	}
}




/********************************** In Transit Status **************************************/

add_action( 'init', 'register_my_new_order_statuses' );

function register_my_new_order_statuses() {
    register_post_status( 'wc-in-transit', array(
        'label'                     => _x( 'In-Transit', 'Order status', 'woocommerce' ),
        'public'                    => true,
        'exclude_from_search'       => false,
        'show_in_admin_all_list'    => true,
        'show_in_admin_status_list' => true,
        'label_count'               => _n_noop( 'In-Transit <span class="count">(%s)</span>', 'In-Transit<span class="count">(%s)</span>', 'woocommerce' )
    ) );
}

add_filter( 'wc_order_statuses', 'my_new_wc_order_statuses' );

// Register in wc_order_statuses.
function my_new_wc_order_statuses( $order_statuses ) {
    $order_statuses['wc-in-transit'] = _x( 'In-Transit', 'Order status', 'woocommerce' );

    return $order_statuses;
}

function insert_new_css() {
   echo '<style>
   .in-transit.tips { background: url("'.get_stylesheet_directory_uri().'/images/in-transit.png") no-repeat scroll 50% center rgb(45, 178, 0) !important; }
   </style>';
}
add_action('admin_head', 'insert_new_css');

add_action('admin_footer-edit.php', 'custom_bulk_admin_footer');
function custom_bulk_admin_footer() {
  
  global $post_type;
  
  if($post_type == 'shop_order') {
    ?>
    <script type="text/javascript">
      jQuery(document).ready(function() {
        jQuery('<option>').val('mark_in-transit').text('<?php _e('Mark In-Transit')?>').appendTo("select[name='action']");
        jQuery('<option>').val('mark_in-transit').text('<?php _e('Mark In-Transit')?>').appendTo("select[name='action2']");
      });
    </script>
    <?php
  }
}

function so_39252649_remove_processing_status( $statuses ){
	
    if( isset( $statuses['wc-pending'] ) ){
        unset( $statuses['wc-pending'] );
    }
    if( isset( $statuses['wc-on-hold'] ) ){
        unset( $statuses['wc-on-hold'] );
    }	
    if( isset( $statuses['wc-cancelled'] ) ){
        unset( $statuses['wc-cancelled'] );
    }
    if( isset( $statuses['wc-refunded'] ) ){
        unset( $statuses['wc-refunded'] );
    }
    if( isset( $statuses['wc-failed'] ) ){
        unset( $statuses['wc-failed'] );
    }
	
    return $statuses;
}
add_filter( 'wc_order_statuses', 'so_39252649_remove_processing_status' );


add_action( 'woocommerce_order_status_changed', 'order_status_shipped_custom');
function order_status_shipped_custom($orderid) {
	change_order_status($orderid);
}

function change_order_status($orderid) {
    $order = new WC_Order($orderid);
    $email = get_post_meta( $orderid, '_billing_email' )[0];
	
	onesignal( $orderid );
	
    if($order->status == 'in-transit') {
        send_this($email, $order);
    }
}

function onesignal($orderid) {
	
	$name = get_post_meta( $orderid, '_billing_first_name' )[0].' '.get_post_meta( $orderid, '_billing_last_name' )[0];
	$order = new WC_Order($orderid);
	
	global $wpdb;
	
	if( $order->status == 'processing' ) { 
		$message = "Dear , Thanks for placing an order with us. We will update you once it is shipped.";
	} else if( $order->status == 'in-transit' ) { 
		$message = "Dear , Your Order #".$orderid." has been shipped.";
	} else if( $order->status == 'completed' ) {
		$message = "Dear , Your Order #".$orderid." has been delivered. Thanks for ordering with Sweet Nectar.";
	} else {
		return;
	}	
	
	$user = $order->get_user_id();
	
	if($user) {
		$resultdata = $wpdb->get_results( 'SELECT * FROM `wp_sweetnector_authcode` WHERE user_id = "'.$user.'" ' );
	} else {
		return;	
	}	
	
	if( count($resultdata) > 0 ) {
		foreach($resultdata as $sing_resultdata)
		{
			$obj_token[] = $sing_resultdata->obj_id;
		}
	} else {
		return;	
	}	
	
	$content = array(
				"en" => $message
				);
	
	$headings = array(
				"en" => "Order Update"
				);

	$fields = array(
		'app_id' => "7270f522-8be9-4a62-9f79-4cdd1fb37e19",
		'include_player_ids' => $obj_token,
		'contents' => $content,
		'headings' => $headings,
	);				

	$fields = json_encode($fields);
	//print("\nJSON sent:\n");
	//print($fields);

	
	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
											   'Authorization: Basic NTVkZmQ0ZTMtMDU5NC00YzBjLThiN2EtNjUxYWZhMjY0ZGY0'));
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	curl_setopt($ch, CURLOPT_HEADER, FALSE);
	curl_setopt($ch, CURLOPT_POST, TRUE);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

	$response = curl_exec($ch);
	curl_close($ch);
	
}

function send_this($email, $order) {
 
    $headers = 'From: Sweet Nectar <hello@sweetnectar.com.au>' . "\r\n";
    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
     
    $subject = 'Your Order has been Mark as In-Transit';
 	$user = $order->get_user_id();
$user_info = get_userdata($user);
	
$name = get_post_meta( $order->get_id(), '_billing_first_name' )[0].' '.get_post_meta( $order->get_id(), '_billing_last_name' )[0];	
	
$delivery_date = get_post_meta( $order->get_id(), 'delivery_date', true );
    $message = '<html>
  <head>
<style>
tr,td{
	border:none;
}
.t1 {
    background: #ec89bb;
    color: #fff;
    height: 50px;
    width: 600px;
	font-size:20px;
	border: none;
	
}
@media only screen and (max-width: 639px){
    .mobileHide { 
        display:block !important; 
    }
}
<!--@media screen and (max-width:600px) {
    td[class="head"] {
        font-size: 18px !important;
    }
}-->
</style>
  </head>
  <body class="">
<table class="container" align="center" border="2px solid #000" cellpadding="0" cellspacing="0" width="100%" style="position:relative; text-align:center; max-width: 600px">
<tr style="text-align: center;border: none;">
<td style="border: none;"><a href="https://sweetnectar.com.au"><img src="https://sweetnectar.com.au/wp-content/uploads/2017/09/SN-logo.png" alt="" width="150" height="150" class="alignnone size-full wp-image-791"></a></td>
</tr>


<tr style="text-align: center;border: none;">
<td style="font-weight: bold;font-family: Pacifico regular;font-size: 30px;padding: 20px;border: none;">
<img src="https://sweetnectar.com.au/wp-content/uploads/2017/10/left.jpg" alt="" class="alignnone size-full wp-image-800" style="position:absolute;left:0px;margin-top: -18%; width: 20%;"><i><b>Hi <strong>' . esc_html( $name ) . '</strong>!</b></i>
<img src="https://sweetnectar.com.au/wp-content/uploads/2017/10/right.jpg" alt="" class="alignnone size-full wp-image-801" style="position:absolute;right:0px;margin-top: -18%;width: 20%;"></td>
</tr>
<tr style="text-align: center;border: none;">
<td style="font-size: 20px;font-family: Open Sans;padding-top: 40px;opacity: 0.7;border: none;">News on your order! It`s been marked as:</td>
</tr>
<tr style="text-align: center;border: none;">
<td style="font-size: 20px;font-family: Open Sans;padding-top: 25px;padding-bottom: 35px;font-weight: bold;color: #ec89bb;border: none;">On board with driver</td>
</tr>

<tr style="text-align: center;border: none;">
<td class="t1" style="border: none;background: #ec89bb;color: #fff;height: 50px;width: 600px;font-size: 20px;">Your order is due for delivery '.date("jS F",strtotime($delivery_date)).'</td>
</tr>
<tr style="text-align: center;border: none;">
<td style="background-image: url(https://sweetnectar.com.au/wp-content/uploads/2017/09/shoppimg.jpg);height: 140px;width: 100%;border: none;"> 
    <h4 style="color:white;text-align:center;font-family:BebasNeueBold; font-size: 15px;line-height: 30px;">Your box will arrive chilled however it must not be left outside on a hot day or you cakes WILL melt!
  </h4></td>
</tr>
<tr style="text-align: center;border: none;">
<td style="font-size: 30px;text-align: center;padding-top: 40px;font-family: Pacifico regular;border: none;"><b><i>not long now...!</i></b></td>
</tr>
<tr style="text-align: center;border: none;">
<td style="text-align: center;padding-top: 50px;padding-bottom: 30px;font-size: 16px;font-weight: bold;border: none;">Sweet Nectar Team:)</td>
</tr>

</table>
  </body>
</html>';  

    $response = wp_mail( $email, $subject, $message, $headers );
}

/* Add Popup Image for products Start */

function misha_include_myuploadscript() {
	/*
	 * I recommend to add additional conditions just to not to load the scipts on each page
	 * like:
	 * if ( !in_array('post-new.php','post.php') ) return;
	 */
	if ( ! did_action( 'wp_enqueue_media' ) ) {
		wp_enqueue_media();
	}
 
 	wp_enqueue_script( 'myuploadscript', get_stylesheet_directory_uri() . '/customscript.js', array('jquery'), null, false );
}
 
add_action( 'admin_enqueue_scripts', 'misha_include_myuploadscript' );

/*
 * @param string $name Name of option or name of post custom field.
 * @param string $value Optional Attachment ID
 * @return string HTML of the Upload Button
 */
function misha_image_uploader_field( $name, $value = '') {
	$image = ' button">Upload image';
	$image_size = 'full'; // it would be better to use thumbnail size here (150x150 or so)
	$display = 'none'; // display state ot the "Remove image" button
 
	if( $image_attributes = wp_get_attachment_image_src( $value, $image_size ) ) {
 
		// $image_attributes[0] - image URL
		// $image_attributes[1] - image width
		// $image_attributes[2] - image height
 
		$image = '"><img src="' . $image_attributes[0] . '" style="max-width:95%;display:block;" />';
		$display = 'inline-block';
 
	} 
 
	return '
	<div>
		<a href="#" class="misha_upload_image_button' . $image . '</a>
		<input type="hidden" name="' . $name . '" id="' . $name . '" value="' . $value . '" />
		<a href="#" class="misha_remove_image_button" style="display:inline-block;display:' . $display . '">Remove image</a>
	</div>';
}


/*
 * Add a meta box
 */
add_action( 'admin_menu', 'misha_meta_box_add' );
 
function misha_meta_box_add() {
	add_meta_box('mishadiv', // meta box ID
		'Popup Image', // meta box title
		'misha_print_box', // callback function that prints the meta box HTML 
		'product', // post type where to add it
		'normal', // priority
		'high' ); // position
}
 
/*
 * Meta Box HTML
 */
function misha_print_box( $post ) {
	$meta_key = 'second_featured_img';
	echo misha_image_uploader_field( $meta_key, get_post_meta($post->ID, $meta_key, true) );
}
 
/*
 * Save Meta Box data
 */
add_action('save_post', 'misha_save');
 
function misha_save( $post_id ) {
	if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) 
		return $post_id;
 
	$meta_key = 'second_featured_img';
 
	update_post_meta( $post_id, $meta_key, $_POST[$meta_key] );
 
	// if you would like to attach the uploaded image to this post, uncomment the line:
	// wp_update_post( array( 'ID' => $_POST[$meta_key], 'post_parent' => $post_id ) );
 
	return $post_id;
}

/* Add Popup Image for products End */