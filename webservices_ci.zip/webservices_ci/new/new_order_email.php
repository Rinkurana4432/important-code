<?php
/**
 * Template Name: New_order_email
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */
?>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="emailstyle.css">
<table class="container" align="center" border="2px solid #000" cellpadding="0" cellspacing="0" width="100%" style="position:relative; text-align: center; max-width: 600px">
<tr style="text-align: center;border: none;">
<td style="border: none;"><img src="http://cloudart.com.au/projects/SweetNector/wp-content/uploads/2017/09/SN-logo.png" alt="" width="150" height="150" class="alignnone size-full wp-image-791"></td>
</tr>


<tr style="text-align: center;border: none;">
<td style="font-weight: bold;font-family: pacific regular;font-size: 30px;margin-top: 100px;padding: 20px;border: none;">
<img src="http://cloudart.com.au/projects/SweetNector/wp-content/uploads/2017/09/side1.jpg" alt="" width="117" height="263" class="alignnone size-full wp-image-800" style="position:absolute;left:0px; margin-top: -18%;"><i>Hi Jessie!</i>
<img src="http://cloudart.com.au/projects/SweetNector/wp-content/uploads/2017/09/side2.jpg" alt="" width="117" height="263" class="alignnone size-full wp-image-801" style="position:absolute;right:0px; margin-top: -18%;"></td>
</tr>
<tr style="text-align: center;border: none;">
<td style="border: none;"><img src="http://cloudart.com.au/projects/SweetNector/wp-content/uploads/2017/09/bg2.png" alt="" width="265" height="184" class="alignnone size-full wp-image-828">
</td></tr>
<tr style="text-align: center;border: none;">
<td style="font-size: 20px;font-family: open sans;padding-top: 25px;padding-bottom: 30px;border: none;">Your order has been received!
</td>
</tr>
<tr style="text-align: center;border: none;">
<td class="t1" style="border: none;background: #ec89bb;color: #fff;height: 50px;width: 600px;font-size: 20px;">Your order is due for delivery 2nd July.</td>
</tr>
<tr style="text-align: center;border: none;">
<td style="background-image: url(http://cloudart.com.au/projects/SweetNector/wp-content/uploads/2017/09/bg.jpg);height: 140px;width: 100%;border: none;"> 
    <h4 style="color:white;text-align:center;font-family:BebasNeueBold; font-size: 15px;line-height: 30px;">YOUR BOX WILL NEED TO BE CHILLED SO PLEASE ORGANISE FOR <br> IT TO BE POPPED INTO THE FRIDGE UPON ARRIVAL
  </h4></td>
</tr>
<tr style="text-align: center;border: none;">
<td style="border: none;">
<hr style="align=center; margin-left:30px; margin-right:30px; margin-top:30px;margin-bottom: 20px;">
<img src="http://cloudart.com.au/projects/SweetNector/wp-content/uploads/2017/09/social2.jpg" alt="" width="57" height="53" class="alignnone size-full wp-image-798">
<img src="http://cloudart.com.au/projects/SweetNector/wp-content/uploads/2017/09/social1.jpg" alt="" width="57" height="53" class="alignnone size-full wp-image-797">
<hr style="align=center; margin-left:30px; margin-right:30px;margin-top: 20px; opacity: 0.3;">
</td>

</tr>
<tr style="text-align: center;line-height: 1;border: none;">
<td style="border: none;">
<div class="row">
<div class="left" style="width: 295px;float: left;padding-bottom: 20px;">
<p class="head" style="color: #ec89bb;font-size: 65px;text-align: left;padding-left: 30px;margin-top: 0px;opacity: 0.3;">P.S</p>
<p style="margin-left: 30px; margin-top: -50px;text-align: left;margin-bottom: 0px; font-family:open sans;">To keep Up to date with new flavors make sure you download our app available for android & iphone 'Sweet Nectar' as a user of th app you can also be in the running to win competitions & receive instant updates when your goodless are on their way!</p>
<img src="http://cloudart.com.au/projects/SweetNector/wp-content/uploads/2017/09/appstore.png" alt="" width="100" height="100" class="alignnone size-full wp-image-825" style="margin-left: -15%;">
<img src="http://cloudart.com.au/projects/SweetNector/wp-content/uploads/2017/09/app1.png" alt="" width="100" height="100" class="alignnone size-full wp-image-813">
<p style="font-size:20px; margin-top: -5px; margin-left:-20%; font-weight:bold; font-family:open sans;">Sweet Nectar Team:)</p>
 </div><!--left-->
<div class="right" style="width: 300px;float: right;margin-top: 50px;">
<img src="http://cloudart.com.au/projects/SweetNector/wp-content/uploads/2017/09/mobile.png" alt="" width="263" height="405" class="alignnone size-full wp-image-820">
</div><!--right-->
</div><!--row-->
</td>
</tr>

</table>
<style>
tr,td{
	border:none;
}
button.btn.btn-default {
    background: #ec89bb;
    color: #fff;
    height: 50px;
    width: 600px;
	font-size:22px;
	border: none;
	
}
.left
{
	width:295px;
	float:left;
	padding-bottom:20px;
}
.right
{
	width:300px;
	float:right;
	margin-top: 50px;
	
}
p.head {
    color:#ec89bb;
    font-size: 65px;
    text-align: left;
    padding-left: 30px;
	margin-top: 0px;
	opacity: 0.3;
}
.t1 {
    background: #ec89bb;
    color: #fff;
    height: 50px;
    width: 600px;
	font-size:20px;
	border: none;
	
}

	@media(max-width:768px)
	{
		.head
		{
			font-size:16px;
	}
}

</style>
