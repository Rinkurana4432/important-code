<?php

$user_email = $_GET['user_email'];
$hash = $_GET['hash'];

mysql_connect("localhost","s3cur3_user","s3cur3_user");
mysql_select_db("s3cur3_user");


$sql = mysql_query(" select id from `user_details` where `user_email`='$user_email' ");
$count = mysql_num_rows($sql);
$result = mysql_fetch_object($sql);

if( $count < 0 )
{
	$mesge = "email in-correct";
}
else
{

$user_id = $result->id;
$sql_hash = mysql_query(" select * from `user_info` where `user_id`='$user_id' ");

$result_hash = mysql_fetch_object($sql_hash);

$hash_code1 = $result_hash->hash_code;


	if( $hash == $hash_code1 )
	{
		$hashcodd = md5(rand(0,1000));

		$sql = mysql_query(" update `user_info` set `active` = 1,`hash_code`='$hashcodd' where `user_id`='$user_id' ");

		$mesge = "Your Account is Activated";
	}
	else
	{

		$mesge = "Invalid Activation link";
	}

}
?>
<html>
<body>
<div id="main_body">
	<div id="inner_wrapper">
		<span class="msg"><?php echo $mesge; ?></span>
	</div>
</div>
</body>
</html>
