<?php
defined('BASEPATH') OR exit('No direct script access allowed');

	class Login extends CI_Controller {
		function __construct() {
			parent::__construct();
			$this->load->helper('url');
			$this->load->library('session');
			}

	
	
	public function index()
		{
			$this->load->view('login_view');
		}

	
	
	public function login_admin(){	
			 $email = $_REQUEST['email'];
			 $password = md5($_REQUEST['password']);
			 $this->load->model('m_wallet');
			 $result =  $this->m_wallet->login_user($email,$password);
			 if($result == false){
			   echo 'false';
			 }
		 }
		
	public function view_data(){
	  $this->load->view('include/header');
	  $this->load->view('include/sidebar');
	   $this->load->model('m_wallet');
				 $data['row'] = $this->m_wallet->view_data();         
				  $this->load->view('view_users',$data);	
	   $this->load->view('include/footer');	
	  }
	

	public function edit_user(){
		$this->load->view('include/header');
		$this->load->view('include/sidebar');
		$id = $_REQUEST['id'];
		$this->load->model('m_wallet');
		$val_data['user'] =  $this->m_wallet->edited_user($id);
		$this->load->view('edit_user',$val_data);	
		$this->load->view('include/footer');	
	}
	
	
	public function update(){
		 $id =  $_REQUEST['id'];	
		 $name = $_REQUEST['name'];
		 $user_email = $_REQUEST['user_email'];
		 $mobile =  $_REQUEST['mobile'];
		 $update_value = array(
					'id'=>$id,
					'name'=>$name,
					'user_email'=>$user_email,
					'mobile'=>$mobile
					);
		$this->load->model('m_wallet');
		$update_data = $this->m_wallet->update_user_data($id,$update_value);

		if($update_data == 0){
					echo 'true';
				 }else{
					  echo 'false';
				 }
		}
	
	public function login_usrname(){
		$login_user_id = $_SESSION['id'];	
		$this->load->model('m_wallet');
		$usrs['l_id'] =  $this->m_wallet->select_loginusr_id($login_user_id);
	    }
	
	
	
	public function create_store(){
		$this->load->view('include/header');
		$this->load->view('include/sidebar');
		$this->load->view('create_store');
		$this->load->view('include/footer');
	  }
	
	
	
	public function add_store(){
		$name = $_REQUEST['name'];
		$storename = $_REQUEST['storename'];
		$email = $_REQUEST['email'];
		$mobile = $_REQUEST['mobile'];
		$address = $_REQUEST['address'];
		$password = md5($_REQUEST['password']);
		$insert_store_data = array(
						   'name'=>$name, 
						   'storename'=>$storename, 
						   'email'=>$email, 
						   'mobile'=>$mobile, 
						   'address'=>$address, 
						   'password'=>$password 
						   );
		$this->load->model('m_wallet');
		$ins_val = $this->m_wallet->create_store_model($email,$insert_store_data);
		if($ins_val > 0){
		echo 'Insert Successfully';
				}else{
				  echo 'Email ID already exists';
				}
	 }	
	
	
	
	public function view_store(){
		$this->load->view('include/header');
		$this->load->view('include/sidebar');
		$this->load->model('m_wallet');
				 $data['row'] = $this->m_wallet->view_store_data();    
				 $this->load->view('view_store',$data);

		$this->load->view('include/footer');
	}
	
	
	
	public function delete_store(){
			$id = $_REQUEST['id'];
			$this->load->model('m_wallet');
			   $resp = $this->m_wallet->delete_store_model($id);
			 if($resp){
				 echo 'Store Deleted Successfully';
			 }else{
			echo 'Store not Deleted';	 
			 }
	}

	
	
	public function edit_store(){
		$this->load->view('include/header');
		$this->load->view('include/sidebar');
		$id = $_REQUEST['id'];
		$this->load->model('m_wallet');
		$store_data['store'] =  $this->m_wallet->editedstore($id);
		$this->load->view('edit_store',$store_data);	
		 $this->load->view('include/footer');	
	}
		
		
	public function update_store(){
		 $id =  $_REQUEST['id'];	
		 $name = $_REQUEST['name'];
		 $storename = $_REQUEST['storename'];
		 $email = $_REQUEST['email'];
		 $mobile =  $_REQUEST['mobile'];
		 $address =  $_REQUEST['address'];
		 $password = $_REQUEST['password'];

			if($password == '' ){
			$update_store_value = array('name'=>$name,'storename'=>$storename,'email'=>$email,'mobile'=>$mobile,'address'=>$address);
			}else{
			$update_store_value = array('name'=>$name,'storename'=>$storename,'email'=>$email,'mobile'=>$mobile,'address'=>$address,'password'=>md5($password));	
			}
			$this->load->model('m_wallet');
			$update_data = $this->m_wallet->update_store_data($id,$update_store_value);
			if($update_data > 0){
						echo 'true';
					  }else{
						  echo 'false';
					  }
	}

	
	
	public function allot_funds(){
		$this->load->view('include/header');
		$this->load->view('include/sidebar');
		$this->load->model('m_wallet');
		$store['fnds'] = $this->m_wallet->store_totl();
		$this->load->view('allot_funds',$store);
		$this->load->view('include/footer');
	}	
	
	
	

	public function add_amount_tostore(){
		$store_id = $_REQUEST['store_id'];
		$amount = $_REQUEST['amount'];
		$current_date = date('Y-m-d H:i:s');
		$val = array(
					'store_id'=>$store_id,
					'amount'=>$amount,
					'created_date'=>$current_date, 
					);
	  $this->load->model('m_wallet');	
	  $ins_amt = $this->m_wallet->storeadd_amnt($val);
	   if($ins_amt > 0){
			   echo 'true';
				}else{
				  echo 'false';
				}

	}

	
	
	public function view_add_amountdtl(){
		$this->load->view('include/header');
		$this->load->view('include/sidebar');
		$this->load->model('m_wallet');
		$amnt['ddtl'] = $this->m_wallet->amount_add_dtl();
		$this->load->view('added_amountdtl',$amnt);
		$this->load->view('include/footer');
	}	
	
		
	public function pending_payment(){
		$this->load->view('include/header');
		$this->load->view('include/sidebar');
		$this->load->model('m_wallet');
		$pending_amt['val'] = $this->m_wallet->pending_amount_tostore();

		$this->load->view('pending_amountdtl',$pending_amt);
		$this->load->view('include/footer');
	}
		
		
	public function paypending_payment(){
	$id = $_REQUEST['id'];
	$this->load->model('m_wallet');
	    $resp = $this->m_wallet->paypayment_anddelete($id);
		
		$dadta = $this->m_wallet->insert_pending_payment($resp);
		if($dadta > 0 ){
			echo 'true';
			}else{
		echo 'false';
		    }
	}	
	
	
	
	
	
	public function logout()
	{
		$this->session->sess_destroy();
		redirect('login/index');
	}	
	
	
	
	
	
	
	
	
	
	
}
