<?php
defined('BASEPATH') OR exit('No direct script access allowed');

	class Webservice extends CI_Controller {
		function __construct() {
			parent::__construct();
			$this->load->helper('url');
			$this->load->library('session');
			}
			
				/********************** Sign up********************/
			public function signup()
				{
					if( isset($_REQUEST['user_name']) &&  isset($_REQUEST['user_email']) && isset($_REQUEST['user_pwd']) && isset($_REQUEST['mobile_no']) )
					{		

						$this->load->model('webservicemodel','',true);

						$data['Result']=$this->webservicemodel->signupmodel( $_REQUEST['user_name'],$_REQUEST['user_email'],$_REQUEST['user_pwd'],$_REQUEST['mobile_no'] );

					}
					else
					{
						echo '{"Status":"false", "Data":[{"result":"Data is missing"}]}';	
					}		
				}
		
		
		/**********************Login********************/
		public function login()
			{
				if( isset($_REQUEST['user_email']) && isset($_REQUEST['user_pwd']) )
				{
					
					$this->load->model('webservicemodel','',true);
					$data['Result']=$this->webservicemodel->loginmodel( $_REQUEST['user_email'],$_REQUEST['user_pwd'] );

				}
				else
				{
					echo '{"Status":"false", "Data":[{"result":"Data is missing"}]}';	
				}
			}
		/********************** Change Password ********************/
		function changepwd()
		{
				if(isset($_REQUEST['auth_code']) && isset($_REQUEST['user_pwd']) && isset($_REQUEST['new_pwd']))
				{
					$this->load->model('webservicemodel','',true);
					$data['res'] = $this->webservicemodel->verifyauthmodel($_REQUEST['auth_code']);
					if($data['res'] == 1)

					$data['Result'] = $this->webservicemodel->changepwdmodel($_REQUEST['auth_code'],$_REQUEST['user_pwd'],$_REQUEST['new_pwd']);
				}
				else
				{
					echo '{"Status":"false", "Data":[{"result":"Data is missing"}]}';	
				}	
		}

	/*******************************Forgot Password**************************************/	
		public function forgotpwd()
			{
			if(isset($_REQUEST['user_email']))
			{
				$this->load->model('webservicemodel','',true);
				$data['Result'] = $this->webservicemodel->forgotpwdmodel($_REQUEST['user_email']);
			}
			else
			{
				echo '{"Status":"false", "Data":[{"result":"Data is missing"}]}';	
			}	
		}
	/********************** User Pin ********************/
	public function userpin()
	{
			if(isset($_REQUEST['auth_code']) && isset($_REQUEST['user_pin']))
			{
				$this->load->model('webservicemodel','',true);
				$data['res'] = $this->webservicemodel->verifyauthmodel($_REQUEST['auth_code']);
				if($data['res'] == 1)
				$data['Result'] = $this->webservicemodel->userpinmodel($_REQUEST['auth_code'],$_REQUEST['user_pin']);
			}
			else
			{
				echo '{"Status":"false", "Data":[{"result":"Data is missing"}]}';	
			}	
	}
	/********************** Forgot Pin ********************/
	public function forgotpin()
	{
			if(isset($_REQUEST['user_email']))
			{
				$this->load->model('webservicemodel','',true);
				$data['Result'] = $this->webservicemodel->forgotpinmodel($_REQUEST['user_email']);
			}
			else
			{
				echo '{"Status":"false", "Data":[{"result":"Data is missing"}]}';	
			}	
	}
/********************** Check Pin ********************/
	function checkpin()
	{
			if(isset($_REQUEST['auth_code']) && isset($_REQUEST['user_pin']))
			{
				$this->load->model('webservicemodel','',true);
				$data['res'] = $this->webservicemodel->verifyauthmodel($_REQUEST['auth_code']);
				if($data['res'] == 1)

				$data['Result'] = $this->webservicemodel->checkpinmodel($_REQUEST['auth_code'],$_REQUEST['user_pin']);
			}
			else
			{
				echo '{"Status":"false", "Data":[{"result":"Data is missing"}]}';	
			}	
	}
/********************** Update Pin ********************/
	public function updatepin()
	{
			if(isset($_REQUEST['auth_code']) && isset($_REQUEST['user_pin']))
			{
				$this->load->model('webservicemodel','',true);
				$data['res'] = $this->webservicemodel->verifyauthmodel($_REQUEST['auth_code']);
				if($data['res'] == 1)
				$data['Result'] = $this->webservicemodel->updatepinmodel($_REQUEST['auth_code'],$_REQUEST['user_pin']);
			}
			else
			{
				echo '{"Status":"false", "Data":[{"result":"Data is missing"}]}';	
			}	
	}		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
			
			
			
}