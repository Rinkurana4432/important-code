<?php
	class m_wallet Extends CI_Model{
         function __construct() {
         parent::__construct();
         $this->load->helper('url');
     	}
		function login_user($email,$password){
		 $data = $this->load->database('default', TRUE);
	     $data->select('*');
         $data->from('admin_info');
         $data->where('email',$email);
         $data->where('password',$password);
         $data = $data->get();
         $session_data = $data->row_array();
			$this->session->set_userdata("verified", $session_data);
         $_SESSION['id'] = $session_data['id'];
          if($data->num_rows() > 0){
          return true; 
          }else{
          return false;  
         }
	}
		function view_data(){
            $user_DB = $this->load->database('user_DB', TRUE);
			$user_DB->select('user_details.*,user_info.*');
			$user_DB->from('user_details');
			$user_DB->join('user_info', 'user_details.id = user_info.user_id', 'left'); 
            $ddd = $user_DB->get();
                if($ddd->num_rows() > 0){
                return $ddd->result_array();
            }else{
              return false;
                }
        }
		
		function edited_user($id){
			$user_DB = $this->load->database('user_DB', TRUE);
			
			$user_DB->select('e.*,ed.*');
			$user_DB->from('user_info e');
			$user_DB->join('user_details ed','e.user_id = ed.id','left');
			$user_DB->where('ed.id = "'.$id.'"');
			$d = $user_DB->get();
                 if($d->num_rows() > 0){
                return $d->result_array();
            }else{
              return false;
                }
		}
		
		public function update_user_data($id,$update_value){
			$user_DB = $this->load->database('user_DB', TRUE);
			$user_DB->set('name',$update_value['name']);
			$user_DB->set('mobile_no',$update_value['mobile']);
    		$user_DB->where('id', $id);
    		$user_DB->update('user_info');
			//return $user_DB->affected_rows();
			$user_DB->set('user_email',$update_value['user_email']);
			$user_DB->where('id', $id);
    		$user_DB->update('user_details');
			return $user_DB->affected_rows(); 
 		}
		
		public function select_loginusr_id($login_user_id){
			 $data = $this->load->database('default', TRUE);
			 $data->select('*');
			 $data->from('admin_info');
			 $d = $data->get();
                 if($d->num_rows() > 0){
                return $d->result_array();
            	}else{
              	return false;
                }
		}
		
		public function create_store_model($email,$insert_store_data){
			  $user_DB = $this->load->database('user_DB', TRUE);
			  $user_DB->select('*');
			  $user_DB->from('store_details');
			  $user_DB->where('email',$email);
			  $exits = $user_DB->get();
			  if($exits->num_rows() > 0){
			  return false;
			  }
			$user_DB->insert('store_details', $insert_store_data);
      		return $user_DB->affected_rows();
			
		}
		
		public function view_store_data(){
		    $user_DB = $this->load->database('user_DB', TRUE);
			$user_DB->select('*');
			$user_DB->from('store_details');
			//$user_DB->order_by("id", "ASC");
			$store_Data = $user_DB->get();
                if($store_Data->num_rows() > 0){
                return $store_Data->result_array();
            }else{
              return false;
                }
			
		}
		
		public function delete_store_model($id){
			 $user_DB = $this->load->database('user_DB', TRUE);
			 $user_DB->where('id', $id);
  			 $user_DB->delete('store_details');
			 $user_DB->affected_rows(); 
			
			 $amount_DB = $this->load->database('amount_DB', TRUE);
			 $amount_DB->where('store_id', $id);
  			 $amount_DB->delete('store_wallet_amt');				
			return $amount_DB->affected_rows();  
		}
		
		public function editedstore($id){
		    $user_DB = $this->load->database('user_DB', TRUE);
		    $user_DB->select('*');
			$user_DB->from('store_details');
			$user_DB->where('id',$id);
			$d = $user_DB->get();
                 if($d->num_rows() > 0){
                return $d->result_array();
            }else{
              return false;
                }
		
		}
		
		public function update_store_data($id,$update_store_value){
		   $user_DB = $this->load->database('user_DB', TRUE);
		   $user_DB->where('id',$id);
           $user_DB->update('store_details',$update_store_value);
		   return $user_DB->affected_rows(); 	
		}
		
		public function store_totl(){
			$user_DB = $this->load->database('user_DB', TRUE);
			$user_DB->select('*');
			$user_DB->from('store_details');
			$d = $user_DB->get();
                 if($d->num_rows() > 0){
                return $d->result_array();
            }else{
              return false;
                }
	    }
		
		public function storeadd_amnt($val){
			$amount_DB = $this->load->database('amount_DB', TRUE);
			$amount_DB->insert('store_wallet_amt', $val);
      		return $amount_DB->affected_rows();
		}	
		
		public function amount_add_dtl(){
		    $amount_DB = $this->load->database('amount_DB', TRUE);  
	        $amount_DB->select('*');
			$amount_DB->from('store_wallet_amt');
			$d = $amount_DB->get();
				if($d->num_rows() > 0){
                return $d->result_array();
           	 }else{
              return false;
                }
		}
		
		public function get_store_name($storeid) {
		 $user_DB = $this->load->database('user_DB', TRUE);
         $user_DB->select('*');
		 $user_DB->from('store_details');
		 $user_DB->where('id',$storeid);
		 $d = $user_DB->get();
                 if($d->num_rows() > 0){
                	return $d->result_array();
            	}else{
              	return false;
                }	
    	}
	
		public function pending_amount_tostore(){
		 $amount_DB = $this->load->database('amount_DB', TRUE);
         $amount_DB->select('*');
		 $amount_DB->from('pending_payment_details');
		 $d = $amount_DB->get();
                 if($d->num_rows() > 0){
                return $d->result_array();
            }else{
              return false;
                }	
	}
		
	public function paypayment_anddelete($id){
		 $amount_DB = $this->load->database('amount_DB', TRUE);
		 $amount_DB->select('*');
		 $amount_DB->from('pending_payment_details');
		 $amount_DB->where('id', $id);
		 $d = $amount_DB->get();
                 if($d->num_rows() > 0){
                return $d->result_array();
            	}else{
             	 return false;
                }
    	}
		
		public function insert_pending_payment($resp){
			$id = $resp[0]['id'];
			$store_id = $resp[0]['store_id'];
			$amount = $resp[0]['amount'];
			$current_date = date('Y-m-d H:i:s');
			$datatt = array(
						'store_id' => $store_id,
						'amount' => $amount,	
						'created_date' => $current_date	
						);
			$amount_DB = $this->load->database('amount_DB', TRUE);
			$amount_DB->insert('store_wallet_amt', $datatt);
			$amount_DB->where('id', $id);
  			$amount_DB->delete('pending_payment_details');
      		  return $amount_DB->affected_rows();
	       }
		
	
			
			
	}














