<?php
	class webservicemodel Extends CI_Model{
         function __construct() {
         parent::__construct();
         $this->load->helper('url');
     	}
		/********************** signup model ********************/
	public function signupmodel( $name, $email, $pwd, $mobile )
	{
	
		$user_DB = $this->load->database('user_DB', TRUE);		
		$created_date = date("Y-m-d H:i:s");
		$password = md5($pwd);
		
		$query = $user_DB->query(" SELECT * FROM `user_info` WHERE email ='".$email."' ");
		$count = $query->num_rows();
		
		if($count > 0)
		{
				echo '{"Status":"false", "Data":[{"result":"This email already exists. Please enter another email address or try Forgot password to regenerate the password for your old account."}]}';				
		
		}
		else
		{
			$hash = md5(rand(0,1000));
			
			$data1 = array(
					'email'=>$email,
					'password'=>$password,
				    'hash_code'=>$hash 
					'created_at'=>$created_date
					);
			
			     $user_DB->insert('user_info', $data1);
				 
				 $last_user_id = $user_DB->insert_id();

              
			//$last_user_id = mysql_insert_id();

			$data2 = array(
					'user_id'=>$last_user_id,
					'name'=>$name,					
					'mobile'=>$mobile,
					'profile_pic'=>'',
					'created_at'=>$created_date
				);
			
			$user_DB->insert('user_details', $data2);	
			//$subject='S3cur3 - Verify your email address';
			    $to = $email;
				$subject = "S3cur3 - Verify your email address.";
				$message = '<html>
                       <body topmargin="25">
					   Dear '.$name.'<br><p>To activate your S3cur3 account, please verify your email address by <a href ="http://cloudart.com.au/projects/s3cur3_wallet/verify_email.php?user_email='.$email.'&hash='.$hash.'" > clicking here </a></p><br/>Thanks,<br/>Team S3cur3</body></html>';

				$headers = "From: s3cur3@reply.com\r\n";
				$headers .= "Reply-To: s3cur3@reply.com\r\n";
				$headers .= "Return-Path: s3cur3@reply.com\r\n";
			    $headers  = 'MIME-Version: 1.0' . "\r\n";
                $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			    mail($to,$subject,$message,$headers);
		
			echo '{"Status":"true", "Data":[{"user_id":"'.$last_user_id.'"}]}';					
		
		}
		
	}
		
		
		public function loginmodel($email,$pwd){	
			
		$user_DB = $this->load->database('user_DB', TRUE);
		$query = $user_DB->query("SELECT * FROM `user_details` WHERE user_email ='".$email."'");
		$count = $query->num_rows();
		
		if($count > 0)
		{	
			$res = $query->result();
			if($res[0]->user_pin_no)
			{
				$pin = 1;
			}
			else
			{
				$pin = 0;
			}

			$query1 = $user_DB->query("SELECT * FROM `user_info` WHERE user_id ='".$res[0]->id."'");
			
			$res1 = $query1->result();
			
			if( $res[0]->user_pass == md5($pwd) )
			{
				$active = $res1[0]->active;
				if( $active != 1 )
				{
					echo '{"Status":"false", "Data":[{"result":"Your Account Is not Active."}]}';
					exit();
				}
				$auth_code = md5(rand(0,9999)); 
				$created_date = date("Y-m-d H:i:s");
				
				$data1 = array(
						'user_id'=>$res[0]->id,
						'auth_code'=>$auth_code,
						'created_date'=>$created_date
						);
					//echo '<pre>'; print_r($data1);die;
				$user_DB->insert('payooze_auth', $data1);
			
				echo '{"Status":"true","Data":{"id":"'.$res[0]->id.'","name" : "'.$res1[0]->name.'" , "email ":"'.$res[0]->user_email.'", "profile_pic ":"'.$res1[0]->profile_pic.'","mobile_no":"'.$res1[0]->mobile_no.'","user_pin":"'.$pin.'","auth_code":"'.$auth_code.'"}}';	

			
			}
			else
			{
				
				echo '{"Status":"false", "Data":[{"result":"Please enter a valid password and try again."}]}';				
			
			}
		
		}
		else
		{
				echo '{"Status":"false", "Data":[{"result":"An account with the entered email address does not exist."}]}';		
		
		}
	
	}
		

	/********************** Verify Authcode Model ********************/	
	public function verifyauthmodel($auth_code){	
		$user_DB = $this->load->database('user_DB', TRUE);
		$sql = $user_DB->query("select * from payooze_auth where auth_code='".$auth_code."' ")-> num_rows();
		if($sql > 0){
			return $sql;
		    }else{
			echo '{"Status":"falseA" , "Data":[{"result":"authcode expired"}]}';
			die();	
		   }
	}		
		
	/********************** Verify Authcode Model End********************/		
	/********************** Change Password Model ********************/
	public function changepwdmodel($auth,$pwd,$newpwd)
	{
		$user_DB = $this->load->database('user_DB', TRUE);	
		$sql = $user_DB->query("select * from payooze_auth where auth_code='".$auth."' ");
		$count = $sql-> num_rows();
		if( $count > 0)
		{
			$result = $sql->result();
			
			$userpass = $user_DB->query("select * from user_details where `id`='{$result[0]->user_id}' ");
			$res_userpass = $userpass->result();

			$oldpwd = $res_userpass[0]->user_pass; 
			
			if( md5($pwd) == $oldpwd )
			{
			   $newpwd_data = array(
			   	   'user_pass' => md5($newpwd)			   
				);
			   
			   $user_DB->where('id',$result[0]->user_id);
			   $user_DB->update('user_details',$newpwd_data);	

				echo '{"Status":"true" , "Data":[{"result":"Password Changed"}]}';			
				die();
			}
			else
			{
			echo '{"Status":"false" , "Data":[{"result":"The entered old password does not match the existing password."}]}';			
			die();
			}
		}
		else
		{
			echo '{"Status":"false" , "Data":[{"result":"authcode expired"}]}';			
			die();
		}
	}
/********************** Forgot Password Model ********************/	
	public function forgotpwdmodel($email)
	{
	
		$user_DB = $this->load->database('user_DB', TRUE);	
			$randomString = substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 1) . 			         substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 10);
	
			$login_query = $user_DB->query("select a.*,b.* from user_details as a,user_info as b where a.user_email='".$email."' AND a.id=b.user_id AND b.active=1 ");
			$login_num = $login_query->num_rows();
			if($login_num > 0)
			{	
			    $to = $email;
				$subject='S3cur3 - New Password';
				$message = '<html><body topmargin="25"><p>Here is your new Password : '.$randomString.'' . '</p><br/><p>Use this to login but please change your password on login for security reasons.</p><br/><p>Regards,<br/>Team S3cur3</>p</body></html>';
				
				
				$headers = "From: s3cur3@reply.com\r\n";
				$headers .= "Reply-To: s3cur3@reply.com\r\n";
				$headers .= "Return-Path: s3cur3@reply.com\r\n";
			    $headers  = 'MIME-Version: 1.0' . "\r\n";
                $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			    mail($to,$subject,$message,$headers);
				
				 $data1 = array(
			   'user_pass' => md5($randomString)			   
			   );
	
			   $user_DB->where('user_email',$email);
			   $user_DB->update('user_details',$data1);
				echo '{"Status":"true", "Data":[{"result":"A new password has been sent to your email. Please check email for further instructions."}]}';
			   exit();
			
			}
			else
			{	echo '{"Status":"false", "Data":[{"result":"The entered email address is not a valid registered user id. Please enter your registered email address."}]}';
				
				exit();
			}
	}
		
		
	/********************** User Pin Model ********************/
	public function userpinmodel($auth,$userpin)
	{	
		$user_DB = $this->load->database('user_DB', TRUE);
		 $sql = $user_DB->query("select * from payooze_auth where auth_code='".$auth."' ")-> num_rows();
		  if( $sql > 0)
		  {
			  $_check = $user_DB->query("select user_id from `payooze_auth` where `auth_code`='".$auth."' ");
              $_result = $_check->row_array();
			  $id= $_result['user_id'];
				
				$pin = md5($userpin);
							$data1 = array(
								'user_pin_no'=>$pin	
								);
								
							$user_DB->where('id',$id);
							$user_DB->update('user_details', $data1);
														
 						echo '{"Status":"true" }';
						exit();
		  }
		
	}
/********************** Forgot Pin Model ********************/
	public function forgotpinmodel($email)
	{	
		    $user_DB = $this->load->database('user_DB', TRUE);	
			$randomString = substr(str_shuffle("0123456789"), 0, 1) . substr(str_shuffle("0123456789"), 0, 3);
	
			$login_query = $user_DB->query("select a.*,b.* from user_details as a,user_info as b where a.user_email='".$email."' AND a.id=b.user_id AND b.active=1 ");
			$login_num = $login_query->num_rows();
			if($login_num > 0)
			{	
		
				$to = $email;
				$subject='New Pin for the S3cur3 Account';
				$message = '<html><body topmargin="25"><p>Here is your new PIN : '.$randomString.'' . '</p><br/><p>Please change your PIN from your account on login for security reasons.</p><br/><p>Regards,<br/>Team S3cur3</>p</body></html>';
				
				
				$headers = "From: s3cur3@reply.com\r\n";
				$headers .= "Reply-To: s3cur3@reply.com\r\n";
				$headers .= "Return-Path: s3cur3@reply.com\r\n";
			    $headers  = 'MIME-Version: 1.0' . "\r\n";
                $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			    mail($to,$subject,$message,$headers);		

			   
			   $data1 = array(
			   'user_pin_no' => md5($randomString)			   
			   );
			   $user_DB->where('user_email',$email);
			  $user_DB->update('user_details',$data1);
				echo '{"Status":"true", "Data":[{"result":"A new pin has been sent to your email. Please check email for further instructions."}]}';
			   exit();
			
			}
			else
			{	echo '{"Status":"false", "Data":[{"result":"The entered email address is not a valid registered user id. Please enter your registered email address."}]}';
				
				exit();
			}	
		
	}
/********************** Check Pin Model ********************/
	public function checkpinmodel($auth,$userpin)
	{
	
		$user_DB = $this->load->database('user_DB', TRUE);
		$sql = $user_DB->query("select * from payooze_auth where auth_code='".$auth."' ")-> num_rows();		

		if( $sql > 0)
		{
			$checkusr = $user_DB->query("select * from payooze_auth where auth_code='".$auth."' ");
			$resuser = $checkusr->result();
			
			$user_id = $resuser[0]->user_id;
			
			$checkpin = $user_DB->query("select * from user_details where id ='".$user_id."' ");
			$respin = $checkpin->result();
			
			if( md5($userpin) == $respin[0]-> user_pin_no )
			{
				echo '{"Status":"true" , "Data":[{"result":"userpin matched"}]}';
			}
			else
			{
				echo '{"Status":"false" , "Data":[{"result":"The enter PIN number is not correct."}]}';
			}
		}
		
	}
/********************** Update Pin Model ********************/	
	public function updatepinmodel($auth,$userpin)
	{	
		$user_DB = $this->load->database('user_DB', TRUE);		
		 $sql = $user_DB->query("select * from payooze_auth where auth_code='".$auth."' ")-> num_rows();
		  if( $sql > 0)
		  {
			  $_check = $user_DB->query("select user_id from `payooze_auth` where `auth_code`='".$auth."' ");
              $_result = $_check->row_array();
			  $id= $_result['user_id'];
				
				$pin = md5($userpin);
							$data1 = array(
								'user_pin_no'=>$pin	
								);
								
							$user_DB->where('id',$id);
							$user_DB->update('user_details', $data1);
														
 						echo '{"Status":"true" }';
						exit();
		  }
		
	}			
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}